"""Test package.

Chromium's sandbox cannot start as root inside a container without user
namespaces, so the suite opts in explicitly instead of the worker defaulting to
a weaker security posture.
"""

import os

os.environ.setdefault("BROWSER_WORKER_NO_SANDBOX", "1")
