"""Portable auth state: cookies plus localStorage, without moving a user-data dir."""

import unittest

from browser_worker.service import WorkerError
from tests.support import LoginSiteTest, sign_in


class AuthStateTest(LoginSiteTest):
    async def test_state_moves_a_login_between_homes(self) -> None:
        session = await self.worker_a.create_session("auth")
        sid = session["session_id"]
        await sign_in(self.worker_a, sid, self.base)
        page = self.worker_a.get(sid).page
        await page.evaluate("localStorage.setItem('theme', 'dark')")

        state = await self.worker_a.export_profile_state("auth")
        self.assertGreaterEqual(len(state.get("cookies") or []), 1)
        self.assertTrue(any(origin.get("localStorage") for origin in state.get("origins") or []))
        await self.worker_a.close_session(sid)

        # control: the same site is not authenticated on the second home yet
        control = await self.worker_b.create_session("auth")
        control_page = await self.worker_b.goto(control["session_id"], f"{self.base}/app")
        self.assertTrue(control_page["url"].endswith("/login"), control_page["url"])
        await self.worker_b.close_session(control["session_id"])

        applied = await self.worker_b.import_profile_state("auth", state)
        self.assertGreaterEqual(applied["cookies"], 1)
        self.assertGreaterEqual(applied["origins"], 1)

        reused = await self.worker_b.create_session("auth")
        page_b = await self.worker_b.goto(reused["session_id"], f"{self.base}/app")
        self.assertTrue(page_b["url"].endswith("/app"), page_b["url"])
        who = await self.worker_b.extract(reused["session_id"], "#who")
        self.assertEqual(who["value"], "welcome alice")
        theme = await self.worker_b.get(reused["session_id"]).page.evaluate("localStorage.getItem('theme')")
        self.assertEqual(theme, "dark")
        await self.worker_b.close_session(reused["session_id"])

    async def test_rejects_state_without_cookies_array(self) -> None:
        with self.assertRaises(WorkerError):
            await self.worker_a.import_profile_state("broken", {"origins": []})

    async def test_session_cookie_survives_import_and_reopen(self) -> None:
        """Chromium drops session cookies on close; the state file has to replay them."""
        session = await self.worker_a.create_session("sc")
        sid = session["session_id"]
        await self.worker_a.goto(sid, f"{self.base}/slogin")
        acted = await self.worker_a.act(sid, [
            {"type": "fill", "selector": "#u", "text": "alice"},
            {"type": "fill", "selector": "#p", "text": "secret"},
            {"type": "click", "selector": "#submit"},
        ])
        self.assertTrue(acted["ok"], acted)
        await self.worker_a.get(sid).page.wait_for_selector("#who", timeout=5000)

        state = await self.worker_a.export_profile_state("sc")
        cookie = next(c for c in state["cookies"] if c["name"] == "sid")
        self.assertEqual(cookie.get("expires"), -1, "fixture must produce a session cookie")
        await self.worker_a.close_session(sid)

        control = await self.worker_b.create_session("sc")
        control_url = (await self.worker_b.goto(control["session_id"], f"{self.base}/app"))["url"]
        self.assertTrue(control_url.endswith("/login"), control_url)
        await self.worker_b.close_session(control["session_id"])

        await self.worker_b.import_profile_state("sc", state)

        reused = await self.worker_b.create_session("sc")
        page = await self.worker_b.goto(reused["session_id"], f"{self.base}/app")
        self.assertTrue(page["url"].endswith("/app"), page["url"])
        who = await self.worker_b.extract(reused["session_id"], "#who")
        self.assertEqual(who["value"], "welcome alice")
        await self.worker_b.close_session(reused["session_id"])

        # causal check: the replay file, not luck, is what keeps the session alive
        (self.worker_b.store.path("sc") / "browser-worker-state.json").unlink()
        bare = await self.worker_b.create_session("sc")
        bare_url = (await self.worker_b.goto(bare["session_id"], f"{self.base}/app"))["url"]
        self.assertTrue(bare_url.endswith("/login"), "session cookie should not survive without replay")
        await self.worker_b.close_session(bare["session_id"])

    async def _session_cookie_state(self) -> dict:
        session = await self.worker_a.create_session("seed")
        sid = session["session_id"]
        await self.worker_a.goto(sid, f"{self.base}/slogin")
        await self.worker_a.act(sid, [
            {"type": "fill", "selector": "#u", "text": "alice"},
            {"type": "fill", "selector": "#p", "text": "secret"},
            {"type": "click", "selector": "#submit"},
        ])
        await self.worker_a.get(sid).page.wait_for_selector("#who", timeout=5000)
        state = await self.worker_a.export_profile_state("seed")
        await self.worker_a.close_session(sid)
        return state

    async def test_logout_is_not_resurrected_on_reopen(self) -> None:
        state = await self._session_cookie_state()
        await self.worker_b.import_profile_state("lo", state)

        live = await self.worker_b.create_session("lo")
        sid = live["session_id"]
        page = await self.worker_b.goto(sid, f"{self.base}/app")
        self.assertTrue(page["url"].endswith("/app"), page["url"])

        # a user logs out: the auth cookie disappears from the context
        await self.worker_b.get(sid).context.clear_cookies()
        await self.worker_b.close_session(sid)

        again = await self.worker_b.create_session("lo")
        after = await self.worker_b.goto(again["session_id"], f"{self.base}/app")
        self.assertTrue(after["url"].endswith("/login"), "replay must not resurrect a logged-out session")
        await self.worker_b.close_session(again["session_id"])

    async def test_import_against_a_live_profile_changes_nothing(self) -> None:
        seed = {"cookies": [], "origins": [{"origin": self.base, "localStorage": [{"name": "seed", "value": "1"}]}]}
        await self.worker_b.import_profile_state("guard", seed)
        path = self.worker_b.store.path("guard") / "browser-worker-state.json"
        before = path.read_bytes()

        live = await self.worker_b.create_session("guard")
        with self.assertRaises(WorkerError):
            await self.worker_b.import_profile_state(
                "guard",
                {"cookies": [{"name": "sid", "value": "other", "domain": "127.0.0.1", "path": "/"}], "origins": []},
            )
        self.assertEqual(path.read_bytes(), before, "a rejected import must not rewrite persistent state")
        await self.worker_b.close_session(live["session_id"])

    async def test_snapshot_failure_drops_stale_auth_instead_of_replaying_it(self) -> None:
        state = await self._session_cookie_state()
        await self.worker_b.import_profile_state("fail", state)

        live = await self.worker_b.create_session("fail")
        sid = live["session_id"]
        page = await self.worker_b.goto(sid, f"{self.base}/app")
        self.assertTrue(page["url"].endswith("/app"), page["url"])

        session = self.worker_b.get(sid)
        await session.context.clear_cookies()  # the user logs out

        async def explode() -> dict:
            raise RuntimeError("snapshot failed")

        session.context.storage_state = explode  # type: ignore[method-assign]
        await self.worker_b.close_session(sid)

        path = self.worker_b.store.path("fail") / "browser-worker-state.json"
        self.assertFalse(path.exists(), "a failed snapshot must not leave the old file behind")

        again = await self.worker_b.create_session("fail")
        after = await self.worker_b.goto(again["session_id"], f"{self.base}/app")
        self.assertTrue(after["url"].endswith("/login"), "stale auth must not be replayed")
        await self.worker_b.close_session(again["session_id"])


if __name__ == "__main__":
    unittest.main()
