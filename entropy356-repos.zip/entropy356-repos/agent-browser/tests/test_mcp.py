import json
import os
import queue
import subprocess
import sys
import tempfile
import threading
import unittest
from pathlib import Path

from browser_worker.mcp_stdio import TOOLS, build_handlers
from browser_worker.profiles import ProfileStore
from browser_worker.service import BrowserWorker
from tests.fixture import start_fixture


class McpStdioTest(unittest.TestCase):
    def setUp(self) -> None:
        self.fix_server, self.fix_port, self.fix_tmp = start_fixture()
        self.home = tempfile.TemporaryDirectory()
        env = dict(os.environ, BROWSER_WORKER_HOME=self.home.name, PYTHONUNBUFFERED="1")
        self.proc = subprocess.Popen(
            [sys.executable, "-m", "browser_worker.mcp_stdio"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            env=env,
        )
        self.lines: queue.Queue = queue.Queue()
        threading.Thread(target=self._pump, daemon=True).start()

    def _pump(self) -> None:
        assert self.proc.stdout is not None
        for line in self.proc.stdout:
            line = line.strip()
            if line:
                self.lines.put(json.loads(line))

    def tearDown(self) -> None:
        assert self.proc.stdin is not None
        self.proc.stdin.close()
        try:
            self.proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            self.proc.kill()
        self.fix_server.shutdown()
        self.fix_tmp.cleanup()
        self.home.cleanup()

    def send(self, payload: dict) -> dict:
        assert self.proc.stdin is not None
        self.proc.stdin.write(json.dumps(payload) + "\n")
        self.proc.stdin.flush()
        return self.lines.get(timeout=30)

    def call(self, name: str, arguments: dict) -> dict:
        response = self.send({
            "jsonrpc": "2.0",
            "id": 99,
            "method": "tools/call",
            "params": {"name": name, "arguments": arguments},
        })
        content = response["result"]["content"][0]["text"]
        return {"is_error": response["result"].get("isError", False), "data": json.loads(content)}

    def test_handshake_and_session_flow(self) -> None:
        init = self.send({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "test", "version": "0"}}})
        self.assertEqual(init["result"]["serverInfo"]["name"], "browser-worker")

        tools = self.send({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})["result"]["tools"]
        names = {t["name"] for t in tools}
        self.assertIn("browser_session_create", names)
        self.assertIn("browser_profile_export", names)

        session = self.call("browser_session_create", {"profile_id": "mcp-demo"})["data"]
        sid = session["session_id"]

        page = self.call("browser_goto", {"session_id": sid, "url": f"http://127.0.0.1:{self.fix_port}/index.html"})["data"]
        self.assertEqual(page["title"], "worker fixture")

        acted = self.call("browser_act", {"session_id": sid, "actions": [
            {"type": "fill", "selector": "#q", "text": "mcp"},
            {"type": "click", "selector": "#go"},
        ]})["data"]
        self.assertTrue(acted["ok"], acted)

        text = self.call("browser_extract", {"session_id": sid, "selector": "#out"})["data"]
        self.assertEqual(text["value"], "hello mcp")

        closed = self.call("browser_session_close", {"session_id": sid})["data"]
        self.assertTrue(closed["closed"])

    def test_unknown_tool_is_an_error(self) -> None:
        response = self.send({"jsonrpc": "2.0", "id": 7, "method": "tools/call", "params": {"name": "nope", "arguments": {}}})
        self.assertTrue(response["result"]["isError"])

    def test_tool_list_is_complete_and_state_tools_work(self) -> None:
        response = self.send({"jsonrpc": "2.0", "id": 3, "method": "tools/list"})
        names = {tool["name"] for tool in response["result"]["tools"]}
        self.assertEqual(names, {
            "browser_session_create",
            "browser_session_close",
            "browser_session_list",
            "browser_goto",
            "browser_act",
            "browser_extract",
            "browser_screenshot",
            "browser_profile_list",
            "browser_profile_export",
            "browser_profile_import",
            "browser_profile_state_export",
            "browser_profile_state_import",
        })

        session = self.call("browser_session_create", {"profile_id": "mcp-state"})["data"]
        sid = session["session_id"]
        self.call("browser_goto", {"session_id": sid, "url": f"http://127.0.0.1:{self.fix_port}/index.html"})
        self.call("browser_session_close", {"session_id": sid})

        state = self.call("browser_profile_state_export", {"profile_id": "mcp-state"})["data"]
        self.assertIn("cookies", state)
        applied = self.call(
            "browser_profile_state_import",
            {"profile_id": "mcp-state-copy", "state": state},
        )["data"]
        self.assertEqual(applied["profile_id"], "mcp-state-copy")


if __name__ == "__main__":
    unittest.main()


class ToolDeclarationsTest(unittest.TestCase):
    """Declared tools and dispatchable tools must not drift apart again."""

    def test_every_declared_tool_has_a_handler(self) -> None:
        with tempfile.TemporaryDirectory() as home:
            root = Path(home)
            store = ProfileStore(root=root / "profiles", lock_dir=root / "locks")
            handlers = build_handlers(BrowserWorker(store))
        declared = {tool["name"] for tool in TOOLS}
        self.assertEqual(declared, set(handlers))
