import io
import json
import os
import socket
import tarfile
import tempfile
import unittest
from pathlib import Path

from browser_worker.profiles import ProfileBusy, ProfileError, ProfileStore


class ProfileStoreTest(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.store = ProfileStore(root=root / "profiles", lock_dir=root / "locks")

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_create_and_list(self) -> None:
        pid = self.store.ensure(None)
        self.assertTrue(pid.startswith("p-"))
        self.assertTrue(self.store.exists(pid))
        (self.store.path(pid) / "Cookies").write_bytes(b"cookie-jar")
        info = self.store.info(pid)
        self.assertEqual(info["profile_id"], pid)
        self.assertGreater(info["bytes"], 0)
        self.assertFalse(info["locked"])
        self.assertEqual([p["profile_id"] for p in self.store.list()], [pid])

    def test_rejects_bad_id(self) -> None:
        for bad in ["../etc", "A/B", "", "x" * 80]:
            with self.assertRaises(ProfileError):
                self.store.ensure(bad)

    def test_export_blocked_while_locked(self) -> None:
        pid = self.store.ensure("demo")
        self.store.lock(pid, "s-1")
        with self.assertRaises(ProfileBusy):
            self.store.export(pid)
        self.store.unlock(pid, "s-1")
        payload = self.store.export(pid)
        self.assertGreater(len(payload), 0)

    def test_export_import_roundtrip(self) -> None:
        pid = self.store.ensure("roundtrip")
        (self.store.path(pid) / "Default").mkdir()
        (self.store.path(pid) / "Default" / "Cookies").write_bytes(b"state-1")

        archive = self.store.export(pid)
        with tarfile.open(fileobj=io.BytesIO(archive), mode="r:gz") as tar:
            self.assertIn("manifest.json", tar.getnames())

        restored = self.store.import_(archive, "restored")
        self.assertEqual((self.store.path(restored) / "Default" / "Cookies").read_bytes(), b"state-1")

    def test_import_rejects_traversal(self) -> None:
        buffer = io.BytesIO()
        with tarfile.open(fileobj=buffer, mode="w:gz") as tar:
            payload = b'{"format": 1}'
            info = tarfile.TarInfo("manifest.json")
            info.size = len(payload)
            tar.addfile(info, io.BytesIO(payload))
            evil = b"x"
            bad = tarfile.TarInfo("profile/../../escape")
            bad.size = len(evil)
            tar.addfile(bad, io.BytesIO(evil))
        archive = buffer.getvalue()
        with self.assertRaises(ProfileError):
            self.store.import_(archive, "bad")

    def test_import_rejects_missing_manifest(self) -> None:
        buffer = io.BytesIO()
        with tarfile.open(fileobj=buffer, mode="w:gz") as tar:
            data = b"x"
            entry = tarfile.TarInfo("profile/file")
            entry.size = len(data)
            tar.addfile(entry, io.BytesIO(data))
        archive = buffer.getvalue()
        with self.assertRaises(ProfileError):
            self.store.import_(archive, "nomanifest")

    def test_delete(self) -> None:
        pid = self.store.ensure("gone")
        self.store.delete(pid)
        self.assertFalse(self.store.exists(pid))

    def test_lock_records_owner_pid_and_host(self) -> None:
        pid = self.store.ensure("owned")
        self.store.lock(pid, "s-owner")
        info = self.store.lock_info(pid)
        self.assertIsNotNone(info)
        assert info is not None
        self.assertEqual(info["session_id"], "s-owner")
        self.assertEqual(info["pid"], os.getpid())
        self.assertEqual(info["host"], socket.gethostname())
        self.assertTrue(info["created_at"])

    def test_reclaim_stale_lock_from_dead_process(self) -> None:
        pid = self.store.ensure("stale")
        self.store._lock_path(pid).write_text(
            json.dumps({"session_id": "s-dead", "pid": 2147483646, "host": socket.gethostname(), "created_at": 0})
        )
        self.assertTrue(self.store.is_locked(pid))
        self.assertTrue(self.store.reclaim_stale(pid))
        self.assertFalse(self.store.is_locked(pid))

    def test_never_reclaims_a_lock_from_another_host(self) -> None:
        pid = self.store.ensure("elsewhere")
        self.store._lock_path(pid).write_text(
            json.dumps({"session_id": "s-other", "pid": 1, "host": "another-machine", "created_at": 0})
        )
        self.assertFalse(self.store.reclaim_stale(pid))
        self.assertTrue(self.store.is_locked(pid))

    def test_import_refuses_while_profile_is_locked(self) -> None:
        pid = self.store.ensure("busy-import")
        (self.store.path(pid) / "Default").mkdir()
        (self.store.path(pid) / "Default" / "Cookies").write_bytes(b"keep-me")
        archive = self.store.export(pid)
        self.store.lock(pid, "s-live")
        with self.assertRaises(ProfileBusy):
            self.store.import_(archive, "busy-import")
        self.assertEqual((self.store.path(pid) / "Default" / "Cookies").read_bytes(), b"keep-me")


if __name__ == "__main__":
    unittest.main()
