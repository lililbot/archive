"""Shared scaffolding: two independent worker homes against one login site."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from browser_worker.profiles import ProfileStore
from browser_worker.service import BrowserWorker
from tests.fixture import start_login_fixture


def store_for(home: str) -> ProfileStore:
    root = Path(home)
    return ProfileStore(root=root / "profiles", lock_dir=root / "locks")


async def sign_in(worker: BrowserWorker, sid: str, base: str) -> None:
    """Drive the fixture's login form and wait for the authenticated page."""
    await worker.goto(sid, f"{base}/login")
    result = await worker.act(sid, [
        {"type": "fill", "selector": "#u", "text": "alice"},
        {"type": "fill", "selector": "#p", "text": "secret"},
        {"type": "click", "selector": "#submit"},
    ])
    if not result["ok"]:
        raise AssertionError(f"sign-in failed: {result}")
    await worker.get(sid).page.wait_for_selector("#who", timeout=5000)


class LoginSiteTest(unittest.IsolatedAsyncioTestCase):
    """A login site plus two workers that share nothing but the network."""

    async def asyncSetUp(self) -> None:
        self.server, self.port = start_login_fixture()
        self.home_a = tempfile.TemporaryDirectory()
        self.home_b = tempfile.TemporaryDirectory()
        self.worker_a = BrowserWorker(store_for(self.home_a.name))
        self.worker_b = BrowserWorker(store_for(self.home_b.name))
        await self.worker_a.start()
        await self.worker_b.start()

    async def asyncTearDown(self) -> None:
        await self.worker_a.stop()
        await self.worker_b.stop()
        self.server.shutdown()
        self.home_a.cleanup()
        self.home_b.cleanup()

    @property
    def base(self) -> str:
        return f"http://127.0.0.1:{self.port}"
