"""Raw user-data archives: backup and restore within a similar environment.

This is not a portability claim. The archive is only expected to restore on the
same OS user, Chromium build and filesystem layout; portable auth state is
covered by tests/test_auth_state.py.
"""

import unittest

from tests.support import LoginSiteTest, sign_in


class RawArchiveTest(LoginSiteTest):
    async def test_raw_archive_restores_a_login_in_a_similar_environment(self) -> None:
        first = await self.worker_a.create_session("auth")
        sid = first["session_id"]
        await sign_in(self.worker_a, sid, self.base)
        signed_in = await self.worker_a.extract(sid, "#who")
        self.assertEqual(signed_in["value"], "welcome alice")
        await self.worker_a.close_session(sid)

        archive = self.worker_a.export_profile("auth")
        self.assertGreater(len(archive), 0)

        # control: the second home has no such login yet
        control = await self.worker_b.create_session("fresh")
        control_page = await self.worker_b.goto(control["session_id"], f"{self.base}/app")
        self.assertTrue(control_page["url"].endswith("/login"), control_page["url"])
        await self.worker_b.close_session(control["session_id"])

        self.assertEqual(self.worker_b.store.import_(archive, "auth"), "auth")

        reused = await self.worker_b.create_session("auth")
        page = await self.worker_b.goto(reused["session_id"], f"{self.base}/app")
        self.assertTrue(page["url"].endswith("/app"), page["url"])
        who = await self.worker_b.extract(reused["session_id"], "#who")
        self.assertEqual(who["value"], "welcome alice")
        await self.worker_b.close_session(reused["session_id"])


if __name__ == "__main__":
    unittest.main()
