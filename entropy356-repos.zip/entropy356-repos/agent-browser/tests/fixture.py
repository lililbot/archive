"""A local page used by the tests, served over HTTP so storage APIs are real."""

from __future__ import annotations

import http.server
import socketserver
import tempfile
import threading
from pathlib import Path

INDEX = """<!doctype html>
<html><head><meta charset="utf-8"><title>worker fixture</title></head>
<body>
  <input id="q" value="">
  <button id="go" onclick="document.getElementById('out').textContent='hello '+document.getElementById('q').value">go</button>
  <div id="out"></div>
  <div id="mark"></div>
  <a id="link" href="/second.html">second</a>
  <script>
    document.getElementById('mark').textContent = localStorage.getItem('mark') || 'none';
  </script>
</body></html>
"""

SECOND = "<html><head><title>second</title></head><body><h1>second page</h1></body></html>"


class _Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):  # keep test output clean
        pass


def start_fixture() -> tuple[socketserver.TCPServer, int, tempfile.TemporaryDirectory]:
    tmp = tempfile.TemporaryDirectory()
    Path(tmp.name, "index.html").write_text(INDEX, encoding="utf-8")
    Path(tmp.name, "second.html").write_text(SECOND, encoding="utf-8")

    def handler(*args, **kwargs):
        return _Handler(*args, directory=tmp.name, **kwargs)

    server = socketserver.TCPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, server.server_address[1], tmp


LOGIN = """<!doctype html>
<html><head><meta charset="utf-8"><title>sign in</title></head>
<body>
  <form method="post" action="/login">
    <input id="u" name="username" value="">
    <input id="p" name="password" type="password" value="">
    <button id="submit" type="submit">sign in</button>
  </form>
</body></html>
"""


SLOGIN = """<!doctype html>
<html><head><meta charset="utf-8"><title>sign in (session cookie)</title></head>
<body>
  <form method="post" action="/slogin">
    <input id="u" name="username" value="">
    <input id="p" name="password" type="password" value="">
    <button id="submit" type="submit">sign in</button>
  </form>
</body></html>
"""


class _LoginHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _send(self, code: int, body: str, extra: dict[str, str] | None = None) -> None:
        payload = body.encode()
        self.send_response(code)
        self.send_header("content-type", "text/html; charset=utf-8")
        self.send_header("content-length", str(len(payload)))
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self) -> None:
        if self.path in {"/", "/login"}:
            self._send(200, LOGIN)
            return
        if self.path == "/slogin":
            self._send(200, SLOGIN)
            return
        if self.path == "/app":
            if "sid=ok" in (self.headers.get("Cookie") or ""):
                self._send(200, "<html><body><h1 id='who'>welcome alice</h1></body></html>")
            else:
                self._send(302, "", {"location": "/login"})
            return
        self._send(404, "not found")

    def do_POST(self) -> None:
        if self.path == "/slogin":
            length = int(self.headers.get("content-length") or 0)
            body = self.rfile.read(length).decode()
            if "username=alice" in body and "password=secret" in body:
                # No Max-Age / Expires on purpose: a session cookie.
                self._send(303, "", {"set-cookie": "sid=ok; Path=/; HttpOnly", "location": "/app"})
            else:
                self._send(401, "<html><body>denied</body></html>")
            return
        if self.path != "/login":
            self._send(404, "not found")
            return
        length = int(self.headers.get("content-length") or 0)
        body = self.rfile.read(length).decode()
        if "username=alice" in body and "password=secret" in body:
            self._send(303, "", {"set-cookie": "sid=ok; Path=/; HttpOnly; Max-Age=3600", "location": "/app"})
        else:
            self._send(401, "<html><body>denied</body></html>")


def start_login_fixture() -> tuple[socketserver.TCPServer, int]:
    server = socketserver.TCPServer(("127.0.0.1", 0), _LoginHandler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, server.server_address[1]
