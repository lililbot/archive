import os
import unittest
from unittest.mock import patch

from browser_worker.cli import is_loopback_host, validate_http_bind


class HttpBindSafetyTest(unittest.TestCase):
    def test_loopback_hosts_need_no_token(self) -> None:
        with patch.dict(os.environ, {"BROWSER_WORKER_HTTP_TOKEN": ""}):
            for host in ["localhost", "127.0.0.1", "127.0.0.2", "::1"]:
                with self.subTest(host=host):
                    self.assertTrue(is_loopback_host(host))
                    validate_http_bind(host)

    def test_remote_bind_without_token_is_rejected(self) -> None:
        with patch.dict(os.environ, {"BROWSER_WORKER_HTTP_TOKEN": ""}):
            for host in ["0.0.0.0", "192.0.2.10", "example.invalid"]:
                with self.subTest(host=host):
                    self.assertFalse(is_loopback_host(host))
                    with self.assertRaises(ValueError):
                        validate_http_bind(host)

    def test_remote_bind_with_token_is_allowed(self) -> None:
        with patch.dict(os.environ, {"BROWSER_WORKER_HTTP_TOKEN": "secret"}):
            validate_http_bind("0.0.0.0")

    def test_explicit_unsafe_override_is_allowed(self) -> None:
        with patch.dict(os.environ, {"BROWSER_WORKER_HTTP_TOKEN": ""}):
            validate_http_bind("0.0.0.0", allow_unauthenticated_remote=True)


if __name__ == "__main__":
    unittest.main()
