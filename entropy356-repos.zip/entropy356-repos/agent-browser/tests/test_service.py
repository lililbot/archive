import asyncio
import json
import socket
import socketserver
import tempfile
import threading
import unittest
from pathlib import Path

from browser_worker.profiles import ProfileStore
from browser_worker.service import BrowserWorker, WorkerError

from tests.fixture import start_fixture


class ServiceTest(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self.server, self.port, self.tmp = start_fixture()
        self.home = tempfile.TemporaryDirectory()
        root = Path(self.home.name)
        self.store = ProfileStore(root=root / "profiles", lock_dir=root / "locks")
        self.worker = BrowserWorker(self.store)
        await self.worker.start()

    async def asyncTearDown(self) -> None:
        await self.worker.stop()
        self.server.shutdown()
        self.tmp.cleanup()
        self.home.cleanup()

    async def test_navigate_act_extract(self) -> None:
        session = await self.worker.create_session("demo")
        sid = session["session_id"]
        url = f"http://127.0.0.1:{self.port}/index.html"

        page = await self.worker.goto(sid, url)
        self.assertEqual(page["title"], "worker fixture")
        self.assertEqual(page["status"], 200)

        result = await self.worker.act(sid, [
            {"type": "fill", "selector": "#q", "text": "world"},
            {"type": "click", "selector": "#go"},
        ])
        self.assertTrue(result["ok"], result)

        text = await self.worker.extract(sid, "#out")
        self.assertEqual(text["value"], "hello world")

        shot = await self.worker.screenshot(sid)
        self.assertGreater(len(shot), 1000)

    async def test_action_failure_is_reported(self) -> None:
        session = await self.worker.create_session("failing")
        sid = session["session_id"]
        await self.worker.goto(sid, f"http://127.0.0.1:{self.port}/index.html")
        result = await self.worker.act(sid, [{"type": "click", "selector": "#missing", "timeout_ms": 800}])
        self.assertFalse(result["ok"])
        self.assertEqual(result["failed_type"], "click")
        self.assertIn("error", result)

    async def test_profile_persists_across_sessions(self) -> None:
        first = await self.worker.create_session("keeper")
        sid = first["session_id"]
        url = f"http://127.0.0.1:{self.port}/index.html"
        await self.worker.goto(sid, url)
        await first_page_eval(self.worker, sid)
        await self.worker.close_session(sid)

        second = await self.worker.create_session("keeper")
        sid2 = second["session_id"]
        await self.worker.goto(sid2, url)
        mark = await self.worker.extract(sid2, "#mark")
        self.assertEqual(mark["value"], "persisted-v1")
        await self.worker.close_session(sid2)

        archive = self.worker.export_profile("keeper")
        self.assertGreater(len(archive), 0)
        restored = self.store.import_(archive, "keeper-copy")
        self.assertTrue(self.store.exists(restored))

    async def test_unknown_session(self) -> None:
        with self.assertRaises(WorkerError):
            await self.worker.goto("s-missing", "about:blank")

    async def test_profile_lock_blocks_second_session(self) -> None:
        await self.worker.create_session("busy")
        with self.assertRaises(WorkerError):
            await self.worker.create_session("busy")
        sessions = await self.worker.list_sessions()
        self.assertEqual(len(sessions), 1)
        await self.worker.close_session(sessions[0]["session_id"])
        await asyncio.sleep(0.2)
        again = await self.worker.create_session("busy")
        self.assertTrue(again["session_id"].startswith("s-"))

    async def test_stale_lock_is_reclaimed_before_launch(self) -> None:
        pid = "recovered"
        self.store.ensure(pid)
        (self.store.path(pid) / "marker").write_text("keep")
        self.store._lock_path(pid).write_text(
            json.dumps({"session_id": "s-dead", "pid": 2147483646, "host": socket.gethostname(), "created_at": 0})
        )
        created = await self.worker.create_session(pid)
        self.assertEqual(created["profile_id"], pid)
        await self.worker.close_session(created["session_id"])
        self.assertFalse(self.store.is_locked(pid))
        self.assertTrue((self.store.path(pid) / "marker").exists())

    async def test_foreign_lock_is_rejected_until_forced(self) -> None:
        pid = "foreign"
        self.store.ensure(pid)
        self.store._lock_path(pid).write_text(
            json.dumps({"session_id": "s-other", "pid": 1, "host": "another-machine", "created_at": 0})
        )
        with self.assertRaises(WorkerError):
            await self.worker.create_session(pid)
        forced = await self.worker.create_session(pid, force=True)
        self.assertEqual(forced["profile_id"], pid)
        await self.worker.close_session(forced["session_id"])


async def first_page_eval(worker: BrowserWorker, sid: str) -> None:
    session = worker.get(sid)
    await session.page.evaluate("localStorage.setItem('mark','persisted-v1')")
    await session.page.reload(wait_until="load")


if __name__ == "__main__":
    unittest.main()
