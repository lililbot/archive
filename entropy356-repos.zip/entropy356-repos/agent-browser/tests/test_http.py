import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path

from tests.fixture import start_fixture


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class HttpApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.server, cls.fixture_port, cls.fixture_tmp = start_fixture()
        cls.home = tempfile.TemporaryDirectory()
        cls.port = free_port()
        env = dict(os.environ, BROWSER_WORKER_HOME=cls.home.name, PYTHONUNBUFFERED="1")
        env.pop("BROWSER_WORKER_HTTP_TOKEN", None)
        cls.proc = subprocess.Popen(
            [sys.executable, "-m", "uvicorn", "browser_worker.http_api:app", "--host", "127.0.0.1", "--port", str(cls.port), "--log-level", "warning"],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        deadline = time.time() + 30
        while time.time() < deadline:
            try:
                cls.get("/health")
                return
            except Exception:
                time.sleep(0.3)
        raise RuntimeError("worker did not start")

    @classmethod
    def tearDownClass(cls) -> None:
        cls.proc.terminate()
        try:
            cls.proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            cls.proc.kill()
        cls.server.shutdown()
        cls.fixture_tmp.cleanup()
        cls.home.cleanup()

    @classmethod
    def url(cls, path: str) -> str:
        return f"http://127.0.0.1:{cls.port}{path}"

    @classmethod
    def get(cls, path: str):
        with urllib.request.urlopen(cls.url(path), timeout=10) as r:
            return json.load(r)

    @classmethod
    def post(cls, path: str, body: dict | None = None, raw: bytes | None = None):
        data = raw if raw is not None else json.dumps(body or {}).encode()
        req = urllib.request.Request(cls.url(path), data=data, method="POST", headers={"content-type": "application/json"})
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.load(r) if "json" in (r.headers.get("content-type") or "") else r.read()

    def test_full_flow(self) -> None:
        session = self.post("/v1/sessions", {"profile_id": "http-demo"})
        sid = session["session_id"]
        self.assertEqual(session["profile_id"], "http-demo")

        page = self.post(f"/v1/sessions/{sid}/goto", {"url": f"http://127.0.0.1:{self.fixture_port}/index.html"})
        self.assertEqual(page["status"], 200)

        acted = self.post(f"/v1/sessions/{sid}/act", {"actions": [
            {"type": "fill", "selector": "#q", "text": "http"},
            {"type": "click", "selector": "#go"},
        ]})
        self.assertTrue(acted["ok"], acted)

        text = self.post(f"/v1/sessions/{sid}/extract", {"selector": "#out"})
        self.assertEqual(text["value"], "hello http")

        shot = self.post(f"/v1/sessions/{sid}/screenshot", {"full_page": False})
        self.assertGreater(len(shot), 1000)

        with self.assertRaises(urllib.error.HTTPError) as busy:
            self.post("/v1/profiles/http-demo/export", {})
        self.assertEqual(busy.exception.code, 409)

        closed = urllib.request.Request(self.url(f"/v1/sessions/{sid}"), method="DELETE")
        with urllib.request.urlopen(closed, timeout=20) as r:
            self.assertTrue(json.load(r)["closed"])

        archive = self.post("/v1/profiles/http-demo/export", {})
        self.assertGreater(len(archive), 0)

        imported = self.post("/v1/profiles/import?profile_id=http-copy", raw=archive)
        self.assertEqual(imported["profile_id"], "http-copy")
        profiles = self.get("/v1/profiles")["profiles"]
        self.assertIn("http-copy", [p["profile_id"] for p in profiles])

    def test_state_endpoints_round_trip(self) -> None:
        session = self.post("/v1/sessions", {"profile_id": "state-demo"})
        sid = session["session_id"]
        self.post(f"/v1/sessions/{sid}/goto", {"url": f"http://127.0.0.1:{self.fixture_port}/index.html"})
        self.post(f"/v1/sessions/{sid}/act", {"actions": [{"type": "fill", "selector": "#q", "text": "state"}]})
        closed = urllib.request.Request(self.url(f"/v1/sessions/{sid}"), method="DELETE")
        with urllib.request.urlopen(closed, timeout=20) as r:
            r.read()

        state = self.get("/v1/profiles/state-demo/state")
        self.assertIn("cookies", state)
        self.assertIn("origins", state)

        body = json.dumps(state).encode()
        req = urllib.request.Request(self.url("/v1/profiles/state-copy/state"), data=body, method="PUT", headers={"content-type": "application/json"})
        with urllib.request.urlopen(req, timeout=30) as r:
            applied = json.load(r)
        self.assertEqual(applied["profile_id"], "state-copy")


class AuthHttpApiTest(unittest.TestCase):
    TOKEN = "test-http-secret"

    @classmethod
    def setUpClass(cls) -> None:
        cls.home = tempfile.TemporaryDirectory()
        cls.port = free_port()
        env = dict(
            os.environ,
            BROWSER_WORKER_HOME=cls.home.name,
            BROWSER_WORKER_HTTP_TOKEN=cls.TOKEN,
            PYTHONUNBUFFERED="1",
        )
        cls.proc = subprocess.Popen(
            [sys.executable, "-m", "uvicorn", "browser_worker.http_api:app", "--host", "127.0.0.1", "--port", str(cls.port), "--log-level", "warning"],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        deadline = time.time() + 30
        while time.time() < deadline:
            try:
                cls.get("/health", cls.TOKEN)
                return
            except Exception:
                time.sleep(0.3)
        raise RuntimeError("authenticated worker did not start")

    @classmethod
    def tearDownClass(cls) -> None:
        cls.proc.terminate()
        try:
            cls.proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            cls.proc.kill()
        cls.home.cleanup()

    @classmethod
    def url(cls, path: str) -> str:
        return f"http://127.0.0.1:{cls.port}{path}"

    @classmethod
    def get(cls, path: str, token: str | None = None):
        headers = {"Authorization": f"Bearer {token}"} if token is not None else {}
        req = urllib.request.Request(cls.url(path), headers=headers)
        with urllib.request.urlopen(req, timeout=10) as response:
            return json.load(response)

    def test_bearer_token_protects_http_surface(self) -> None:
        with self.assertRaises(urllib.error.HTTPError) as missing:
            self.get("/health")
        self.assertEqual(missing.exception.code, 401)
        self.assertEqual(missing.exception.headers.get("WWW-Authenticate"), "Bearer")

        with self.assertRaises(urllib.error.HTTPError) as wrong:
            self.get("/health", "wrong")
        self.assertEqual(wrong.exception.code, 401)

        health = self.get("/health", self.TOKEN)
        self.assertTrue(health["ok"])


if __name__ == "__main__":
    unittest.main()
