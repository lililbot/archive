# Browser Worker v0

A browser execution layer whose profiles belong to us, exposed over HTTP and MCP.
Protocol and design rationale: [`PROTOCOL.md`](PROTOCOL.md).

## Install

```bash
pip install .
python -m playwright install chromium    # or point at a system Chromium
```

## Run

HTTP API:

```bash
agent-browser http --host 127.0.0.1 --port 8787
```

MCP stdio (for hosts that speak MCP):

```bash
agent-browser mcp
```

The source-tree module forms remain available when useful:

```bash
uvicorn browser_worker.http_api:app --host 127.0.0.1 --port 8787
python -m browser_worker.mcp_stdio
```

## Environment

| Variable | Default | Meaning |
| --- | --- | --- |
| `BROWSER_WORKER_HOME` | `~/.browser-worker` | root for `profiles/` and `locks/` |
| `BROWSER_WORKER_HEADLESS` | `1` | launch headless |
| `BROWSER_WORKER_NO_SANDBOX` | unset | opt in to `--no-sandbox`; only for containers that cannot run Chromium's sandbox (root, no user namespaces) |
| `BROWSER_WORKER_CHROMIUM_ARGS` | — | extra Chromium flags, space separated |
| `BROWSER_WORKER_ACTION_TIMEOUT_MS` | `15000` | default per-action timeout |
| `BROWSER_WORKER_HTTP_TOKEN` | unset | when set, every HTTP request must send this value as a Bearer token |

`agent-browser http` binds only to loopback by default. Local loopback use remains
zero-config when no HTTP token is set. A non-loopback bind is refused unless
`BROWSER_WORKER_HTTP_TOKEN` is configured; the only bypass is the explicit
`--allow-unauthenticated-remote` flag, which is intentionally unsafe.

For an authenticated remote bind:

```bash
export BROWSER_WORKER_HTTP_TOKEN="$(python -c 'import secrets; print(secrets.token_urlsafe(32))')"
agent-browser http --host 0.0.0.0 --port 8787
curl -H "Authorization: Bearer $BROWSER_WORKER_HTTP_TOKEN" http://127.0.0.1:8787/health
```

The token is read from the environment rather than a command-line argument so it
is not exposed in the process list. Network encryption is still the deployment
layer's job: use TLS/tunneling when requests cross an untrusted network.

## Quick check

```bash
curl -s localhost:8787/health
sid=$(curl -s -X POST localhost:8787/v1/sessions -H 'content-type: application/json' -d '{"profile_id":"demo"}' | jq -r .session_id)
curl -s -X POST localhost:8787/v1/sessions/$sid/goto -H 'content-type: application/json' -d '{"url":"https://example.com"}'
curl -s -X POST localhost:8787/v1/sessions/$sid/extract -H 'content-type: application/json' -d '{"mode":"text"}' | jq -r .value
curl -s -X DELETE localhost:8787/v1/sessions/$sid
curl -s localhost:8787/v1/profiles/demo/state -o demo.state.json    # portable: cookies + localStorage
curl -s -X POST localhost:8787/v1/profiles/demo/export -o demo.profile.tar.gz  # raw backup, same host only
```

## Tests

```bash
python -m unittest discover -s tests -t .
```

The suite drives a real Chromium: 36 tests. It covers lock ownership and stale
lock reclamation, refusal to write over a live profile, raw-archive round-trip
and unsafe-archive rejection, portable `storage_state` round-trip (persistent cookies, session
cookies and localStorage) into a different home directory, including a causal
check that the profile-local state file is what keeps a session cookie alive,
that a logout is not resurrected by that file, that a failed snapshot removes the
file rather than leaving stale auth replayable, and that a rejected import leaves
the previous state untouched, navigation/actions/extraction, HTTP Bearer auth and
remote-bind safety, the HTTP contract, and the MCP stdio handshake. One test
asserts that the declared tool list and the dispatch table cannot drift apart,
because a registered handler that `tools/list` never advertises is invisible to
every MCP client.

Chromium's sandbox cannot start as root without user namespaces, so the suite
sets `BROWSER_WORKER_NO_SANDBOX=1` itself; the worker default stays sandboxed.

## Status

v0 covers execution, not reasoning: it does not plan, does not call an LLM, and
does not claim stealth, CAPTCHA solving or proxy rotation.
