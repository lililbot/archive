"""Browser Worker: a self-owned browser execution layer for agents."""

__version__ = "0.1.0"
