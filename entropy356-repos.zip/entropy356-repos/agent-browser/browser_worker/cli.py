"""Installed command-line entrypoint for agent-browser."""

from __future__ import annotations

import argparse
import ipaddress

from . import __version__, config


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="agent-browser")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    commands = parser.add_subparsers(dest="command", required=True)

    http = commands.add_parser("http", help="run the HTTP API")
    http.add_argument("--host", default="127.0.0.1", help="bind host (default: 127.0.0.1)")
    http.add_argument("--port", type=int, default=8787, help="bind port (default: 8787)")
    http.add_argument("--log-level", default="info", help="uvicorn log level (default: info)")
    http.add_argument(
        "--allow-unauthenticated-remote",
        action="store_true",
        help="allow a non-loopback bind without BROWSER_WORKER_HTTP_TOKEN (unsafe)",
    )

    commands.add_parser("mcp", help="run the MCP stdio server")
    return parser


def is_loopback_host(host: str) -> bool:
    normalized = host.strip().lower()
    if normalized == "localhost":
        return True
    try:
        return ipaddress.ip_address(normalized).is_loopback
    except ValueError:
        return False


def validate_http_bind(host: str, allow_unauthenticated_remote: bool = False) -> None:
    if is_loopback_host(host) or config.http_token() is not None or allow_unauthenticated_remote:
        return
    raise ValueError(
        "refusing unauthenticated non-loopback HTTP bind; set "
        "BROWSER_WORKER_HTTP_TOKEN or pass --allow-unauthenticated-remote explicitly"
    )


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    if args.command == "http":
        try:
            validate_http_bind(args.host, args.allow_unauthenticated_remote)
        except ValueError as exc:
            parser.error(str(exc))

        import uvicorn

        uvicorn.run(
            "browser_worker.http_api:app",
            host=args.host,
            port=args.port,
            log_level=args.log_level,
        )
        return

    from .mcp_stdio import serve

    serve()


if __name__ == "__main__":
    main()
