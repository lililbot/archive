"""HTTP surface: the platform-neutral contract agents use.

Design notes are in PROTOCOL.md.
"""

from __future__ import annotations

import secrets
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from . import config
from .profiles import ProfileBusy, ProfileError
from .service import BrowserWorker, WorkerError

worker = BrowserWorker()


@asynccontextmanager
async def lifespan(app: FastAPI):
    await worker.start()
    try:
        yield
    finally:
        await worker.stop()


app = FastAPI(title="browser-worker", version="0.1.0", lifespan=lifespan)


@app.middleware("http")
async def bearer_auth(request: Request, call_next):
    expected = config.http_token()
    if expected is not None:
        scheme, separator, presented = request.headers.get("authorization", "").partition(" ")
        valid = (
            separator == " "
            and scheme.lower() == "bearer"
            and bool(presented)
            and secrets.compare_digest(presented, expected)
        )
        if not valid:
            return JSONResponse(
                status_code=401,
                content={"detail": "unauthorized"},
                headers={"WWW-Authenticate": "Bearer"},
            )
    return await call_next(request)


def _fail(exc: Exception) -> HTTPException:
    if isinstance(exc, ProfileBusy):
        return HTTPException(status_code=409, detail=str(exc))
    if isinstance(exc, ProfileError):
        return HTTPException(status_code=400, detail=str(exc))
    if isinstance(exc, WorkerError):
        code = 404 if "unknown session" in str(exc) else 409
        return HTTPException(status_code=code, detail=str(exc))
    return HTTPException(status_code=500, detail=f"{type(exc).__name__}: {exc}")


# -- models ---------------------------------------------------------------
class SessionCreate(BaseModel):
    profile_id: str | None = None
    headless: bool | None = None
    force: bool = False


class Goto(BaseModel):
    url: str
    wait_until: str = "load"
    timeout_ms: int | None = None


class Act(BaseModel):
    actions: list[dict[str, Any]] = Field(default_factory=list)


class Extract(BaseModel):
    selector: str | None = None
    mode: str = "text"


class Screenshot(BaseModel):
    full_page: bool = False


# -- system ---------------------------------------------------------------
@app.get("/health")
async def health() -> dict[str, Any]:
    return {
        "ok": True,
        "sessions": len(await worker.list_sessions()),
        "profiles": len(worker.store.list()),
    }


# -- sessions -------------------------------------------------------------
@app.post("/v1/sessions")
async def create_session(body: SessionCreate) -> dict[str, Any]:
    try:
        return await worker.create_session(body.profile_id, body.headless, body.force)
    except Exception as exc:
        raise _fail(exc) from exc


@app.get("/v1/sessions")
async def list_sessions() -> dict[str, Any]:
    return {"sessions": await worker.list_sessions()}


@app.get("/v1/sessions/{sid}")
async def get_session(sid: str) -> dict[str, Any]:
    try:
        return await worker.get(sid).descriptor()
    except Exception as exc:
        raise _fail(exc) from exc


@app.delete("/v1/sessions/{sid}")
async def close_session(sid: str) -> dict[str, Any]:
    try:
        return await worker.close_session(sid)
    except Exception as exc:
        raise _fail(exc) from exc


@app.post("/v1/sessions/{sid}/goto")
async def goto(sid: str, body: Goto) -> dict[str, Any]:
    try:
        return await worker.goto(sid, body.url, body.wait_until, body.timeout_ms)
    except Exception as exc:
        raise _fail(exc) from exc


@app.post("/v1/sessions/{sid}/act")
async def act(sid: str, body: Act) -> dict[str, Any]:
    try:
        return await worker.act(sid, body.actions)
    except Exception as exc:
        raise _fail(exc) from exc


@app.post("/v1/sessions/{sid}/extract")
async def extract(sid: str, body: Extract) -> dict[str, Any]:
    try:
        return await worker.extract(sid, body.selector, body.mode)
    except Exception as exc:
        raise _fail(exc) from exc


@app.post("/v1/sessions/{sid}/screenshot")
async def screenshot(sid: str, body: Screenshot) -> Response:
    try:
        data = await worker.screenshot(sid, body.full_page)
    except Exception as exc:
        raise _fail(exc) from exc
    return Response(content=data, media_type="image/png")


# -- profiles -------------------------------------------------------------
@app.get("/v1/profiles")
async def list_profiles() -> dict[str, Any]:
    return {"profiles": worker.store.list()}


@app.post("/v1/profiles")
async def create_profile(body: SessionCreate) -> dict[str, Any]:
    try:
        pid = worker.store.ensure(body.profile_id)
        return worker.store.info(pid)
    except Exception as exc:
        raise _fail(exc) from exc


@app.get("/v1/profiles/{pid}/state")
async def export_state(pid: str) -> dict[str, Any]:
    try:
        return await worker.export_profile_state(pid)
    except Exception as exc:
        raise _fail(exc) from exc


@app.put("/v1/profiles/{pid}/state", responses={400: {"description": "state is not a storage_state object"}})
async def import_state(pid: str, request: Request) -> dict[str, Any]:
    payload = await request.json()
    try:
        return await worker.import_profile_state(pid, payload)
    except Exception as exc:
        raise _fail(exc) from exc


@app.delete("/v1/profiles/{pid}")
async def delete_profile(pid: str) -> dict[str, Any]:
    try:
        worker.store.delete(pid)
        return {"profile_id": pid, "deleted": True}
    except Exception as exc:
        raise _fail(exc) from exc


@app.post("/v1/profiles/{pid}/export")
async def export_profile(pid: str, force: bool = False) -> Response:
    try:
        data = worker.export_profile(pid, force=force)
    except Exception as exc:
        raise _fail(exc) from exc
    return Response(
        content=data,
        media_type="application/gzip",
        headers={"content-disposition": f'attachment; filename="{pid}.profile.tar.gz"'},
    )


@app.post("/v1/profiles/import", responses={400: {"description": "empty or malformed profile archive"}})
async def import_profile(request: Request, profile_id: str | None = None) -> dict[str, Any]:
    payload = await request.body()
    if not payload:
        raise HTTPException(status_code=400, detail="empty body; send a profile archive")
    try:
        pid = worker.store.import_(payload, profile_id)
        return worker.store.info(pid)
    except Exception as exc:
        raise _fail(exc) from exc
