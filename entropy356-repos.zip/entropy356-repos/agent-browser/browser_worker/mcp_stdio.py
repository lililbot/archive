"""Minimal MCP stdio facade over the same worker.

No SDK dependency: newline-delimited JSON-RPC 2.0, tools only. The HTTP API
remains the canonical surface; this adapter exists so MCP hosts can call the
worker without a separate integration.
"""

from __future__ import annotations

import asyncio
import base64
import inspect
import json
import sys
from typing import Any, Callable

from .service import BrowserWorker

PROTOCOL_VERSION = "2025-06-18"

ToolHandler = Callable[[dict[str, Any]], Any]

TOOLS: list[dict[str, Any]] = [
    {
        "name": "browser_session_create",
        "description": "Create a browser session bound to a durable profile. Omit profile_id to allocate a new profile.",
        "inputSchema": {
            "type": "object",
            "properties": {"profile_id": {"type": "string"}, "headless": {"type": "boolean"}, "force": {"type": "boolean"}},
        },
    },
    {
        "name": "browser_session_close",
        "description": "Close a session and flush its profile to disk.",
        "inputSchema": {"type": "object", "properties": {"session_id": {"type": "string"}}, "required": ["session_id"]},
    },
    {"name": "browser_session_list", "description": "List live sessions.", "inputSchema": {"type": "object", "properties": {}}},
    {
        "name": "browser_goto",
        "description": "Navigate the session's page.",
        "inputSchema": {
            "type": "object",
            "properties": {"session_id": {"type": "string"}, "url": {"type": "string"}, "wait_until": {"type": "string"}},
            "required": ["session_id", "url"],
        },
    },
    {
        "name": "browser_act",
        "description": "Run ordered actions: goto, click, fill, press, select, wait_for, wait, scroll, reload.",
        "inputSchema": {
            "type": "object",
            "properties": {"session_id": {"type": "string"}, "actions": {"type": "array", "items": {"type": "object"}}},
            "required": ["session_id", "actions"],
        },
    },
    {
        "name": "browser_extract",
        "description": "Extract text, html, or links from the page or a selector.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "session_id": {"type": "string"},
                "selector": {"type": "string"},
                "mode": {"type": "string", "enum": ["text", "html", "links"]},
            },
            "required": ["session_id"],
        },
    },
    {
        "name": "browser_screenshot",
        "description": "Capture a PNG screenshot, returned as base64.",
        "inputSchema": {
            "type": "object",
            "properties": {"session_id": {"type": "string"}, "full_page": {"type": "boolean"}},
            "required": ["session_id"],
        },
    },
    {
        "name": "browser_profile_list",
        "description": "List durable profiles with size and lock state.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "browser_profile_export",
        "description": "Export a profile as a base64 tar.gz archive. Close its session first.",
        "inputSchema": {
            "type": "object",
            "properties": {"profile_id": {"type": "string"}, "force": {"type": "boolean"}},
            "required": ["profile_id"],
        },
    },
    {
        "name": "browser_profile_import",
        "description": "Import a profile archive previously produced by browser_profile_export.",
        "inputSchema": {
            "type": "object",
            "properties": {"archive_base64": {"type": "string"}, "profile_id": {"type": "string"}},
            "required": ["archive_base64"],
        },
    },
    {
        "name": "browser_profile_state_export",
        "description": "Export portable auth state (cookies + per-origin localStorage) as a storage_state object.",
        "inputSchema": {"type": "object", "properties": {"profile_id": {"type": "string"}}, "required": ["profile_id"]},
    },
    {
        "name": "browser_profile_state_import",
        "description": "Import portable auth state previously produced by browser_profile_state_export.",
        "inputSchema": {
            "type": "object",
            "properties": {"profile_id": {"type": "string"}, "state": {"type": "object"}},
            "required": ["profile_id", "state"],
        },
    },
]

NOTIFICATIONS = {"notifications/initialized", "notifications/cancelled"}


def build_handlers(worker: BrowserWorker) -> dict[str, ToolHandler]:
    async def session_create(args: dict[str, Any]) -> Any:
        return await worker.create_session(args.get("profile_id"), args.get("headless"), bool(args.get("force", False)))

    async def session_close(args: dict[str, Any]) -> Any:
        return await worker.close_session(args["session_id"])

    async def session_list(args: dict[str, Any]) -> Any:
        return {"sessions": await worker.list_sessions()}

    async def goto(args: dict[str, Any]) -> Any:
        return await worker.goto(args["session_id"], args["url"], args.get("wait_until", "load"))

    async def act(args: dict[str, Any]) -> Any:
        return await worker.act(args["session_id"], args.get("actions", []))

    async def extract(args: dict[str, Any]) -> Any:
        return await worker.extract(args["session_id"], args.get("selector"), args.get("mode", "text"))

    async def screenshot(args: dict[str, Any]) -> Any:
        data = await worker.screenshot(args["session_id"], bool(args.get("full_page", False)))
        return {"format": "png", "base64": base64.b64encode(data).decode()}

    def profile_list(args: dict[str, Any]) -> Any:
        return {"profiles": worker.store.list()}

    async def profile_state_export(args: dict[str, Any]) -> Any:
        return await worker.export_profile_state(args["profile_id"])

    async def profile_state_import(args: dict[str, Any]) -> Any:
        return await worker.import_profile_state(args["profile_id"], args.get("state") or {})

    def profile_export(args: dict[str, Any]) -> Any:
        data = worker.export_profile(args["profile_id"], force=bool(args.get("force", False)))
        return {"profile_id": args["profile_id"], "format": "tar.gz", "base64": base64.b64encode(data).decode()}

    def profile_import(args: dict[str, Any]) -> Any:
        raw = base64.b64decode(args["archive_base64"])
        pid = worker.store.import_(raw, args.get("profile_id"))
        return worker.store.info(pid)

    return {
        "browser_session_create": session_create,
        "browser_session_close": session_close,
        "browser_session_list": session_list,
        "browser_goto": goto,
        "browser_act": act,
        "browser_extract": extract,
        "browser_screenshot": screenshot,
        "browser_profile_list": profile_list,
        "browser_profile_export": profile_export,
        "browser_profile_state_export": profile_state_export,
        "browser_profile_state_import": profile_state_import,
        "browser_profile_import": profile_import,
    }


def _text(payload: Any) -> dict[str, Any]:
    return {"content": [{"type": "text", "text": json.dumps(payload, ensure_ascii=False)}]}


def _error(message: str) -> dict[str, Any]:
    return {"content": [{"type": "text", "text": message}], "isError": True}


def _call_tool(handlers: dict[str, ToolHandler], loop: asyncio.AbstractEventLoop, params: dict[str, Any]) -> dict[str, Any]:
    handler = handlers.get(params.get("name", ""))
    if handler is None:
        return _error("unknown tool")
    try:
        value = handler(params.get("arguments") or {})
        if inspect.isawaitable(value):
            value = loop.run_until_complete(value)
        return _text(value)
    except Exception as exc:
        return _error(f"{type(exc).__name__}: {exc}")


def _dispatch(
    handlers: dict[str, ToolHandler],
    loop: asyncio.AbstractEventLoop,
    request: dict[str, Any],
) -> dict[str, Any] | None:
    method = request.get("method")
    if method in NOTIFICATIONS:
        return None
    if method == "initialize":
        return {
            "protocolVersion": request.get("params", {}).get("protocolVersion", PROTOCOL_VERSION),
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "browser-worker", "version": "0.1.0"},
        }
    if method == "ping":
        return {}
    if method == "tools/list":
        return {"tools": TOOLS}
    if method == "tools/call":
        return _call_tool(handlers, loop, request.get("params") or {})
    return None


def serve() -> None:
    worker = BrowserWorker()
    handlers = build_handlers(worker)
    loop = asyncio.new_event_loop()
    loop.run_until_complete(worker.start())
    try:
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            try:
                request = json.loads(line)
            except json.JSONDecodeError:
                continue
            rid = request.get("id")
            result = _dispatch(handlers, loop, request)
            if result is None:
                if request.get("method") in NOTIFICATIONS:
                    continue
                error = {"code": -32601, "message": f"unknown method: {request.get('method')}"}
                print(json.dumps({"jsonrpc": "2.0", "id": rid, "error": error}), flush=True)
                continue
            print(json.dumps({"jsonrpc": "2.0", "id": rid, "result": result}), flush=True)
    finally:
        loop.run_until_complete(worker.stop())
        loop.close()


if __name__ == "__main__":
    serve()
