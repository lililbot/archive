"""Session service: one Chromium context per session, profiles owned on disk."""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable

from playwright.async_api import BrowserContext, Page, Playwright, async_playwright

from . import config
from .profiles import ProfileBusy, ProfileStore


class WorkerError(RuntimeError):
    pass


# Chromium drops session cookies on shutdown, so a state file replays what the
# profile itself cannot keep. It lives inside the profile directory so deleting
# the profile deletes it too.
STATE_FILE = "browser-worker-state.json"


@dataclass
class Session:
    id: str
    profile_id: str
    context: BrowserContext
    page: Page
    created_at: float = field(default_factory=time.time)
    headless: bool = True

    async def descriptor(self) -> dict[str, Any]:
        return {
            "session_id": self.id,
            "profile_id": self.profile_id,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(self.created_at)),
            "headless": self.headless,
            "url": self.page.url if not self.page.is_closed() else None,
            "title": await self._title(),
        }

    async def _title(self) -> str | None:
        try:
            return await self.page.title() if not self.page.is_closed() else None
        except Exception:
            return None


# -- action handlers ------------------------------------------------------
# One function per action type keeps the loop in BrowserWorker.act free of
# branching, which is also what makes the surface easy to extend.

ActionHandler = Callable[[Page, dict[str, Any], int], Awaitable[dict[str, Any]]]


async def _act_goto(page: Page, action: dict[str, Any], timeout: int) -> dict[str, Any]:
    await page.goto(action["url"], wait_until=action.get("wait_until", "load"), timeout=timeout)
    return {"url": page.url}


async def _act_click(page: Page, action: dict[str, Any], timeout: int) -> dict[str, Any]:
    await page.click(action["selector"], timeout=timeout)
    return {"selector": action["selector"]}


async def _act_fill(page: Page, action: dict[str, Any], timeout: int) -> dict[str, Any]:
    await page.fill(action["selector"], action.get("text", ""), timeout=timeout)
    return {"selector": action["selector"]}


async def _act_press(page: Page, action: dict[str, Any], timeout: int) -> dict[str, Any]:
    await page.press(action["selector"], action["key"], timeout=timeout)
    return {"key": action["key"]}


async def _act_select(page: Page, action: dict[str, Any], timeout: int) -> dict[str, Any]:
    await page.select_option(action["selector"], action["value"], timeout=timeout)
    return {"value": action["value"]}


async def _act_wait_for(page: Page, action: dict[str, Any], timeout: int) -> dict[str, Any]:
    await page.wait_for_selector(action["selector"], state=action.get("state", "visible"), timeout=timeout)
    return {"selector": action["selector"]}


async def _act_wait(page: Page, action: dict[str, Any], timeout: int) -> dict[str, Any]:
    ms = int(action.get("ms", 500))
    await asyncio.sleep(ms / 1000)
    return {"ms": ms}


async def _act_scroll(page: Page, action: dict[str, Any], timeout: int) -> dict[str, Any]:
    if action.get("selector"):
        await page.locator(action["selector"]).scroll_into_view_if_needed(timeout=timeout)
        return {"selector": action["selector"]}
    dy = int(action.get("dy", 600))
    await page.mouse.wheel(0, dy)
    return {"dy": dy}


async def _act_reload(page: Page, action: dict[str, Any], timeout: int) -> dict[str, Any]:
    await page.reload(wait_until=action.get("wait_until", "load"), timeout=timeout)
    return {"url": page.url}


ACTIONS: dict[str, ActionHandler] = {
    "goto": _act_goto,
    "click": _act_click,
    "fill": _act_fill,
    "press": _act_press,
    "select": _act_select,
    "wait_for": _act_wait_for,
    "wait": _act_wait,
    "scroll": _act_scroll,
    "reload": _act_reload,
}


class BrowserWorker:
    """Owns browser sessions. Profiles live under BROWSER_WORKER_HOME/profiles."""

    def __init__(self, store: ProfileStore | None = None) -> None:
        self.store = store or ProfileStore()
        self._playwright: Playwright | None = None
        self._sessions: dict[str, Session] = {}
        self._start_lock = asyncio.Lock()

    # -- lifecycle --------------------------------------------------------
    async def start(self) -> None:
        async with self._start_lock:
            if self._playwright is None:
                self._playwright = await async_playwright().start()

    async def stop(self) -> None:
        while self._sessions:
            sid = next(iter(self._sessions))
            try:
                await self.close_session(sid)
            except Exception:
                self._sessions.pop(sid, None)
        if self._playwright is not None:
            await self._playwright.stop()
            self._playwright = None

    # -- sessions ---------------------------------------------------------
    async def create_session(
        self,
        profile_id: str | None = None,
        headless: bool | None = None,
        force: bool = False,
    ) -> dict[str, Any]:
        await self.start()
        assert self._playwright is not None
        pid = self.store.ensure(profile_id)
        sid = f"s-{uuid.uuid4().hex[:12]}"
        use_headless = config.headless() if headless is None else headless
        try:
            self._acquire(pid, sid, force)
        except ProfileBusy as exc:
            raise WorkerError(str(exc)) from exc

        try:
            context = await self._playwright.chromium.launch_persistent_context(
                user_data_dir=str(self.store.path(pid)),
                headless=use_headless,
                args=config.chromium_args(),
                viewport={"width": 1280, "height": 800},
            )
            page = context.pages[0] if context.pages else await context.new_page()
        except Exception as exc:
            self.store.unlock(pid, sid)
            raise WorkerError(f"failed to launch browser: {exc}") from exc

        session = Session(id=sid, profile_id=pid, context=context, page=page, headless=use_headless)
        self._sessions[sid] = session
        await self._replay_state(session)
        return await session.descriptor()

    def _acquire(self, pid: str, sid: str, force: bool) -> None:
        """Take the profile lock, reclaiming a dead owner's lock when possible."""
        try:
            self.store.lock(pid, sid)
            return
        except ProfileBusy:
            if self.store.reclaim_stale(pid):
                self.store.lock(pid, sid)
                return
            if not force:
                raise
        self.store.unlock(pid)
        self.store.lock(pid, sid)

    def get(self, sid: str) -> Session:
        session = self._sessions.get(sid)
        if session is None:
            raise WorkerError(f"unknown session: {sid}")
        return session

    async def list_sessions(self) -> list[dict[str, Any]]:
        return [await s.descriptor() for s in self._sessions.values()]

    async def close_session(self, sid: str) -> dict[str, Any]:
        session = self.get(sid)
        try:
            await self._snapshot_state(session)
            await session.context.close()
        finally:
            self._sessions.pop(sid, None)
            self.store.unlock(session.profile_id, sid)
        return {"session_id": sid, "closed": True, "profile_id": session.profile_id}

    # -- page actions -----------------------------------------------------
    async def goto(self, sid: str, url: str, wait_until: str = "load", timeout_ms: int | None = None) -> dict[str, Any]:
        session = self.get(sid)
        response = await session.page.goto(url, wait_until=wait_until, timeout=timeout_ms or config.action_timeout_ms())
        return {
            "session_id": sid,
            "url": session.page.url,
            "title": await session.page.title(),
            "status": response.status if response else None,
        }

    async def act(self, sid: str, actions: list[dict[str, Any]]) -> dict[str, Any]:
        session = self.get(sid)
        page = session.page
        done: list[dict[str, Any]] = []

        for index, action in enumerate(actions):
            kind = (action.get("type") or "").lower()
            handler = ACTIONS.get(kind)
            timeout = int(action.get("timeout_ms") or config.action_timeout_ms())
            try:
                if handler is None:
                    raise WorkerError(f"unsupported action: {kind!r}")
                detail = await handler(page, action, timeout)
            except Exception as exc:
                return {
                    "session_id": sid,
                    "ok": False,
                    "completed": done,
                    "failed_index": index,
                    "failed_type": kind,
                    "error": f"{type(exc).__name__}: {exc}".splitlines()[0][:400],
                    "url": page.url,
                }
            done.append({"type": kind, **detail})

        return {"session_id": sid, "ok": True, "completed": done, "url": page.url}

    async def extract(self, sid: str, selector: str | None = None, mode: str = "text") -> dict[str, Any]:
        session = self.get(sid)
        page = session.page
        timeout = config.action_timeout_ms()
        if mode == "links":
            value: Any = await page.eval_on_selector_all(
                selector or "a",
                "els => els.map(e => ({text: (e.innerText||'').trim(), href: e.href}))",
            )
        else:
            target = page.locator(selector) if selector else page.locator("body")
            if mode == "text":
                value = (await target.first.inner_text(timeout=timeout)).strip()
            elif mode == "html":
                value = await target.first.inner_html(timeout=timeout)
            else:
                raise WorkerError(f"unsupported extract mode: {mode!r}")
        return {"session_id": sid, "mode": mode, "selector": selector, "value": value, "url": page.url}

    async def screenshot(self, sid: str, full_page: bool = False) -> bytes:
        session = self.get(sid)
        return await session.page.screenshot(full_page=full_page, type="png")

    # -- portable auth state ---------------------------------------------
    # A raw user-data directory is a backup, not a portable identity: paths,
    # keyrings and Chromium versions differ across machines and OS users.
    # storage_state carries the part that is actually portable — cookies and
    # per-origin localStorage — and is the supported way to move a login.

    async def export_state(self, sid: str) -> dict[str, Any]:
        return await self.get(sid).context.storage_state()

    async def export_profile_state(self, profile_id: str) -> dict[str, Any]:
        live = next((s for s in self._sessions.values() if s.profile_id == profile_id), None)
        if live is not None:
            return await live.context.storage_state()
        created = await self.create_session(profile_id)
        try:
            return await self.get(created["session_id"]).context.storage_state()
        finally:
            await self.close_session(created["session_id"])

    def _state_path(self, profile_id: str) -> Path:
        return self.store.path(profile_id) / STATE_FILE

    async def _snapshot_state(self, session: Session) -> None:
        """Keep the replay file tracking reality, including a logout.

        The failure mode matters more than the happy path: if the snapshot
        cannot be read or written, the old file must not stay behind, because
        it would replay credentials the browser has already dropped. Closing
        still proceeds — a missing replay file is a safe state, a stale one is
        not.
        """
        path = self._state_path(session.profile_id)
        if not path.exists():
            return
        try:
            state = await session.context.storage_state()
        except Exception:
            path.unlink(missing_ok=True)
            return
        try:
            path.write_text(json.dumps(state))
        except OSError:
            path.unlink(missing_ok=True)

    async def _replay_state(self, session: Session) -> None:
        path = self._state_path(session.profile_id)
        if not path.exists():
            return
        try:
            state = json.loads(path.read_text())
        except (OSError, json.JSONDecodeError):
            return
        await self._apply_state(session, state)

    async def _apply_state(self, session: Session, state: dict[str, Any]) -> tuple[int, int]:
        now = time.time()
        cookies = [
            cookie for cookie in state.get("cookies") or []
            if not (isinstance(cookie.get("expires"), (int, float)) and 0 < cookie["expires"] < now)
        ]
        if cookies:
            await session.context.add_cookies(cookies)
        origins = 0
        for origin in state.get("origins") or []:
            url = origin.get("origin")
            if not url:
                continue
            await session.page.goto(url if url.endswith("/") else f"{url}/", wait_until="domcontentloaded")
            items = origin.get("localStorage") or []
            if items:
                await session.page.evaluate(
                    "(items) => { for (const item of items) localStorage.setItem(item.name, item.value); }",
                    items,
                )
            origins += 1
        return len(cookies), origins

    async def import_profile_state(self, profile_id: str, state: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(state, dict) or not isinstance(state.get("cookies"), list):
            raise WorkerError("state must be a storage_state object with a cookies array")
        pid = self.store.ensure(profile_id)
        # Take ownership first: a locked profile must fail before any persistent
        # state is written, otherwise a rejected import still mutates the profile.
        created = await self.create_session(pid)
        sid = created["session_id"]
        session = self.get(sid)
        try:
            self._state_path(pid).write_text(json.dumps(state))
            cookies, origins = await self._apply_state(session, state)
            return {
                "profile_id": pid,
                "cookies": cookies,
                "origins": origins,
                "session_id": sid,
            }
        finally:
            await self.close_session(sid)

    # -- profile passthrough ---------------------------------------------
    def export_profile(self, profile_id: str, force: bool = False) -> bytes:
        if profile_id in {s.profile_id for s in self._sessions.values()} and not force:
            raise ProfileBusy(f"profile {profile_id} has a live session; close it before exporting")
        return self.store.export(profile_id, force=force)
