"""Runtime configuration for the browser worker."""

from __future__ import annotations

import os
from pathlib import Path


def home() -> Path:
    return Path(os.environ.get("BROWSER_WORKER_HOME", str(Path.home() / ".browser-worker"))).expanduser()


def profiles_dir() -> Path:
    root = home() / "profiles"
    root.mkdir(parents=True, exist_ok=True)
    return root


def headless() -> bool:
    return os.environ.get("BROWSER_WORKER_HEADLESS", "1") not in {"0", "false", "False"}


def chromium_args() -> list[str]:
    """Chromium flags for this worker.

    The sandbox is left enabled: passing --no-sandbox disables a real security
    boundary. Containers that cannot satisfy Chromium's sandbox (running as
    root, no user namespaces) must opt in explicitly with
    BROWSER_WORKER_NO_SANDBOX=1.
    """
    args: list[str] = []
    if os.environ.get("BROWSER_WORKER_NO_SANDBOX", "").lower() in {"1", "true", "yes"}:
        args.append("--no-sandbox")
    args.append("--disable-dev-shm-usage")
    extra = os.environ.get("BROWSER_WORKER_CHROMIUM_ARGS", "")
    args.extend(a for a in extra.split() if a)
    return args


def action_timeout_ms() -> int:
    return int(os.environ.get("BROWSER_WORKER_ACTION_TIMEOUT_MS", "15000"))


def http_token() -> str | None:
    """Bearer token protecting the HTTP surface, or None for local-only use."""
    token = os.environ.get("BROWSER_WORKER_HTTP_TOKEN", "").strip()
    return token or None
