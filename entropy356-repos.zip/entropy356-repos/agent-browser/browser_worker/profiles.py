"""Profile store: the browser's durable identity, owned by this worker.

A profile is a Chromium user-data directory kept under BROWSER_WORKER_HOME.
Nothing here depends on a vendor: a profile can be exported as a portable
archive and re-imported on another machine.
"""

from __future__ import annotations

import io
import json
import os
import re
import shutil
import socket
import tarfile
import time
import uuid
from pathlib import Path
from typing import Any

from . import config

ID_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,62}$")
MANIFEST = "manifest.json"
FORMAT = 1


class ProfileError(RuntimeError):
    pass


class ProfileBusy(ProfileError):
    pass


class ProfileStore:
    def __init__(self, root: Path | None = None, lock_dir: Path | None = None) -> None:
        self.root = Path(root) if root else config.profiles_dir()
        self.root.mkdir(parents=True, exist_ok=True)
        self.lock_dir = Path(lock_dir) if lock_dir else config.home() / "locks"
        self.lock_dir.mkdir(parents=True, exist_ok=True)

    # -- identity ---------------------------------------------------------
    @staticmethod
    def validate_id(profile_id: str) -> str:
        if not ID_RE.match(profile_id or ""):
            raise ProfileError(f"invalid profile id: {profile_id!r}")
        return profile_id

    def new_id(self) -> str:
        return f"p-{uuid.uuid4().hex[:12]}"

    def path(self, profile_id: str) -> Path:
        return self.root / self.validate_id(profile_id)

    def ensure(self, profile_id: str | None = None) -> str:
        pid = self.validate_id(profile_id) if profile_id is not None else self.new_id()
        self.path(pid).mkdir(parents=True, exist_ok=True)
        return pid

    def exists(self, profile_id: str) -> bool:
        try:
            return self.path(profile_id).is_dir()
        except ProfileError:
            return False

    # -- locking ----------------------------------------------------------
    # A lock records who holds the profile, on which host, from which process.
    # Without that an unclean exit leaves a file nobody can attribute, and the
    # profile is stranded for good.

    def _lock_path(self, profile_id: str) -> Path:
        return self.lock_dir / f"{self.validate_id(profile_id)}.lock"

    def lock(self, profile_id: str, holder: str) -> None:
        path = self._lock_path(profile_id)
        if path.exists():
            info = self.lock_info(profile_id) or {}
            owner = info.get("session_id") or "another process"
            host = info.get("host")
            where = f"{owner} on {host}" if host else str(owner)
            raise ProfileBusy(
                f"profile {profile_id} is in use by {where}; close it, "
                "or pass force=true after confirming the owner is really gone"
            )
        record = {
            "session_id": holder,
            "pid": os.getpid(),
            "host": socket.gethostname(),
            "created_at": round(time.time(), 3),
        }
        path.write_text(json.dumps(record))

    def lock_info(self, profile_id: str) -> dict[str, Any] | None:
        path = self._lock_path(profile_id)
        if not path.exists():
            return None
        raw = path.read_text().strip()
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return {"session_id": raw, "pid": None, "host": None, "created_at": None}
        return parsed if isinstance(parsed, dict) else {"session_id": str(parsed)}

    def unlock(self, profile_id: str, holder: str | None = None) -> None:
        info = self.lock_info(profile_id)
        if info is None:
            return
        if holder and info.get("session_id") != holder:
            return
        self._lock_path(profile_id).unlink(missing_ok=True)

    def is_locked(self, profile_id: str) -> bool:
        return self._lock_path(profile_id).exists()

    def reclaim_stale(self, profile_id: str) -> bool:
        """Drop a lock whose owning process no longer exists on this host.

        Locks held by another host are never reclaimed automatically: pid
        liveness means nothing there, and guessing would let two Chromium
        processes write one profile.
        """
        info = self.lock_info(profile_id)
        if info is None:
            return False
        pid = info.get("pid")
        if info.get("host") != socket.gethostname() or not isinstance(pid, int):
            return False
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            self._lock_path(profile_id).unlink(missing_ok=True)
            return True
        except PermissionError:
            return False
        return False

    def _staleness(self, profile_id: str) -> dict[str, Any]:
        info = self.lock_info(profile_id)
        if info is None:
            return {"locked": False}
        return {"locked": True, "holder": info}

    # -- inspection -------------------------------------------------------
    def info(self, profile_id: str) -> dict[str, Any]:
        path = self.path(profile_id)
        if not path.is_dir():
            raise ProfileError(f"unknown profile: {profile_id}")
        size = sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
        return {
            "profile_id": profile_id,
            "bytes": size,
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(path.stat().st_mtime)),
            **self._staleness(profile_id),
        }

    def list(self) -> list[dict[str, Any]]:
        out = []
        for entry in sorted(self.root.iterdir()):
            if entry.is_dir() and ID_RE.match(entry.name):
                try:
                    out.append(self.info(entry.name))
                except ProfileError:
                    continue
        return out

    # -- export / import --------------------------------------------------
    def export(self, profile_id: str, *, force: bool = False) -> bytes:
        path = self.path(profile_id)
        if not path.is_dir():
            raise ProfileError(f"unknown profile: {profile_id}")
        if self.is_locked(profile_id) and not force:
            raise ProfileBusy(f"profile {profile_id} has a live session; close it before exporting")

        manifest = {
            "format": FORMAT,
            "profile_id": profile_id,
            "exported_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        buffer = io.BytesIO()
        with tarfile.open(fileobj=buffer, mode="w:gz") as tar:
            payload = json.dumps(manifest, ensure_ascii=False).encode()
            info = tarfile.TarInfo(MANIFEST)
            info.size = len(payload)
            info.mtime = int(time.time())
            tar.addfile(info, io.BytesIO(payload))
            for entry in sorted(path.rglob("*")):
                arcname = f"profile/{entry.relative_to(path)}"
                tar.add(entry, arcname=arcname, recursive=False)
        return buffer.getvalue()

    def import_(self, archive: bytes, profile_id: str | None = None) -> str:
        with tarfile.open(fileobj=io.BytesIO(archive), mode="r:gz") as tar:
            members = tar.getmembers()
            _reject_unsafe_members(members)
            _read_manifest(tar, members)

            pid = self.validate_id(profile_id) if profile_id is not None else self.new_id()
            target = self.path(pid)
            if target.exists() and self.is_locked(pid):
                raise ProfileBusy(
                    f"refusing to import over profile {pid}: it has a live session; "
                    "close it first, or import under a different id"
                )
            staging = target.with_suffix(".importing")
            if staging.exists():
                shutil.rmtree(staging)
            staging.mkdir(parents=True)
            try:
                _materialize(tar, members, staging)
            except Exception:
                shutil.rmtree(staging, ignore_errors=True)
                raise
            if target.exists():
                shutil.rmtree(target)
            os.replace(staging, target)
            return pid

    def delete(self, profile_id: str) -> None:
        if self.is_locked(profile_id):
            raise ProfileBusy(f"profile {profile_id} has a live session")
        path = self.path(profile_id)
        if path.is_dir():
            shutil.rmtree(path)


def _reject_unsafe_members(members: list[tarfile.TarInfo]) -> None:
    for member in members:
        name = member.name.lstrip("./")
        if name.startswith("/") or ".." in Path(name).parts:
            raise ProfileError(f"refusing unsafe archive member: {member.name}")


def _read_manifest(tar: tarfile.TarFile, members: list[tarfile.TarInfo]) -> dict[str, Any]:
    manifest_member = next((m for m in members if m.name.lstrip("./") == MANIFEST), None)
    if manifest_member is None:
        raise ProfileError("archive has no manifest")
    payload = tar.extractfile(manifest_member)
    if payload is None:
        raise ProfileError("manifest is not a regular file")
    manifest = json.loads(payload.read().decode())
    if manifest.get("format") != FORMAT:
        raise ProfileError(f"unsupported profile format: {manifest.get('format')!r}")
    return manifest


def _materialize(tar: tarfile.TarFile, members: list[tarfile.TarInfo], staging: Path) -> None:
    for member in members:
        name = member.name.lstrip("./")
        if not name.startswith("profile/"):
            continue
        relative = name[len("profile/"):]
        if not relative:
            continue
        destination = staging / relative
        if member.isdir():
            destination.mkdir(parents=True, exist_ok=True)
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        source = tar.extractfile(member)
        if source is None:
            continue
        with open(destination, "wb") as handle:
            shutil.copyfileobj(source, handle)
