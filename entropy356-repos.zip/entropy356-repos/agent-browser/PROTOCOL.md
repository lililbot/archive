# Browser Worker protocol v0

A browser execution layer that agents call over HTTP or MCP. The defining
constraint is ownership: the browser state — cookies, local storage, saved
logins — belongs to us and lives on our disk, rather than inside a third-party
execution service. Everything else follows from that, including the honest
limits of what "ours" can promise across machines.

## Why this shape

Three candidate stacks were considered for v0.

| Option | Verdict |
| --- | --- |
| **Playwright + persistent user-data directory** | Chosen. The profile is an ordinary directory we can back up and restore, and no vendor sits in the identity path. |
| **Steel (self-hosted)** | Not the core. Steel is a good session API, but self-hosted it serves one live session per container, and its profile persistence lives inside the Steel server rather than in our storage. Adopting it as the core would put the identity we are trying to own behind another service. It remains a plausible *executor* behind this interface later, when a profile directory can be mounted into it. |
| **Browser Use** | Not in v0. It is a planning/agent loop on top of Playwright; the execution layer should not depend on how a particular model decides to click. It can sit above this API as a client. |

The worker therefore ships one driver — local Chromium via Playwright — and keeps
the session boundary narrow enough that a CDP-based remote executor can be added
without changing the API.

## API surface (HTTP)

All paths are under `/v1`. Bodies are JSON; errors carry a JSON `detail`.
Loopback use is unauthenticated by default. If `BROWSER_WORKER_HTTP_TOKEN` is
set, every HTTP request, including `/health`, must send
`Authorization: Bearer <token>`; invalid or missing credentials return `401`
with `WWW-Authenticate: Bearer`.

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/health` | liveness, live session count, profile count |
| `POST` | `/sessions` | create a session bound to a profile (`profile_id` optional; `force` overrides a lock you have verified is dead) |
| `GET` | `/sessions` | list live sessions |
| `GET` | `/sessions/{id}` | one session descriptor |
| `DELETE` | `/sessions/{id}` | close the session and flush the profile |
| `POST` | `/sessions/{id}/goto` | navigate (`url`, `wait_until`, `timeout_ms`) |
| `POST` | `/sessions/{id}/act` | run ordered actions (see below) |
| `POST` | `/sessions/{id}/extract` | `text`, `html` or `links` from the page or a selector |
| `POST` | `/sessions/{id}/screenshot` | PNG bytes |
| `GET` | `/profiles` | list profiles with size and lock state |
| `POST` | `/profiles` | create an empty profile |
| `GET` | `/profiles/{id}/state` | **portable** auth state: `storage_state` (cookies + per-origin localStorage) |
| `PUT` | `/profiles/{id}/state` | import that state |
| `POST` | `/profiles/{id}/export` | raw `tar.gz` of the user-data directory; `409` while a session holds the profile |
| `POST` | `/profiles/import` | raw `tar.gz` body; refuses to overwrite a profile with a live session |
| `DELETE` | `/profiles/{id}` | delete a profile that is not in use |

### Actions

`POST /act` takes `{"actions": [...]}` and stops at the first failure, returning
`{"ok": false, "completed": [...], "failed_index": n, "failed_type": "...", "error": "..."}`.
Supported types: `goto`, `click`, `fill`, `press`, `select`, `wait_for`, `wait`,
`scroll`, `reload`.

### MCP

`browser_session_create` (with `force`), `browser_session_close`,
`browser_session_list`, `browser_goto`, `browser_act`, `browser_extract`,
`browser_screenshot`, `browser_profile_list`, `browser_profile_export`,
`browser_profile_import`, `browser_profile_state_export`,
`browser_profile_state_import`. Same semantics; binary payloads travel
base64-encoded. The HTTP surface stays canonical — MCP is an adapter over the
same service object.

## Two kinds of profile artefact

These were previously conflated. They are not the same promise.

**Raw archive (`/profiles/{id}/export`)** is a *backup*. It is a tarball of a
Chromium user-data directory: cookies database, local storage, extensions,
cache, and Chromium's own bookkeeping. It restores reliably on the same OS user,
the same Chromium build and a compatible filesystem layout. It is not a portable
identity: paths, keyrings, disk-encryption keys and Chromium schema versions
differ across machines and OS users, and a restored directory can be rejected,
reset, or silently downgraded. Use it to move a profile between two workers you
control, on similar hosts.

**Portable auth state (`/profiles/{id}/state`)** is the supported way to move a
login. It is Playwright's `storage_state`: cookies plus per-origin
`localStorage`, as JSON. It is small, diffable, and independent of Chromium
internals. Import replays cookies through `add_cookies` and writes localStorage
after navigating each origin.

Gaps, stated rather than hidden: IndexedDB, service workers and Cache Storage
are not part of `storage_state`. A site that keeps its session only in IndexedDB
will not survive this path; if that becomes a real need, extend the state format
deliberately rather than assuming the raw archive covers it.

Session-scoped cookies (`Set-Cookie` with no expiry) are dropped by Chromium on a
clean shutdown, so they do not survive inside a raw archive. They are present in
`storage_state`, but applying state once is not enough: the context used to apply
it is closed, and the cookie dies with it.

The state path therefore **persists portable state** as
`profiles/{id}/browser-worker-state.json` and replays it, cookies and
per-origin localStorage, on every session created for that profile. Expired
cookies are skipped at replay time, and the file is **refreshed from the live
context on every close**, so it tracks reality: a logout removes the cookie from
the context, the snapshot overwrites the file, and the next session stays logged
out instead of replaying a stale seed. The file lives inside the profile
directory, so deleting the profile deletes it.

If a snapshot cannot be read or written, the replay file is **removed** instead of
being left as it was: a missing file is a safe state, a stale one would replay
credentials the browser has already dropped. Closing still proceeds.

Import takes profile ownership before writing anything. A locked profile fails
before the replay file is touched, so a rejected import cannot mutate persistent
state.

This is the reason the state path, not the raw archive, is the portability
promise — and it is tested causally: with the file the session survives
export → import → close → reopen, and deleting the file makes the same
sequence fall back to the login page.

## Session and profile semantics

- A lock records `session_id`, `pid`, `host` and `created_at`. A bare filename
  was not enough: an unclean exit left a file nobody could attribute and the
  profile stayed stranded.
- On lock conflict the worker reclaims **only** a lock whose `host` matches this
  machine and whose `pid` no longer exists. A lock from another host is never
  reclaimed automatically — pid liveness means nothing there, and guessing would
  let two Chromium processes write one directory.
- `force=true` exists for the case the operator has verified the owner is gone.
  It is a decision, not a fallback, and it is visible in the request.
- Importing a raw archive over a profile that currently holds a lock is refused
  (`409`), so an import cannot silently replace a live profile's directory.
- Closing a session flushes the profile; `export` refuses while a session holds
  it (`force` for recovery only).
- Archives are `tar.gz` with `manifest.json` first
  (`{"format": 1, "profile_id": ..., "exported_at": ...}`), followed by
  `profile/**`. Import rejects absolute paths, `..` segments and archives without
  a manifest, and stages into a temporary directory before swapping in.
- Sessions are in-process state. Restarting the worker loses live sessions, not
  profiles.

## Security defaults

- Chromium's sandbox stays enabled. `--no-sandbox` disables a real boundary, so
  it is opt-in via `BROWSER_WORKER_NO_SANDBOX=1`, for containers that cannot
  satisfy it (root with no user namespaces). The test suite opts in explicitly
  because CI runs as root.
- `agent-browser http` binds to loopback by default. Loopback can remain
  unauthenticated for local use. Set `BROWSER_WORKER_HTTP_TOKEN` to require
  Bearer authentication on every HTTP route.
- A non-loopback CLI bind is refused when no HTTP token is configured. The
  `--allow-unauthenticated-remote` flag exists only as an explicit unsafe escape
  hatch; it is never selected automatically.
- The Bearer token authenticates requests but does not encrypt the network path.
  Use TLS or a secure tunnel before carrying it across an untrusted network.
- Profile directories and state exports contain live credentials. Treat an
  exported `state.json` as a password, not as configuration.

## Non-goals for v0

- No planning, no LLM calls, no natural-language task decomposition.
- No stealth, fingerprint randomisation, proxy rotation, or CAPTCHA solving.
- No multi-process coordination: one process, one host. Two workers over the
  same directory is exactly the case the lock refuses to guess about.
- No CDP remote executor yet; the seam exists in the session boundary, not in code.
- No IndexedDB / service-worker export.

## Next steps that would justify changing this document

1. A second driver (CDP endpoint) behind the same API, if a remote executor is
   needed for scale or geography.
2. An explicit storage-state extension for IndexedDB, if a target site proves it
   is required.
3. Session resurrection semantics, if agents prove they need to survive a worker
   restart without re-authenticating.
