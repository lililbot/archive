# entropy356 仓库快照

| 仓库 | 可见性 | 默认分支 | 提交数 | HEAD | 体积 | 远端分支 |
|---|---|---|---|---|---|---|
| `e-m-c` | 公开 | main | 87 | `be6d4a0ef8` | 536K | main, scratch/branch-workflow-review |
| `e-m-c.extra` | 公开 | main | 9 | `8cb78706b4` | 1.1M | main |
| `e-m-c.runtime` | 公开 | main | 2 | `a4fbdba4dc` | 376K | main |
| `game` | 公开 | main | 1 | `77814c2672` | 124K | main |
| `public-01` | 公开 | main | 0 | `(empty)` | 80K | - |
| `temp` | 公开 | main | 1 | `eb50f3cf95` | 120K | a2a/task/04386d4d-b587-46a9-b2f7-9005afac0a86, main |
| `agent-browser` | 私有 | main | 4 | `0c5c27a2d7` | 320K | main, migration/current-baseline, work/http-auth-boundary, work/standalone-install |
| `issuehub` | 私有 | main | 57 | `28415d818d` | 508K | cleanup/agent-browser-extraction, docs/codebuddy-capability-card, experiment/chatgpt-work-wake, feat/http-gateway-poc, fix/agentmore-refresh-secret-normalization, fix/browser-worker-review, fix/collab-wake-handoff-gating, main, maintenance/sonar-cleanup, proto/collab-mcp-v0, transport/chatgpt-work-wake, work/close-collab-mcp-v0, work/collab-edge-wake, work/collab-handoff, work/zhipu-agentmore-v0 |
| `private-01` | 私有 | main | 1 | `8c10e26e29` | 144K | feat/http-mcp-plugin, main |
| `private-02` | 私有 | main | 3 | `cbbd4f71be` | 252K | main |

每个目录都是完整克隆，含 `.git/` 全量历史；`git -C <仓库> log` 可直接查看。

共 10 个仓库。
