# Current state

This file is the smallest useful resume point for the work center.

## Work center

`issuehub` is the persistent coordination layer for human–AI work. The design is being **dogfooded**, not treated as a finished specification.

Primary meta-experiment: **#3 — Dogfood a GitHub-based AI collaboration system**.

No protocol experiment is currently active. Both current protocol slices have reached their v0 validation target; further changes should come from real usage evidence.

Validated infrastructure:

- **Cross-platform AI collaboration MCP v0 (#2, completed)**: shared durable collaboration state exposed through five ordinary MCP tools. The implementation is merged on `main` under `prototypes/collab-mcp`. Handoff/resumption and stale-revision reconciliation were validated first across independent client sessions and then across two hosts on separate platforms with no transcript transfer.

- **GitHub-native agent transport v0 (#8, completed)**: one task branch per task, canonical `a2a/task.json`, GitHub blob SHA revisions, optimistic stale-write rejection, and Actions validation. A real two-writer race produced the expected HTTP 409 on the stale write; re-read/reconcile/retry and cancel both succeeded, with Actions green. The transport remains experimental and does not claim full A2A custom-binding conformance.

- **ChatGPT Plus event-triggered Work wake v0 (#15, completed)**: a GitHub PR conversation comment can wake a ChatGPT Work task without a new user chat message. The task read repository context and autonomously wrote `[result] wake-ok` back to the PR with no manual approval in the validated path. GitHub Actions also successfully emitted supported PR-comment wake events, so unsupported GitHub events can be adapted at the edge instead of changing canonical collaboration state. Reaction writes were not reliable in the Work tool surface and are not part of the validated claim.

MCP, the GitHub-native transport, and platform wake adapters are complementary: MCP is a shared-state boundary for heterogeneous AI hosts; the GitHub transport proves direct durable agent task exchange can work without a privately operated always-on server; wake adapters let platform agents resume from GitHub events without making wake mechanics part of canonical state.

## Open directions

| # | Work item | Mode |
| --- | --- | --- |
| #1 | Map token resources | AI |
| #3 | Dogfood a GitHub-based AI collaboration system | Joint |
| #4 | Explore an AI-native operating system | Joint |
| #5 | Design a GitHub-hosted AI memory layer | Joint |
| #6 | Prototype Android text role-play with a Git-like story tree | Joint |

## Current operating hypotheses

- GitHub-native primitives should be used until a concrete limitation justifies custom infrastructure.
- Canonical state, including principles and protocols, should represent the best current model; Git should carry superseded states and rationale.
- Obsolete principles should be replaced, simplified, or deleted rather than retained as compatibility layers or historical notes.
- Unresolved/actionable things belong in Issues rather than accumulating as narrative notes.
- Work should be allocated explicitly to AI, Human, or Joint execution according to capability boundaries.
- A future agent should be able to resume useful work from this repository without replaying prior chats.
- Cross-platform AI collaboration can use shared durable state through MCP; direct agent-to-agent communication is a separate concern.
- Platform wake mechanics belong at the edge: prefer native event push, adapt unsupported GitHub events through Actions into supported wake events, and use polling only as a fallback.
- For direct agent task transport, GitHub-native state plus optimistic SHA-checked writes is sufficient for the validated v0 concurrency loop; no separate lock service is needed.
- WorkItem revisions represent adapter-owned semantic collaboration state, not every byte of a human-editable Issue body. Unmapped human edits should not cause conflicts by themselves.
- The GitHub Issues backend has a GET→PATCH TOCTOU window because Issue PATCH has no atomic compare-and-swap. Broader revision hashing does not remove that limitation.
- A protocol should not claim standards conformance until its actual behavior satisfies the standard; compatibility adapters belong at the edge rather than inside canonical state.
- Concurrency should default to optimistic, lock-free parallelism: Git manages state concurrency through commits/branches/merges/version checks, while the collaboration layer coordinates only semantic conflicts such as incompatible decisions, ownership, dependencies, or irreversible actions.
- A successful textual merge is not sufficient evidence of semantic compatibility; affected assumptions and contracts still need validation.

## Next validation

Continue #3 through real project work rather than extending coordination protocols speculatively.

Open a new focused work item only when dogfooding exposes a concrete failure, interoperability need, or repeated source of friction. In particular, address the GitHub Issues TOCTOU limitation only if real multi-writer use requires stronger atomicity; prefer a CAS-capable canonical primitive/backend over coordination locks.

The GitHub-native transport should only expand beyond v0 when a concrete interoperability need justifies implementing more A2A semantics or a thin standard-A2A adapter.

Judge the work center by whether a fresh agent can resume useful work from durable state cheaply and leave current truth cleaner than it found it.
