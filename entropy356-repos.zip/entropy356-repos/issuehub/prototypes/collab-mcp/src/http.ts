import { createServer as createHttpServer } from 'node:http';
import { createMcpHandler } from '@modelcontextprotocol/server';
import { toNodeHandler } from '@modelcontextprotocol/node';
import { createCollabServer } from './server.js';

const port = Number(process.env.PORT ?? '3000');
const mcp = createMcpHandler(() => createCollabServer());
const handleMcp = toNodeHandler(mcp, {
  onerror(error) {
    console.error(error);
  },
});

const http = createHttpServer(async (req, res) => {
  const path = new URL(req.url ?? '/', `http://${req.headers.host ?? 'localhost'}`).pathname;
  if (path !== '/mcp') {
    res.statusCode = 404;
    res.setHeader('content-type', 'text/plain; charset=utf-8');
    res.end('Not found');
    return;
  }
  await handleMcp(req, res);
});

http.listen(port, () => {
  console.error(`collab-mcp listening on http://127.0.0.1:${port}/mcp`);
});

async function shutdown() {
  http.close();
  await mcp.close();
}

process.once('SIGINT', shutdown);
process.once('SIGTERM', shutdown);
