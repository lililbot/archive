import { McpServer } from '@modelcontextprotocol/server';
import * as z from 'zod/v4';
import {
  GitHubBackend,
  HandoffRejectedError,
  RevisionConflictError,
  type ArtifactRef,
  type HandoffTransition,
  type WorkMode,
  type WorkState,
} from './github-backend.js';

const workState = z.enum(['open', 'active', 'review', 'blocked', 'done']);
const workMode = z.enum(['ai', 'human', 'joint']);
const artifactRole = z.enum(['input', 'output', 'canonical', 'evidence', 'implementation']);
const artifact = z.object({
  uri: z.string().min(1),
  role: artifactRole,
  label: z.string().min(1),
});

// The minimal tuple every transition must carry. Making these required is what
// stops a partial handoff at the schema boundary, before the backend sees it.
const handoffTransition = z.object({
  state: workState,
  owner: z.string(),
  next_actor: z.string(),
  current_truth: z.string(),
  next_actions: z.array(z.string()),
  blockers: z.array(z.string()),
  artifacts: z.array(artifact),
  mode: workMode.optional(),
  goal: z.string().optional(),
  constraints: z.array(z.string()).optional(),
});

export function createCollabServer(): McpServer {
  const server = new McpServer({ name: 'collab-mcp', version: '0.0.0' });
  const backend = backendFromEnv();

  server.registerTool(
    'collab.workspace.read',
    {
      description: 'Read the smallest durable workspace state needed to resume collaboration.',
      inputSchema: z.object({}),
    },
    async () => jsonResult(await backend.readWorkspace()),
  );

  server.registerTool(
    'collab.work.list',
    {
      description: 'List compact work-item descriptors without replaying work history.',
      inputSchema: z.object({ state: workState.optional() }),
    },
    async ({ state }) => jsonResult(await backend.listWork(state as WorkState | undefined)),
  );

  server.registerTool(
    'collab.work.read',
    {
      description: 'Read one complete current WorkItem snapshot for handoff/resumption.',
      inputSchema: z.object({ id: z.string().min(1) }),
    },
    async ({ id }) => jsonResult(await backend.readWork(id)),
  );

  server.registerTool(
    'collab.work.create',
    {
      description: 'Create a new durable WorkItem in the collaboration backend.',
      inputSchema: z.object({
        title: z.string().min(1),
        state: workState.default('open'),
        mode: workMode.default('joint'),
        owner: z.string().default(''),
        next_actor: z.string().default(''),
        goal: z.string().default(''),
        current_truth: z.string().default(''),
        constraints: z.array(z.string()).default([]),
        next_actions: z.array(z.string()).default([]),
        blockers: z.array(z.string()).default([]),
        artifacts: z.array(artifact).default([]),
      }),
    },
    async (input) => jsonResult(await backend.createWork({
      title: input.title,
      state: input.state as WorkState,
      mode: input.mode as WorkMode,
      owner: input.owner,
      next_actor: input.next_actor,
      goal: input.goal,
      current_truth: input.current_truth,
      constraints: input.constraints,
      next_actions: input.next_actions,
      blockers: input.blockers,
      artifacts: input.artifacts as ArtifactRef[],
    })),
  );

  server.registerTool(
    'collab.work.handoff',
    {
      description:
        'Perform one revision-checked WorkItem transition: state, owner, next actor, current truth, ' +
        'next actions, blockers and artifacts change together, and the complete resulting WorkItem is returned. ' +
        'Stale revisions are rejected; done requires at least one artifact as evidence.',
      inputSchema: z.object({
        id: z.string().min(1),
        expected_revision: z.string().min(1),
        set: handoffTransition,
      }),
    },
    async ({ id, expected_revision, set }) => {
      try {
        const updated = await backend.handoff(id, expected_revision, set as HandoffTransition);
        return jsonResult(updated);
      } catch (error) {
        if (error instanceof RevisionConflictError) {
          return jsonResult({
            error: 'revision_conflict',
            message: error.message,
            current: error.current,
          }, true);
        }
        if (error instanceof HandoffRejectedError) {
          return jsonResult({ error: 'handoff_rejected', reason: error.reason }, true);
        }
        throw error;
      }
    },
  );

  return server;
}

function backendFromEnv(): GitHubBackend {
  const token = process.env.COLLAB_GITHUB_TOKEN ?? process.env.GITHUB_TOKEN;
  const repository = process.env.COLLAB_GITHUB_REPO;
  if (!token) throw new Error('Set COLLAB_GITHUB_TOKEN (or GITHUB_TOKEN).');
  if (!repository) throw new Error('Set COLLAB_GITHUB_REPO=owner/repo.');
  return new GitHubBackend(token, repository, process.env.GITHUB_API_URL ?? 'https://api.github.com');
}

function jsonResult(value: unknown, isError = false) {
  return {
    content: [{ type: 'text' as const, text: JSON.stringify(value, null, 2) }],
    ...(isError ? { isError: true } : {}),
  };
}
