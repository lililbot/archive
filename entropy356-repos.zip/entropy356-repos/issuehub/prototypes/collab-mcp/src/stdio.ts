import { serveStdio } from '@modelcontextprotocol/server/stdio';
import { createCollabServer } from './server.js';

await serveStdio(() => createCollabServer());
