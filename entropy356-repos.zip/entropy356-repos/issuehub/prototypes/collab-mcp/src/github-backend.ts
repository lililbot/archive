import { createHash } from 'node:crypto';

export type WorkState = 'open' | 'active' | 'review' | 'blocked' | 'done';
export type WorkMode = 'ai' | 'human' | 'joint';

export interface ArtifactRef {
  uri: string;
  role: 'input' | 'output' | 'canonical' | 'evidence' | 'implementation';
  label: string;
}

export interface WorkItem {
  id: string;
  revision: string;
  title: string;
  state: WorkState;
  mode: WorkMode;
  /** Platform-level role currently responsible, for example `codebuddy`. */
  owner: string;
  /** Platform-level role expected to act next; empty when nobody is called on. */
  next_actor: string;
  goal: string;
  current_truth: string;
  constraints: string[];
  next_actions: string[];
  blockers: string[];
  artifacts: ArtifactRef[];
}

export interface Workspace {
  id: string;
  revision: string;
  summary: string;
  active_work: string[];
  links: Array<{ rel: string; uri: string }>;
}

type Issue = {
  number: number;
  title: string;
  state: 'open' | 'closed';
  body: string | null;
  html_url: string;
  pull_request?: unknown;
};

/** The minimal tuple every transition must carry, so no reader sees half a handoff. */
export interface HandoffTransition {
  state: WorkState;
  owner: string;
  next_actor: string;
  current_truth: string;
  next_actions: string[];
  blockers: string[];
  artifacts: ArtifactRef[];
  mode?: WorkMode;
  goal?: string;
  constraints?: string[];
}

export const REQUIRED_HANDOFF_FIELDS = [
  'state',
  'owner',
  'next_actor',
  'current_truth',
  'next_actions',
  'blockers',
  'artifacts',
] as const;

/** A transition that is well-formed as a request but wrong for this WorkItem. */
export class HandoffRejectedError extends Error {
  constructor(public readonly reason: string) {
    super(`HANDOFF_REJECTED ${reason}`);
    this.name = 'HandoffRejectedError';
  }
}

export class RevisionConflictError extends Error {
  constructor(public readonly current: WorkItem) {
    super(`REVISION_CONFLICT current_revision=${current.revision}`);
    this.name = 'RevisionConflictError';
  }
}

export class GitHubBackend {
  private readonly owner: string;
  private readonly repo: string;

  constructor(
    private readonly token: string,
    repository: string,
    private readonly apiBase = 'https://api.github.com',
  ) {
    const [owner, repo] = repository.split('/');
    if (!owner || !repo) throw new Error('COLLAB_GITHUB_REPO must be owner/repo');
    this.owner = owner;
    this.repo = repo;
  }

  async readWorkspace(): Promise<Workspace> {
    const file = await this.request<{ content: string; encoding: string; sha: string; html_url: string }>(
      `/repos/${this.owner}/${this.repo}/contents/STATE.md`,
    );
    const summary = file.encoding === 'base64'
      ? Buffer.from(file.content.replaceAll('\n', ''), 'base64').toString('utf8')
      : file.content;
    const issueNumbers = [...summary.matchAll(/#(\d+)/g)].map((m) => Number(m[1]));
    const active_work = [...new Set(issueNumbers)].map((n) => this.issueUrl(n));

    return {
      id: `github://${this.owner}/${this.repo}`,
      revision: file.sha,
      summary,
      active_work,
      links: [
        { rel: 'repository', uri: `https://github.com/${this.owner}/${this.repo}` },
        { rel: 'state', uri: file.html_url },
      ],
    };
  }

  async listWork(state?: WorkState): Promise<Array<Pick<WorkItem, 'id' | 'title' | 'state' | 'mode' | 'revision'>>> {
    const issues = await this.request<Issue[]>(
      `/repos/${this.owner}/${this.repo}/issues?state=all&per_page=100&sort=updated&direction=desc`,
    );

    return issues
      .filter((issue) => !issue.pull_request)
      .map((issue) => this.toWorkItem(issue))
      .filter((item) => !state || item.state === state)
      .map(({ id, title, state: itemState, mode, revision }) => ({ id, title, state: itemState, mode, revision }));
  }

  async readWork(id: string): Promise<WorkItem> {
    const number = this.issueNumber(id);
    const issue = await this.request<Issue>(`/repos/${this.owner}/${this.repo}/issues/${number}`);
    return this.toWorkItem(issue);
  }

  async createWork(input: Omit<WorkItem, 'id' | 'revision'>): Promise<WorkItem> {
    validateTransition(input);
    let issue = await this.request<Issue>(`/repos/${this.owner}/${this.repo}/issues`, {
      method: 'POST',
      body: JSON.stringify({ title: input.title, body: renderBody(input) }),
    });

    if (input.state === 'done') {
      issue = await this.request<Issue>(`/repos/${this.owner}/${this.repo}/issues/${issue.number}`, {
        method: 'PATCH',
        body: JSON.stringify({ state: 'closed' }),
      });
    }
    return this.toWorkItem(issue);
  }

  /**
   * The single write path. One revision-checked transition carries state, the
   * actors, current truth, next actions, blockers and artifacts together, so a
   * reader never sees a half-updated WorkItem.
   */
  async handoff(id: string, expectedRevision: string, transition: HandoffTransition): Promise<WorkItem> {
    for (const field of REQUIRED_HANDOFF_FIELDS) {
      if (!(field in transition)) {
        throw new HandoffRejectedError(`handoff requires ${field}; a partial transition is not a handoff`);
      }
    }
    const number = this.issueNumber(id);
    const latestIssue = await this.request<Issue>(`/repos/${this.owner}/${this.repo}/issues/${number}`);
    const latest = this.toWorkItem(latestIssue);
    if (latest.revision !== expectedRevision) throw new RevisionConflictError(latest);

    const next: WorkItem = { ...latest, ...transition };
    validateTransition(next);
    const issue = await this.request<Issue>(`/repos/${this.owner}/${this.repo}/issues/${number}`, {
      method: 'PATCH',
      body: JSON.stringify({
        body: patchBody(latestIssue.body ?? '', next),
        state: next.state === 'done' ? 'closed' : 'open',
      }),
    });
    return this.toWorkItem(issue);
  }

  private toWorkItem(issue: Issue): WorkItem {
    const body = issue.body ?? '';
    const stateText = section(body, 'State').trim().toLowerCase();
    const state: WorkState = issue.state === 'closed' ? 'done' : stateFromText(stateText);

    const modeText = section(body, 'Mode').trim().toLowerCase();
    const mode: WorkMode = modeFromText(modeText);

    const item: WorkItem = {
      id: issue.html_url || this.issueUrl(issue.number),
      revision: '',
      title: issue.title,
      state,
      mode,
      owner: section(body, 'Owner').trim(),
      next_actor: section(body, 'Next actor').trim(),
      goal: section(body, 'Goal').trim(),
      current_truth: section(body, 'Current truth').trim(),
      constraints: parseList(section(body, 'Constraints')),
      next_actions: parseList(section(body, 'Next actions')),
      blockers: parseList(section(body, 'Blockers')),
      artifacts: parseArtifacts(section(body, 'Artifacts')),
    };
    item.revision = revisionOf({ ...item, revision: undefined });
    return item;
  }

  private issueNumber(id: string): number {
    const trimmed = id.endsWith('/') ? id.slice(0, -1) : id;
    let start = trimmed.length;
    while (start > 0) {
      const code = trimmed.codePointAt(start - 1);
      if (code === undefined || code < 48 || code > 57) break;
      start -= 1;
    }
    if (start === trimmed.length) throw new Error(`Invalid work item id: ${id}`);
    return Number(trimmed.slice(start));
  }

  private issueUrl(number: number): string {
    return `https://github.com/${this.owner}/${this.repo}/issues/${number}`;
  }

  private async request<T>(path: string, init: RequestInit = {}): Promise<T> {
    const response = await fetch(`${this.apiBase}${path}`, {
      ...init,
      headers: {
        Accept: 'application/vnd.github+json',
        Authorization: `Bearer ${this.token}`,
        'X-GitHub-Api-Version': '2022-11-28',
        'Content-Type': 'application/json',
        ...init.headers,
      },
    });

    if (!response.ok) {
      const text = await response.text();
      throw new Error(`GitHub ${response.status}: ${text}`);
    }
    return response.json() as Promise<T>;
  }
}

/** State invariants that make a WorkItem readable without interpretation. */
export function validateTransition(
  item: Pick<WorkItem, 'state' | 'owner' | 'next_actor' | 'blockers' | 'artifacts'>,
): void {
  if (item.state === 'active') {
    if (!item.owner.trim()) {
      throw new HandoffRejectedError('active needs a non-empty owner');
    }
    if (!item.next_actor.trim()) {
      throw new HandoffRejectedError('active needs a next_actor');
    }
    if (item.next_actor !== item.owner) {
      throw new HandoffRejectedError('active requires next_actor to equal owner; use review, blocked, or done to route work away');
    }
  }
  if (item.state === 'review') {
    if (item.artifacts.length === 0) {
      throw new HandoffRejectedError('review needs at least one artifact under review');
    }
    if (!item.next_actor.trim()) {
      throw new HandoffRejectedError('review needs a next_actor to review it');
    }
  }
  if (item.state === 'done') {
    if (item.artifacts.length === 0) {
      throw new HandoffRejectedError('done needs at least one artifact as evidence; hand off to review instead');
    }
    if (item.blockers.length > 0) {
      throw new HandoffRejectedError('done cannot carry blockers');
    }
    if (item.next_actor.trim() !== '') {
      throw new HandoffRejectedError('done must clear next_actor');
    }
  }
}

function stateFromText(text: string): WorkState {
  if (text === 'active') return 'active';
  if (text === 'review') return 'review';
  if (text === 'blocked') return 'blocked';
  return 'open';
}

function modeFromText(text: string): WorkMode {
  if (text.startsWith('ai')) return 'ai';
  if (text.startsWith('human')) return 'human';
  return 'joint';
}

function revisionOf(value: unknown): string {
  return createHash('sha256').update(JSON.stringify(value)).digest('hex').slice(0, 24);
}

function section(body: string, name: string): string {
  const lines = body.split(/\r?\n/);
  const start = lines.findIndex((line) => line.trim().toLowerCase() === `## ${name}`.toLowerCase());
  if (start < 0) return '';
  const out: string[] = [];
  for (let i = start + 1; i < lines.length; i += 1) {
    if (/^##\s+/.test(lines[i])) break;
    out.push(lines[i]);
  }
  return out.join('\n').trim();
}

function replaceSection(body: string, name: string, value: string): string {
  const heading = `## ${name}`;
  const lines = body.split(/\r?\n/);
  const start = lines.findIndex((line) => line.trim().toLowerCase() === heading.toLowerCase());
  if (start < 0) return `${body.trimEnd()}\n\n${heading}\n${value.trim()}\n`;

  let end = lines.length;
  for (let i = start + 1; i < lines.length; i += 1) {
    if (/^##\s+/.test(lines[i])) {
      end = i;
      break;
    }
  }
  return [...lines.slice(0, start), heading, value.trim(), '', ...lines.slice(end)].join('\n').trimEnd() + '\n';
}

function parseList(value: string): string[] {
  return value
    .split(/\r?\n/)
    .map((line) => line.replace(/^\s*(?:[-*]|\d+[.)])\s+/, '').trim())
    .filter(Boolean);
}

function renderList(items: string[]): string {
  return items.map((item) => `- ${item}`).join('\n');
}

const ARTIFACT_ROLES = ['input', 'output', 'canonical', 'evidence', 'implementation'] as const;

function parseArtifacts(value: string): ArtifactRef[] {
  const artifacts: ArtifactRef[] = [];
  for (const raw of value.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line.startsWith('-')) continue;
    const labelStart = line.indexOf('[');
    const labelEnd = line.indexOf('](', labelStart + 1);
    if (labelStart < 0 || labelEnd < 0) continue;
    const uriEnd = line.indexOf(')', labelEnd + 2);
    const roleSep = line.indexOf('—', uriEnd + 1);
    if (uriEnd < 0 || roleSep < 0) continue;

    const label = line.slice(labelStart + 1, labelEnd).trim();
    const uri = line.slice(labelEnd + 2, uriEnd).trim();
    const role = line.slice(roleSep + 1).trim().toLowerCase();
    if (!label || !uri) continue;
    if (!(ARTIFACT_ROLES as readonly string[]).includes(role)) continue;
    artifacts.push({ label, uri, role: role as ArtifactRef['role'] });
  }
  return artifacts;
}

function renderArtifacts(items: ArtifactRef[]): string {
  return items.map((item) => `- [${item.label}](${item.uri}) — ${item.role}`).join('\n');
}

function renderBody(item: Omit<WorkItem, 'id' | 'revision'>): string {
  return [
    `## Goal\n${item.goal}`,
    `## State\n${item.state}`,
    `## Mode\n${item.mode}`,
    `## Owner\n${item.owner}`,
    `## Next actor\n${item.next_actor}`,
    `## Current truth\n${item.current_truth}`,
    `## Next actions\n${renderList(item.next_actions)}`,
    `## Blockers\n${renderList(item.blockers)}`,
    `## Artifacts\n${renderArtifacts(item.artifacts)}`,
    `## Constraints\n${renderList(item.constraints)}`,
  ].join('\n\n').trimEnd() + '\n';
}

function patchBody(body: string, item: WorkItem): string {
  let next = body;
  next = replaceSection(next, 'Goal', item.goal);
  next = replaceSection(next, 'State', item.state);
  next = replaceSection(next, 'Mode', item.mode);
  next = replaceSection(next, 'Owner', item.owner);
  next = replaceSection(next, 'Next actor', item.next_actor);
  next = replaceSection(next, 'Current truth', item.current_truth);
  next = replaceSection(next, 'Next actions', renderList(item.next_actions));
  next = replaceSection(next, 'Blockers', renderList(item.blockers));
  next = replaceSection(next, 'Artifacts', renderArtifacts(item.artifacts));
  next = replaceSection(next, 'Constraints', renderList(item.constraints));
  return next;
}