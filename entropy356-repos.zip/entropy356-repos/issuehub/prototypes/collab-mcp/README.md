# collab-mcp prototype

A minimal GitHub-backed MCP server for cross-platform AI handoff experiments.

This prototype implements the v0 contract in `../../projects/collab-mcp/PROTOCOL.md` using only ordinary MCP tools. It intentionally does not depend on MCP Tasks, elicitation, sampling, subscriptions, or agent-to-agent RPC.

## Tools

- `collab.workspace.read`
- `collab.work.list`
- `collab.work.read`
- `collab.work.create`
- `collab.work.handoff` — one revision-checked transition; state, owner, next actor, current truth, next actions, blockers and artifacts are all required, and `review`/`done` carry enforced invariants

Tool results are JSON encoded as text content for broad host compatibility.

## Backend mapping

- `STATE.md` → Workspace
- GitHub Issues → WorkItems
- Issue sections `Goal`, `State`, `Mode`, `Owner`, `Next actor`, `Current truth`, `Next actions`, `Blockers`, `Artifacts`, `Constraints` → structured WorkItem fields
- closed Issue → `done`
- GitHub/Git history → history outside the current WorkItem

The adapter preserves unrelated Issue sections when updating a work item.

## Run locally (stdio)

Requires Node.js 20+ and a GitHub token with access to the target repository.

```bash
npm install
export COLLAB_GITHUB_TOKEN=...
export COLLAB_GITHUB_REPO=entropy356/issuehub
npm run dev
```

Point an MCP host at the stdio command for this package.

## Run over Streamable HTTP

```bash
export COLLAB_GITHUB_TOKEN=...
export COLLAB_GITHUB_REPO=entropy356/issuehub
PORT=3000 npm run dev:http
```

The MCP endpoint is `http://127.0.0.1:3000/mcp`.

The HTTP entry uses the current MCP v2 server handler and accepts its legacy stateless fallback as well as the modern protocol era.

## Concurrency

Every WorkItem read returns an opaque `revision`. `collab.work.update` requires `expected_revision`. If the item has changed since it was read, the tool returns `revision_conflict` together with the latest WorkItem so the caller can reconcile and retry.

This prototype detects ordinary stale writes, but the GitHub Issues REST API does not provide an atomic compare-and-swap for Issue bodies. A tiny race remains between the server's final read and PATCH if multiple server processes write the same Issue simultaneously. The first validation should run a single server instance; a production backend must close this gap (for example by serializing writes or moving canonical mutable state to a CAS-capable store/Git object).

## First experiment

1. Start one server instance against `entropy356/issuehub`.
2. Connect Platform A and read a real Issue.
3. Advance it and update only distilled current truth/artifact references.
4. Start Platform B without Platform A's conversation history.
5. Have Platform B read and continue the same Issue.
6. Replay an older revision and verify that the server returns `revision_conflict`.

The prototype is successful if Platform B can continue correctly and the handoff does not require transcript transfer.

## Tests

```bash
npm test
```

Eight tests drive the backend against a local HTTP stand-in for the GitHub API:
implementer → review, reviewer → implementer with blockers, stale handoff
rejection with the current snapshot, `done` requiring evidence, empty routing
and no blockers, partial transitions refused before reaching the backend,
`create` unable to bypass the `done` invariant, and preservation of sections the
adapter does not own.
