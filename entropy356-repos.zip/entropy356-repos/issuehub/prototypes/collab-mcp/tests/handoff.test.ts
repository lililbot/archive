import assert from 'node:assert/strict';
import test from 'node:test';

import {
  GitHubBackend,
  HandoffRejectedError,
  RevisionConflictError,
  type HandoffTransition,
  type WorkState,
} from '../src/github-backend.js';
import { FakeGitHub } from './fake-github.js';

const artifact = {
  uri: 'https://github.com/entropy356/issuehub/pull/25',
  role: 'implementation' as const,
  label: 'PR #25',
};

async function withBackend(run: (backend: GitHubBackend, fake: FakeGitHub) => Promise<void>): Promise<void> {
  const fake = new FakeGitHub();
  const base = await fake.listen();
  try {
    await run(new GitHubBackend('test-token', 'entropy356/issuehub', base), fake);
  } finally {
    await fake.close();
  }
}

function workItemBody(sections: Record<string, string>): string {
  return Object.entries(sections).map(([name, value]) => `## ${name}\n${value}`).join('\n\n') + '\n';
}

const base: Omit<HandoffTransition, 'state'> = {
  owner: 'CodeBuddy',
  next_actor: 'ChatGPT',
  current_truth: 'unchanged',
  next_actions: ['review'],
  blockers: [],
  artifacts: [],
};

test('implementer hands the item to review', async () => {
  await withBackend(async (backend, fake) => {
    fake.addIssue(
      'Browser Worker review fixes',
      workItemBody({
        Goal: 'Land the review fixes.',
        State: 'active',
        Mode: 'ai',
        Owner: 'CodeBuddy',
        'Next actor': 'CodeBuddy',
        'Current truth': 'Implementation is in progress.',
        'Next actions': '- finish the change',
      }),
    );

    const item = await backend.readWork('1');
    assert.equal(item.state, 'active');
    assert.equal(item.owner, 'CodeBuddy');

    const handed = await backend.handoff(item.id, item.revision, {
      ...base,
      state: 'review',
      current_truth: 'Fixes implemented; PR #25 is ready for review.',
      next_actions: ['Review PR #25'],
      artifacts: [artifact],
    });

    assert.equal(handed.state, 'review');
    assert.equal(handed.next_actor, 'ChatGPT');
    assert.deepEqual(handed.artifacts, [artifact]);

    const reread = await backend.readWork(item.id);
    assert.equal(reread.revision, handed.revision);
    assert.equal(reread.state, 'review');
  });
});

test('reviewer sends the item back for changes', async () => {
  await withBackend(async (backend, fake) => {
    fake.addIssue(
      'Needs another pass',
      workItemBody({ State: 'review', Mode: 'ai', Owner: 'CodeBuddy', 'Next actor': 'ChatGPT', Goal: 'g' }),
    );
    const item = await backend.readWork('1');

    const returned = await backend.handoff(item.id, item.revision, {
      ...base,
      state: 'active',
      next_actor: 'CodeBuddy',
      blockers: ['sandbox flag must be opt-in'],
      next_actions: ['make --no-sandbox opt-in', 're-run tests'],
      artifacts: [artifact],
    });

    assert.equal(returned.state, 'active');
    assert.equal(returned.next_actor, 'CodeBuddy');
    assert.deepEqual(returned.blockers, ['sandbox flag must be opt-in']);
  });
});

test('active work stays routed to its owner', async () => {
  await withBackend(async (backend, fake) => {
    fake.addIssue(
      'Cleanup in progress',
      workItemBody({
        State: 'active',
        Mode: 'joint',
        Owner: 'CodeBuddy',
        'Next actor': 'CodeBuddy',
        Goal: 'Finish cleanup.',
      }),
    );
    const item = await backend.readWork('1');

    const continued = await backend.handoff(item.id, item.revision, {
      ...base,
      state: 'active',
      next_actor: 'CodeBuddy',
      current_truth: 'Cleanup is still in progress.',
      next_actions: ['finish cleanup'],
    });

    assert.equal(continued.state, 'active');
    assert.equal(continued.owner, 'CodeBuddy');
    assert.equal(continued.next_actor, 'CodeBuddy');
  });
});

test('active work cannot route next_actor away from owner', async () => {
  await withBackend(async (backend, fake) => {
    fake.addIssue(
      'Cleanup in progress',
      workItemBody({
        State: 'active',
        Mode: 'joint',
        Owner: 'CodeBuddy',
        'Next actor': 'CodeBuddy',
        Goal: 'Finish cleanup.',
      }),
    );
    const item = await backend.readWork('1');

    await assert.rejects(
      () => backend.handoff(item.id, item.revision, {
        ...base,
        state: 'active',
        owner: 'CodeBuddy',
        next_actor: 'ChatGPT',
        next_actions: ['finish cleanup'],
      }),
      (error: unknown) =>
        error instanceof HandoffRejectedError && /next_actor.*owner|owner.*next_actor/i.test(error.reason),
    );
  });
});

test('a stale handoff is rejected and returns the live item', async () => {
  await withBackend(async (backend, fake) => {
    fake.addIssue('Contended item', workItemBody({ State: 'active', Mode: 'ai', Owner: 'CodeBuddy', Goal: 'g' }));
    const first = await backend.readWork('1');

    await backend.handoff(first.id, first.revision, {
      ...base,
      state: 'review',
      current_truth: 'first writer',
      artifacts: [artifact],
    });

    await assert.rejects(
      () => backend.handoff(first.id, first.revision, { ...base, state: 'active', current_truth: 'second writer' }),
      (error: unknown) => {
        assert.ok(error instanceof RevisionConflictError);
        assert.equal(error.current.current_truth, 'first writer');
        return true;
      },
    );
  });
});

test('done requires evidence and clears routing', async () => {
  await withBackend(async (backend, fake) => {
    fake.addIssue(
      'Ready to close',
      workItemBody({ State: 'review', Mode: 'ai', Owner: 'CodeBuddy', 'Next actor': 'ChatGPT', Goal: 'g' }),
    );
    const item = await backend.readWork('1');

    await assert.rejects(
      () => backend.handoff(item.id, item.revision, { ...base, state: 'done', next_actor: '' }),
      (error: unknown) => error instanceof HandoffRejectedError && /artifact/i.test(error.reason),
    );
    await assert.rejects(
      () =>
        backend.handoff(item.id, item.revision, {
          ...base,
          state: 'done',
          next_actor: 'ChatGPT',
          artifacts: [artifact],
        }),
      (error: unknown) => error instanceof HandoffRejectedError && /next_actor/.test(error.reason),
    );
    await assert.rejects(
      () =>
        backend.handoff(item.id, item.revision, {
          ...base,
          state: 'done',
          next_actor: '',
          blockers: ['still waiting'],
          artifacts: [artifact],
        }),
      (error: unknown) => error instanceof HandoffRejectedError && /blockers/.test(error.reason),
    );

    const closed = await backend.handoff(item.id, item.revision, {
      ...base,
      state: 'done',
      next_actor: '',
      current_truth: 'Merged and verified.',
      next_actions: [],
      artifacts: [artifact],
    });
    assert.equal(closed.state, 'done');
    assert.equal(fake.issues.get(1)?.state, 'closed');
  });
});

test('a review transition needs an artifact and a reviewer', async () => {
  await withBackend(async (backend, fake) => {
    fake.addIssue('Half handoff', workItemBody({ State: 'active', Mode: 'ai', Owner: 'CodeBuddy', Goal: 'g' }));
    const item = await backend.readWork('1');

    await assert.rejects(
      () => backend.handoff(item.id, item.revision, { ...base, state: 'review' }),
      (error: unknown) => error instanceof HandoffRejectedError && /artifact/.test(error.reason),
    );
    await assert.rejects(
      () =>
        backend.handoff(item.id, item.revision, {
          ...base,
          state: 'review',
          next_actor: '  ',
          artifacts: [artifact],
        }),
      (error: unknown) => error instanceof HandoffRejectedError && /next_actor/.test(error.reason),
    );
  });
});

test('a partial transition is refused before it reaches the backend', async () => {
  await withBackend(async (backend, fake) => {
    fake.addIssue('Partial', workItemBody({ State: 'active', Mode: 'ai', Owner: 'CodeBuddy', Goal: 'g' }));
    const item = await backend.readWork('1');
    const partial = { state: 'review' as WorkState, owner: 'CodeBuddy' };

    await assert.rejects(
      () => backend.handoff(item.id, item.revision, partial as unknown as HandoffTransition),
      (error: unknown) => error instanceof HandoffRejectedError && /requires/.test(error.reason),
    );
  });
});

test('create cannot bypass the done invariant', async () => {
  await withBackend(async (backend) => {
    await assert.rejects(
      () =>
        backend.createWork({
          title: 'Created as done',
          state: 'done',
          mode: 'ai',
          owner: 'CodeBuddy',
          next_actor: '',
          goal: 'g',
          current_truth: '',
          constraints: [],
          next_actions: [],
          blockers: [],
          artifacts: [],
        }),
      (error: unknown) => error instanceof HandoffRejectedError && /artifact/.test(error.reason),
    );
  });
});

test('create cannot bypass the active routing invariant', async () => {
  await withBackend(async (backend) => {
    await assert.rejects(
      () =>
        backend.createWork({
          title: 'Misrouted active work',
          state: 'active',
          mode: 'joint',
          owner: 'CodeBuddy',
          next_actor: 'ChatGPT',
          goal: 'g',
          current_truth: '',
          constraints: [],
          next_actions: ['finish work'],
          blockers: [],
          artifacts: [],
        }),
      (error: unknown) =>
        error instanceof HandoffRejectedError && /next_actor.*owner|owner.*next_actor/i.test(error.reason),
    );
  });
});

test('sections the adapter does not own survive a handoff', async () => {
  await withBackend(async (backend, fake) => {
    fake.addIssue(
      'Has human notes',
      workItemBody({ State: 'active', Mode: 'ai', Owner: 'CodeBuddy', Goal: 'g' }) +
        '\n## Notes\nKept by a human, must not be lost.\n',
    );
    const item = await backend.readWork('1');
    await backend.handoff(item.id, item.revision, {
      ...base,
      state: 'review',
      artifacts: [artifact],
    });

    const body = fake.issues.get(1)?.body ?? '';
    assert.match(body, /## Notes\nKept by a human, must not be lost\./);
    assert.match(body, /## Next actor\nChatGPT/);
  });
});