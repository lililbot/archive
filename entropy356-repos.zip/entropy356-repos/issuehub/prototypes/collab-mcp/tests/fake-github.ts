import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import type { AddressInfo } from 'node:net';

export interface FakeIssue {
  number: number;
  title: string;
  state: 'open' | 'closed';
  body: string;
  html_url: string;
}

/**
 * The smallest GitHub surface the backend actually uses: one file and issues.
 * Tests drive real HTTP so the request formatting is exercised too.
 */
export class FakeGitHub {
  readonly issues = new Map<number, FakeIssue>();
  stateFile = '# Current state\n\n- **#1** a work item\n';
  private nextNumber = 1;
  private server: Server | null = null;
  private port = 0;

  addIssue(title: string, body: string): FakeIssue {
    const number = this.nextNumber;
    this.nextNumber += 1;
    const issue: FakeIssue = {
      number,
      title,
      state: 'open',
      body,
      html_url: `https://github.com/entropy356/issuehub/issues/${number}`,
    };
    this.issues.set(number, issue);
    return issue;
  }

  async listen(): Promise<string> {
    this.server = createServer((req, res) => this.handle(req, res));
    await new Promise<void>((resolve) => this.server?.listen(0, '127.0.0.1', resolve));
    this.port = (this.server!.address() as AddressInfo).port;
    return `http://127.0.0.1:${this.port}`;
  }

  async close(): Promise<void> {
    await new Promise<void>((resolve) => this.server?.close(() => resolve()));
  }

  private serveState(send: (status: number, payload: unknown) => void): void {
    send(200, {
      content: Buffer.from(this.stateFile, 'utf8').toString('base64'),
      encoding: 'base64',
      sha: 'state-sha',
      html_url: 'https://github.com/entropy356/issuehub/blob/main/STATE.md',
    });
  }

  private async serveIssue(
    number: number,
    req: IncomingMessage,
    send: (status: number, payload: unknown) => void,
    readBody: () => Promise<string>,
  ): Promise<void> {
    const issue = this.issues.get(number);
    if (!issue) {
      send(404, { message: 'Not Found' });
      return;
    }
    if (req.method === 'PATCH') {
      const payload = JSON.parse(await readBody()) as Partial<FakeIssue>;
      if (typeof payload.body === 'string') issue.body = payload.body;
      if (payload.state === 'open' || payload.state === 'closed') issue.state = payload.state;
    }
    send(200, issue);
  }

  private async handle(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const url = new URL(req.url ?? '/', 'http://127.0.0.1');
    const readBody = async (): Promise<string> => {
      const chunks: Buffer[] = [];
      for await (const chunk of req) chunks.push(chunk as Buffer);
      return Buffer.concat(chunks).toString('utf8');
    };
    const send = (status: number, payload: unknown): void => {
      const body = JSON.stringify(payload);
      res.writeHead(status, { 'content-type': 'application/json' });
      res.end(body);
    };

    if (url.pathname === '/repos/entropy356/issuehub/contents/STATE.md') {
      this.serveState(send);
      return;
    }

    if (url.pathname === '/repos/entropy356/issuehub/issues' && req.method === 'GET') {
      send(200, [...this.issues.values()]);
      return;
    }

    if (url.pathname === '/repos/entropy356/issuehub/issues' && req.method === 'POST') {
      const payload = JSON.parse(await readBody()) as { title: string; body: string };
      send(201, this.addIssue(payload.title, payload.body));
      return;
    }

    const match = /^\/repos\/entropy356\/issuehub\/issues\/(\d+)$/.exec(url.pathname);
    if (match) {
      await this.serveIssue(Number(match[1]), req, send, readBody);
      return;
    }

    send(404, { message: `unhandled ${req.method} ${url.pathname}` });
  }
}
