# zhipu-agentmore v0

Thin experimental adapter for the private AgentMore web backend.

## Validated boundary

A real authenticated AgentMore run created one `A2A Probe` partner and successfully sent a task through the web-session endpoint:

```text
POST /api/partners/{agent_id}/chat-messages/
```

Observed request fields:

```text
message
stream
conversation_id
model
```

The authenticated A2A Probe page also exposes its AgentMore assistant identifier:

```text
asst_8c7403a04840095c3b767063101720b3
```

That gives the second transport a concrete target rather than guessing from the partner route ID.

Partner creation is deliberately **not implemented** yet. The UI flow works, but the authenticated HTTP contract behind the create button has not been observed precisely enough to encode without guessing.

## Two task transports

### Session transport

`agentmore.py` implements the product-layer request observed during the real browser validation. It needs the authenticated web Cookie and CSRF token and sends to `/api/partners/{agent_id}/chat-messages/`.

### Signed transport

`signed.py` implements the independently reverse-engineered ChatGLM/AgentMore web protocol:

```text
chatglm_refresh_token
  -> POST https://chatglm.cn/chatglm/user-api/user/refresh
  -> short-lived access token
  -> POST https://agentmore.chatglm.cn/chatglm/agent-api/chat/stream
```

Requests use the frontend `X-Sign`/`X-Timestamp`/`X-Nonce` signing scheme and the AgentMore assistant ID. The current public signing salt is kept as an overrideable protocol constant; it is not an account secret.

The signed transport intentionally does **not** add spoofed `X-Forwarded-For` headers.

The refresh endpoint may rotate the long-lived refresh token. v0 reports that condition but does not yet persist the rotated value automatically.

## Credentials

For the GitHub wake experiment, the only account secret is:

```text
AGENTMORE_REFRESH_TOKEN
```

It is the value of the `chatglm_refresh_token` Cookie created by a normal logged-in ChatGLM session. Do not commit it to GitHub.

Optional protocol overrides:

```text
AGENTMORE_SIGN_SECRET
AGENTMORE_REFRESH_URL
AGENTMORE_AGENT_STREAM_URL
AGENTMORE_AGENT_ORIGIN
AGENTMORE_SIGNED_MODEL
```

The older session transport instead reads:

```text
AGENTMORE_COOKIE
AGENTMORE_CSRF_TOKEN
AGENTMORE_AGENT_ID
AGENTMORE_CONVERSATION_ID
```

## CLI

Session-transport dry-run without credentials:

```bash
python prototypes/zhipu-agentmore/agentmore.py send \
  --agent-id a1 \
  --conversation-id c1 \
  --message 'ping' \
  --dry-run
```

`create` currently fails explicitly rather than guessing the private creation endpoint.

## GitHub wake experiment

`.github/workflows/zhipu-agentmore.yml` listens only to new issue comments beginning with:

```text
[wake:zhipu]
```

It serializes all AgentMore work through one repository-wide concurrency group, uses the signed refresh-token transport to start a fresh conversation against the existing `A2A Probe` assistant, and writes the answer back with:

```text
[result:zhipu]
```

Result comments cannot retrigger the workflow because they do not use the wake prefix.

The current `A2A Probe` assistant ID is temporarily fixed in the workflow because it is a non-secret v0 execution target. It should disappear once fresh-agent creation is implemented.

## Test

```bash
cd prototypes/zhipu-agentmore
python -m unittest -v test_agentmore.py test_signed.py
```

## Intended next validation

1. Put `chatglm_refresh_token` into the repository Actions secret `AGENTMORE_REFRESH_TOKEN`.
2. Merge the experimental workflow after PR smoke tests pass.
3. Post one `[wake:zhipu]` instruction and verify the direct GitHub Actions -> AgentMore -> GitHub result loop.
4. If the refresh token rotates, design secure persistence before treating this as a repeated unattended channel.
5. Capture the exact partner-creation HTTP contract and replace the fixed probe assistant with fresh-agent creation.

This is an edge adapter. GitHub remains canonical collaboration state; AgentMore conversation history is execution-local.
