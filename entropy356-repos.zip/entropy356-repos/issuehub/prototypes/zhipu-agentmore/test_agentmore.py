import json
import unittest

from agentmore import AgentMoreClient, AgentMoreConfig, parse_body, parse_sse


class AgentMoreTests(unittest.TestCase):
    def test_task_url_and_payload(self):
        client = AgentMoreClient(AgentMoreConfig(base_url="https://example.test", model="GLM-Flash"))
        self.assertEqual(client.task_url("a1"), "https://example.test/api/partners/a1/chat-messages/")
        self.assertEqual(
            client.build_payload(conversation_id="c1", message="hi"),
            {"message": "hi", "stream": True, "conversation_id": "c1", "model": "GLM-Flash"},
        )

    def test_json_response(self):
        body = json.dumps({"answer": "wake-ok", "status": "finish"}).encode()
        parsed = parse_body(body, "application/json")
        self.assertEqual(parsed["format"], "json")
        self.assertEqual(parsed["answer"], "wake-ok")

    def test_sse_response(self):
        text = (
            'event: message\ndata: {"answer":"pro"}\n\n'
            'data: {"answer":"probe-2","status":"finish"}\n\n'
            'data: [DONE]\n\n'
        )
        events = parse_sse(text)
        self.assertEqual(len(events), 3)
        parsed = parse_body(text.encode(), "text/event-stream")
        self.assertEqual(parsed["answer"], "probe-2")


if __name__ == "__main__":
    unittest.main()
