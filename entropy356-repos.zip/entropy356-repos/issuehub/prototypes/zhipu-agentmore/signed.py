from __future__ import annotations

import hashlib
import json
import os
import time
import urllib.error
import urllib.request
import uuid
from dataclasses import dataclass
from typing import Any

from agentmore import AgentMoreError

DEFAULT_REFRESH_URL = "https://chatglm.cn/chatglm/user-api/user/refresh"
DEFAULT_AGENT_STREAM_URL = "https://agentmore.chatglm.cn/chatglm/agent-api/chat/stream"
DEFAULT_AGENT_ORIGIN = "https://agentmore.chatglm.cn"
DEFAULT_SIGN_SECRET = "8a1317a7468aa3ad86e997d08f3f31cb"
DEFAULT_SIGNED_MODEL = "glm-5.3-flash"


def normalize_refresh_token(value: str) -> str:
    """Accept a raw token plus common copy/paste forms without exposing it."""
    token = value.strip()
    if len(token) >= 2 and token[0] == token[-1] and token[0] in {"'", '"'}:
        token = token[1:-1].strip()
    if token.lower().startswith("bearer "):
        token = token[7:].strip()

    cookie_token: str | None = None
    for part in token.split(";"):
        name, separator, candidate = part.strip().partition("=")
        if separator and name.strip() == "chatglm_refresh_token":
            cookie_token = candidate.strip()
            break
    if cookie_token is not None:
        token = cookie_token

    return token.strip().strip("'\"")


@dataclass(frozen=True)
class SignedConfig:
    refresh_token: str
    sign_secret: str = DEFAULT_SIGN_SECRET
    refresh_url: str = DEFAULT_REFRESH_URL
    stream_url: str = DEFAULT_AGENT_STREAM_URL
    origin: str = DEFAULT_AGENT_ORIGIN
    model: str = DEFAULT_SIGNED_MODEL

    @classmethod
    def from_env(cls) -> "SignedConfig":
        return cls(
            refresh_token=normalize_refresh_token(os.getenv("AGENTMORE_REFRESH_TOKEN", "")),
            sign_secret=os.getenv("AGENTMORE_SIGN_SECRET", DEFAULT_SIGN_SECRET),
            refresh_url=os.getenv("AGENTMORE_REFRESH_URL", DEFAULT_REFRESH_URL),
            stream_url=os.getenv("AGENTMORE_AGENT_STREAM_URL", DEFAULT_AGENT_STREAM_URL),
            origin=os.getenv("AGENTMORE_AGENT_ORIGIN", DEFAULT_AGENT_ORIGIN).rstrip("/"),
            model=os.getenv("AGENTMORE_SIGNED_MODEL", DEFAULT_SIGNED_MODEL),
        )


def signed_timestamp(now_ms: int | None = None) -> str:
    if now_ms is None:
        now_ms = int(time.time() * 1000)
    digits = [int(ch) for ch in str(now_ms)]
    checksum = (sum(digits) - digits[-2]) % 10
    return "".join(str(digit) for digit in digits[:-2]) + str(checksum) + str(digits[-1])


def signature_headers(secret: str, now_ms: int | None = None, nonce: str | None = None) -> dict[str, str]:
    timestamp = signed_timestamp(now_ms)
    nonce = nonce or uuid.uuid4().hex
    # MD5 is mandated by AgentMore's upstream wire protocol, not used as a security primitive here.
    sign = hashlib.md5(
        f"{timestamp}-{nonce}-{secret}".encode("utf-8"),
        usedforsecurity=False,
    ).hexdigest()
    return {
        "X-Device-Id": uuid.uuid4().hex,
        "X-Nonce": nonce,
        "X-Request-Id": uuid.uuid4().hex,
        "X-Sign": sign,
        "X-Timestamp": timestamp,
    }


def _headers(origin: str, secret: str, bearer: str, referer: str | None = None) -> dict[str, str]:
    headers = {
        "Accept": "text/event-stream",
        "Accept-Encoding": "identity",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "App-Name": "chatglm",
        "Cache-Control": "no-cache",
        "Content-Type": "application/json",
        "Origin": origin,
        "Pragma": "no-cache",
        "Referer": referer or origin.rstrip("/") + "/",
        "X-App-Fr": "browser_extension",
        "X-App-Platform": "pc",
        "X-App-Version": "0.0.1",
        "X-Lang": "zh",
        "Authorization": f"Bearer {bearer}",
    }
    headers.update(signature_headers(secret))
    return headers


def _deep_get(obj: Any, key: str) -> Any:
    if isinstance(obj, dict):
        if key in obj:
            return obj[key]
        for value in obj.values():
            found = _deep_get(value, key)
            if found is not None:
                return found
    elif isinstance(obj, list):
        for item in obj:
            found = _deep_get(item, key)
            if found is not None:
                return found
    return None


def refresh_access_token(config: SignedConfig, timeout: float = 30.0) -> tuple[str, str | None]:
    if not config.refresh_token:
        raise AgentMoreError("AGENTMORE_REFRESH_TOKEN is required for signed transport")
    headers = _headers("https://chatglm.cn", config.sign_secret, config.refresh_token, "https://chatglm.cn/")
    request = urllib.request.Request(config.refresh_url, data=b"{}", headers=headers, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read()
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise AgentMoreError(f"AgentMore token refresh HTTP {exc.code}: {body[:300]}") from exc
    except urllib.error.URLError as exc:
        raise AgentMoreError(f"AgentMore token refresh failed: {exc.reason}") from exc

    try:
        body = json.loads(raw)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise AgentMoreError("AgentMore token refresh returned non-JSON") from exc
    access_token = _deep_get(body, "access_token")
    if not isinstance(access_token, str) or not access_token:
        raise AgentMoreError("AgentMore token refresh response contained no access_token")
    rotated = _deep_get(body, "refresh_token")
    return access_token, rotated if isinstance(rotated, str) and rotated else None


def build_agent_body(
    *,
    assistant_id: str,
    prompt: str,
    conversation_id: str = "",
    model: str = DEFAULT_SIGNED_MODEL,
) -> dict[str, Any]:
    return {
        "assistant_id": assistant_id,
        "conversation_id": conversation_id,
        "project_id": "",
        "chat_type": "user_chat",
        "messages": [{"role": "user", "content": [{"type": "text", "text": prompt}]}],
        "meta_data": {
            "channel": "",
            "chat_mode": "chat_agent",
            "draft_id": "",
            "reasoning_effort": "low",
            "selected_model": model,
            "input_question_type": "xxxx",
            "is_networking": True,
            "is_test": False,
            "platform": "pc",
            "quote_log_id": "",
            "cogview": {"rm_label_watermark": False},
        },
    }


def _decode_agent_event(line: str) -> tuple[dict[str, Any] | None, str]:
    line = line.strip()
    if not line.startswith("data:"):
        return None, ""
    payload = line[5:].strip()
    if not payload:
        return None, ""
    if payload == "[DONE]":
        return None, "done"
    try:
        obj = json.loads(payload)
    except json.JSONDecodeError:
        return None, ""
    return (obj, "") if isinstance(obj, dict) else (None, "")


def _block_text(block: dict[str, Any]) -> str | None:
    block_type = block.get("type")
    if block_type == "text":
        value = block.get("text")
    elif block_type == "execution_output":
        value = block.get("content")
    elif block_type == "code":
        code = block.get("code")
        value = f"```python\n{code}\n```" if isinstance(code, str) and code else None
    else:
        value = None
    return value if isinstance(value, str) and value else None


def _part_text(part: Any) -> tuple[str, str] | None:
    if not isinstance(part, dict):
        return None
    logic_id = part.get("logic_id")
    if not isinstance(logic_id, str) or not logic_id:
        logic_id = "default"
    content = part.get("content")
    if not isinstance(content, list):
        return None
    text = "".join(
        value
        for block in content
        if isinstance(block, dict)
        for value in [_block_text(block)]
        if value is not None
    )
    return (logic_id, text) if text else None


def _frame_text(parts: Any) -> dict[str, str]:
    frame: dict[str, str] = {}
    if not isinstance(parts, list):
        return frame
    for part in parts:
        parsed = _part_text(part)
        if parsed is not None:
            logic_id, text = parsed
            frame[logic_id] = frame.get(logic_id, "") + text
    return frame


class AgentStreamParser:
    def __init__(self) -> None:
        self._text_state: dict[str, str] = {}
        self._text_sent: dict[str, int] = {}
        self._order: list[str] = []

    def _apply_frame(self, frame: dict[str, str], increase_push: bool) -> None:
        for logic_id, value in frame.items():
            previous = self._text_state.get(logic_id, "")
            self._text_state[logic_id] = previous + value if increase_push else value
            if logic_id not in self._order:
                self._order.append(logic_id)

    def _drain_text(self) -> str:
        text_parts: list[str] = []
        for logic_id in self._order:
            full = self._text_state.get(logic_id, "")
            sent = self._text_sent.get(logic_id, 0)
            if len(full) > sent:
                text_parts.append(full[sent:])
                self._text_sent[logic_id] = len(full)
        return "".join(text_parts)

    def parse_line(self, line: str) -> tuple[str, str | None, str]:
        obj, terminal_status = _decode_agent_event(line)
        if terminal_status:
            return "", None, terminal_status
        if obj is None:
            return "", None, ""

        conversation_id = _deep_get(obj, "conversation_id")
        status = str(obj.get("status", "") or "")
        meta = obj.get("meta_data")
        increase_push = isinstance(meta, dict) and bool(meta.get("if_increase_push"))
        self._apply_frame(_frame_text(obj.get("parts")), increase_push)

        return (
            self._drain_text(),
            conversation_id if isinstance(conversation_id, str) else None,
            status,
        )


def send_signed(
    *,
    config: SignedConfig,
    assistant_id: str,
    prompt: str,
    conversation_id: str = "",
    timeout: float = 120.0,
) -> dict[str, Any]:
    access_token, rotated_refresh = refresh_access_token(config)
    body = build_agent_body(
        assistant_id=assistant_id,
        prompt=prompt,
        conversation_id=conversation_id,
        model=config.model,
    )
    headers = _headers(config.origin, config.sign_secret, access_token)
    request = urllib.request.Request(
        config.stream_url,
        data=json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
        headers=headers,
        method="POST",
    )

    parser = AgentStreamParser()
    text_parts: list[str] = []
    response_conversation_id: str | None = None
    final_status = ""
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            for raw_line in response:
                text, event_conversation_id, status = parser.parse_line(
                    raw_line.decode("utf-8", errors="replace")
                )
                if text:
                    text_parts.append(text)
                if event_conversation_id:
                    response_conversation_id = event_conversation_id
                if status:
                    final_status = status
    except urllib.error.HTTPError as exc:
        body_text = exc.read().decode("utf-8", errors="replace")
        raise AgentMoreError(f"AgentMore signed request HTTP {exc.code}: {body_text[:500]}") from exc
    except urllib.error.URLError as exc:
        raise AgentMoreError(f"AgentMore signed request failed: {exc.reason}") from exc

    return {
        "answer": "".join(text_parts),
        "conversation_id": response_conversation_id,
        "status": final_status,
        "refresh_token_rotated": bool(rotated_refresh and rotated_refresh != config.refresh_token),
    }
