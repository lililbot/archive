from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Iterable


class AgentMoreError(RuntimeError):
    pass


@dataclass(frozen=True)
class AgentMoreConfig:
    base_url: str = "https://agentmore.chatglm.cn"
    cookie: str = ""
    csrf_token: str = ""
    model: str = "GLM-Flash"

    @classmethod
    def from_env(cls) -> "AgentMoreConfig":
        return cls(
            base_url=os.getenv("AGENTMORE_BASE_URL", "https://agentmore.chatglm.cn").rstrip("/"),
            cookie=os.getenv("AGENTMORE_COOKIE", ""),
            csrf_token=os.getenv("AGENTMORE_CSRF_TOKEN", ""),
            model=os.getenv("AGENTMORE_MODEL", "GLM-Flash"),
        )


class AgentMoreClient:
    def __init__(self, config: AgentMoreConfig):
        self.config = config

    def task_url(self, agent_id: str) -> str:
        return f"{self.config.base_url}/api/partners/{agent_id}/chat-messages/"

    def build_payload(
        self,
        *,
        conversation_id: str,
        message: str,
        model: str | None = None,
        stream: bool = True,
    ) -> dict[str, Any]:
        return {
            "message": message,
            "stream": stream,
            "conversation_id": conversation_id,
            "model": model or self.config.model,
        }

    def send_message(
        self,
        *,
        agent_id: str,
        conversation_id: str,
        message: str,
        model: str | None = None,
        stream: bool = True,
        timeout: float = 120.0,
    ) -> dict[str, Any]:
        if not self.config.cookie:
            raise AgentMoreError("AGENTMORE_COOKIE is required for live requests")
        if not self.config.csrf_token:
            raise AgentMoreError("AGENTMORE_CSRF_TOKEN is required for live requests")

        url = self.task_url(agent_id)
        payload = self.build_payload(
            conversation_id=conversation_id,
            message=message,
            model=model,
            stream=stream,
        )
        data = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        headers = {
            "Accept": "application/json, text/event-stream, */*",
            "Content-Type": "application/json",
            "Cookie": self.config.cookie,
            "Origin": self.config.base_url,
            "Referer": f"{self.config.base_url}/chat/{agent_id}/{conversation_id}",
            "X-CSRF-Token": self.config.csrf_token,
        }
        request = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                body = response.read()
                content_type = response.headers.get("Content-Type", "")
                status = getattr(response, "status", 200)
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise AgentMoreError(f"AgentMore HTTP {exc.code}: {body[:500]}") from exc
        except urllib.error.URLError as exc:
            raise AgentMoreError(f"AgentMore request failed: {exc.reason}") from exc

        parsed = parse_body(body, content_type)
        return {"http_status": status, "content_type": content_type, **parsed}


def _json_object(text: str) -> Any:
    return json.loads(text)


def _decode_sse_data(raw: str) -> Any:
    if raw == "[DONE]":
        return raw
    try:
        return _json_object(raw)
    except (json.JSONDecodeError, TypeError):
        return raw


def _sse_event(event_name: str | None, data_lines: list[str]) -> dict[str, Any] | None:
    if not data_lines and event_name is None:
        return None
    return {
        "event": event_name,
        "data": _decode_sse_data("\n".join(data_lines)),
    }


def parse_sse(text: str) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    event_name: str | None = None
    data_lines: list[str] = []

    for line in text.splitlines():
        if not line:
            event = _sse_event(event_name, data_lines)
            if event is not None:
                events.append(event)
            event_name = None
            data_lines = []
            continue
        if line.startswith(":"):
            continue
        if line.startswith("event:"):
            event_name = line[6:].strip() or None
        elif line.startswith("data:"):
            data_lines.append(line[5:].lstrip())

    event = _sse_event(event_name, data_lines)
    if event is not None:
        events.append(event)
    return events


def _candidate_objects(events: Iterable[dict[str, Any]]) -> Iterable[dict[str, Any]]:
    for event in events:
        data = event.get("data")
        if isinstance(data, dict):
            yield data
            nested = data.get("data")
            if isinstance(nested, dict):
                yield nested


def extract_answer(objects: Iterable[dict[str, Any]]) -> str | None:
    answer: str | None = None
    for obj in objects:
        for key in ("answer", "content", "text"):
            value = obj.get(key)
            if isinstance(value, str) and value:
                answer = value
    return answer


def parse_body(body: bytes, content_type: str) -> dict[str, Any]:
    text = body.decode("utf-8", errors="replace")
    lowered = content_type.lower()
    if "text/event-stream" in lowered or any(
        line.startswith(("data:", "event:")) for line in text.splitlines()[:5]
    ):
        events = parse_sse(text)
        return {
            "format": "sse",
            "events": events,
            "answer": extract_answer(_candidate_objects(events)),
        }

    try:
        data = _json_object(text)
    except json.JSONDecodeError:
        return {"format": "text", "text": text, "answer": text or None}

    objects = [data] if isinstance(data, dict) else []
    return {"format": "json", "data": data, "answer": extract_answer(objects)}


def _print_json(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Minimal AgentMore private-web adapter")
    sub = parser.add_subparsers(dest="command", required=True)

    send = sub.add_parser("send", help="send a task to an existing AgentMore partner")
    send.add_argument(
        "--agent-id",
        default=os.getenv("AGENTMORE_AGENT_ID"),
        required=not bool(os.getenv("AGENTMORE_AGENT_ID")),
    )
    send.add_argument(
        "--conversation-id",
        default=os.getenv("AGENTMORE_CONVERSATION_ID"),
        required=not bool(os.getenv("AGENTMORE_CONVERSATION_ID")),
    )
    send.add_argument("--message", required=True)
    send.add_argument("--model", default=None)
    send.add_argument("--no-stream", action="store_true")
    send.add_argument("--dry-run", action="store_true")
    send.add_argument("--answer-only", action="store_true")

    create = sub.add_parser("create", help="create a fresh AgentMore partner")
    create.add_argument("--name", required=True)

    args = parser.parse_args(argv)
    config = AgentMoreConfig.from_env()
    client = AgentMoreClient(config)

    if args.command == "create":
        raise AgentMoreError(
            "partner creation is intentionally unsupported until its authenticated HTTP contract is observed"
        )

    payload = client.build_payload(
        conversation_id=args.conversation_id,
        message=args.message,
        model=args.model,
        stream=not args.no_stream,
    )
    if args.dry_run:
        _print_json({"method": "POST", "url": client.task_url(args.agent_id), "payload": payload})
        return 0

    result = client.send_message(
        agent_id=args.agent_id,
        conversation_id=args.conversation_id,
        message=args.message,
        model=args.model,
        stream=not args.no_stream,
    )
    if args.answer_only:
        answer = result.get("answer")
        if not isinstance(answer, str) or not answer:
            raise AgentMoreError("AgentMore response contained no extractable answer")
        print(answer)
        return 0
    _print_json(result)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AgentMoreError as exc:
        print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(2)
