import hashlib
import unittest

from signed import (
    AgentStreamParser,
    build_agent_body,
    normalize_refresh_token,
    signature_headers,
    signed_timestamp,
)


class SignedTransportTests(unittest.TestCase):
    def test_signature(self):
        now_ms = 1770000000123
        nonce = "abc"
        timestamp = signed_timestamp(now_ms)
        headers = signature_headers("secret", now_ms=now_ms, nonce=nonce)
        expected = hashlib.md5(f"{timestamp}-{nonce}-secret".encode("utf-8")).hexdigest()
        self.assertEqual(headers["X-Timestamp"], timestamp)
        self.assertEqual(headers["X-Nonce"], nonce)
        self.assertEqual(headers["X-Sign"], expected)

    def test_normalize_refresh_token(self):
        self.assertEqual(normalize_refresh_token(" token-value "), "token-value")
        self.assertEqual(normalize_refresh_token("Bearer token-value"), "token-value")
        self.assertEqual(
            normalize_refresh_token("chatglm_refresh_token=token-value"),
            "token-value",
        )
        self.assertEqual(
            normalize_refresh_token("foo=bar; chatglm_refresh_token=token-value; baz=qux"),
            "token-value",
        )
        self.assertEqual(
            normalize_refresh_token("'chatglm_refresh_token=token-value'"),
            "token-value",
        )

    def test_agent_body(self):
        body = build_agent_body(assistant_id="asst_1", prompt="hello")
        self.assertEqual(body["assistant_id"], "asst_1")
        self.assertEqual(body["messages"][0]["content"][0]["text"], "hello")
        self.assertEqual(body["meta_data"]["chat_mode"], "chat_agent")
        self.assertTrue(body["meta_data"]["is_networking"])

    def test_stream_parser(self):
        parser = AgentStreamParser()
        text, conversation_id, status = parser.parse_line(
            'data: {"conversation_id":"conv_1","parts":[{"logic_id":"1","content":[{"type":"text","text":"wake-ok"}]}],"status":"finish"}'
        )
        self.assertEqual(text, "wake-ok")
        self.assertEqual(conversation_id, "conv_1")
        self.assertEqual(status, "finish")


if __name__ == "__main__":
    unittest.main()
