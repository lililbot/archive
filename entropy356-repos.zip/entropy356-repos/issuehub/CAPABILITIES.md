# CAPABILITIES.md

This file is the current capability-routing table for collaboration.

Capability cards are keyed by **`Platform: Mode`**, not by model instance, session, or individual agent. They describe what a role can reliably execute and verify **now**. When capabilities change, replace the current card; Git is the history layer.

Use these cards to choose `owner` / `next_actor`. A wake is transport only and should target the actor already named in the Work Item.

## ChatGPT: Chat

### Good fit

- Coordinate Work Items, review handoffs, and reconcile current project truth across repositories.
- Read and write GitHub repositories through the connected GitHub integration: files, branches, commits, Issues, PRs, reviews, reactions, CI status/logs, and related metadata within granted permissions.
- Perform current public-web research and source-backed verification.
- Use local Python/container execution for code inspection, tests, data work, and generated artifacts when dependencies and inputs are available.
- Work with connected services/plugins when available, including Google Drive and specialized browser/web tooling.
- Create scheduled or condition-based ChatGPT tasks when future execution is explicitly requested.
- Review implementation changes independently of the implementing agent and drive reviewer -> implementer handoffs.

### Browser / network boundary

- Public-web search/fetch is available through platform web tools.
- Browser interaction can use connected browser-automation tooling when that tool supports the required operation.
- The local execution container is **not** a reliable general browser host: it may lack direct outbound DNS/network access, and the hosted Chromium environment has been observed blocking navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`.
- A locally started `agent-browser` can exercise its service/session/profile lifecycle, but this ChatGPT-hosted Chromium environment should not be used as the canonical remote Browser Worker.
- The currently available external browser-automation path can reach public HTTPS endpoints, but it cannot be relied on to inject arbitrary HTTP headers such as a custom `Authorization` header for raw API calls.
- Therefore authenticated remote `agent-browser` use requires a caller/tool path that can send its HTTP API requests with the required credentials; do not assume ordinary browser automation is equivalent to a general HTTP client.

### Execution / lifecycle boundary

- Normal chat execution is synchronous: do not assign work that requires an assistant process to remain alive after the response unless it is represented by a supported scheduled/condition task.
- The local container is ephemeral and should not own long-lived services, durable browser profiles, or inbound public endpoints.
- Do not treat temporary runtime credentials, URLs, mounted files, or local process state as durable project state.

### Human-required or external boundary

Route to `Human` or another platform/mode when work requires:

- purchasing infrastructure or accepting charges,
- physical-device interaction or account verification unavailable to connected tools,
- supplying/rotating secrets that should not be posted into project state,
- hosting a durable public service when no connected runtime provides that host,
- a UI capability or authenticated action not exposed by the available integrations.

### Routing shorthand

Prefer `ChatGPT` / `ChatGPT: Chat` for **coordination, review, research, repository operations, and tool-supported execution**.

Do not route **durable hosting, unrestricted browser egress, arbitrary inbound networking, or unsupported authenticated HTTP calls** here unless a connected external runtime/tool explicitly provides that capability.

## ChatGPT: Work

### Good fit

- Execute multi-step Work Items using the Work cloud runtime, connected repository tools, shell/code execution, and browser/computer interaction where available.
- Implement repository changes on a branch, run local checks/tests, create PRs, inspect CI results, and update the canonical Work Item with evidence.
- Author and edit ChatGPT Sites, including Site-hosted MCP source, when the Sites authoring skill/tools are available.
- Run focused integration probes and return durable results through the Work Item; hand back to `ChatGPT: Chat` for independent review when the Work Item calls for it.

### Execution / lifecycle boundary

- Work is task-based, not a guaranteed persistent daemon. Do not treat a completed Work run or its cloud runtime as an always-on service host.
- A successful local test is not evidence of a deployed Site/plugin. Keep preview, saved source, published Site, installed plugin, and verified in-chat invocation as distinct states.
- Use current repository instructions and explicit Work Item routing; do not infer authorization to publish a Site, expose a service, configure secrets, or merge a PR from implementation access alone.
- Repository writes should be reviewable. Do not merge without explicit user approval of the exact reviewed head SHA.

### Browser / network boundary

- Work can use outbound web/network access when available in its runtime, but that is not by itself proof of a general-purpose authenticated HTTP client or a safe public-only egress boundary.
- Current Sites documentation supports HTTP/HTTPS/WebSockets but not raw inbound/outbound TCP. No Sites address-pinning API or public-only egress policy has been demonstrated in this project; DNS preflight followed by ordinary `fetch` is insufficient against DNS rebinding.
- Do not publish a generic arbitrary-URL HTTP tool until the destination IP is enforced at the actual connection or a documented runtime-level egress policy has been verified.
- GitHub Actions workflows can be authored and verified when repository permissions and event triggers allow it; do not assume an unavailable direct dispatch tool or that a workflow has run just because it was committed.

### Human-required or external boundary

Route to `Human` when work requires:

- buying infrastructure or accepting new charges,
- configuring secrets through a UI when no safe secret-management tool is available,
- account/workspace permission changes or verification unavailable to Work,
- approval to publish/share a Site, expose a public service, or merge a reviewed PR.

### Routing shorthand

Prefer `ChatGPT: Work` for **multi-step implementation, cloud execution, Site authoring, and implementation-side verification**.

Prefer `ChatGPT: Chat` for **independent review, architecture decisions, public-web research, and reconciliation of canonical project state**. Never assume Work's outbound access removes the need for destination validation, secret boundaries, or deployment verification.
