---
name: Work item
about: A unit of unresolved or actionable work
title: ""
labels: ""
assignees: ""
---

## Goal

What should become true?

## Why now

Why is this worth attention now?

## Mode

AI / Human / Joint

## Current truth

What is already known or already exists?

## Definition of done

What observable state means this can be closed?

## Constraints

Only constraints that materially affect execution.
