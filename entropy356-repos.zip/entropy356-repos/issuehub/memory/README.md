# Durable context

Store only distilled context that is both:

1. useful across future work sessions, and
2. not more naturally owned by code, an Issue, a project document, or another external system.

## What belongs here

- stable personal working conventions relevant to collaboration;
- cross-project constraints;
- compact conceptual models that repeatedly affect decisions.

## What does not belong here

- chat transcripts;
- chronological logs;
- stale versions of facts;
- duplicated project documentation;
- speculative notes that can live as Issues until resolved.

The desired end state is small enough that an agent can read it cheaply and regain useful context quickly.
