# GitHub-native A2A transport

Status: **experimental v0**. This is not yet a conformant A2A custom protocol binding.

Canonical work item: #8 (completed).

## Goal

Use GitHub itself as the transport, durable state store, concurrency boundary, and execution trigger for agent-to-agent tasks. No privately operated always-on application server is required.

Standard A2A remains the compatibility edge. GitHub is the source of truth.

## Why this is experimental

A2A 1.0 allows custom protocol bindings, but a conformant binding must preserve the A2A data model and operation semantics. This v0 deliberately implements only the smallest repository-native loop needed to test the architecture.

The current implementation supports:

- create a task with an initial user message
- get current task state
- send another message / advance task state
- cancel a task
- optimistic stale-write rejection

It does **not** yet implement:

- `SendStreamingMessage`
- `SubscribeToTask`
- push-notification configuration operations
- `GetExtendedAgentCard`
- complete A2A Part / Artifact coverage
- a published Agent Card claiming this binding

Therefore clients must treat this as `github-a2a-v0`, not as a generally interoperable A2A binding.

## Transport identity

Experimental binding identifier:

`https://github.com/entropy356/issuehub/tree/main/projects/github-a2a#v0`

Repository endpoint:

`https://api.github.com/repos/<owner>/<repo>`

Authentication is ordinary GitHub authentication. For a private repository, a caller needs enough repository permission to read and update task branches. No credentials are stored in task documents.

## Canonical layout

Each task owns one branch:

```text
a2a/task/<task-id>
```

Each task branch contains one canonical task document:

```text
a2a/task.json
```

Task branches are created from the repository default branch. The task document is the only protocol-owned mutable state in v0.

Issues and PRs may project a task for humans, but they are not canonical transport state.

## Task document

The v0 document keeps transport metadata outside the A2A-shaped task payload:

```json
{
  "transportVersion": "0",
  "protocolVersion": "1.0",
  "task": {
    "id": "f8d0...",
    "contextId": "6c90...",
    "status": {
      "state": "TASK_STATE_SUBMITTED",
      "timestamp": "2026-10-25T00:00:00.000Z"
    },
    "history": [
      {
        "role": "ROLE_USER",
        "parts": [
          { "text": "Do the thing." }
        ],
        "messageId": "891b...",
        "taskId": "f8d0...",
        "contextId": "6c90..."
      }
    ],
    "artifacts": []
  }
}
```

The prototype intentionally starts with text messages. The document shape should move toward the canonical A2A v1 data model as support expands; transport-specific revision data must remain outside the A2A task object.

## Revision and concurrency

The GitHub Contents API returns a blob SHA for `a2a/task.json`. That SHA is the opaque task revision.

A state-changing client must:

1. read `a2a/task.json` from the task branch;
2. retain its returned blob SHA;
3. construct the next complete task document;
4. update `a2a/task.json` while supplying the retained SHA.

If another writer changed the file first, the update fails instead of silently overwriting the newer state. The client then reads the latest task, reconciles semantically, and retries.

There is no separate lock service.

This is deliberately narrower than using the branch head as the revision. Other files may change on a task branch without invalidating a task-state update; only concurrent changes to the canonical task document conflict.

## Operation mapping

### Create / initial SendMessage

1. Read the default branch head.
2. Generate a task ID and context ID.
3. Create `a2a/task/<task-id>` at that head.
4. Create `a2a/task.json` with `TASK_STATE_SUBMITTED` and the initial `ROLE_USER` message.
5. Return the task plus the created file SHA as transport revision.

This is the current v0 equivalent of creating work through `SendMessage`.

### GetTask

Read `a2a/task.json` from `a2a/task/<task-id>` and return:

- `task`: the task payload
- `revision`: the current file SHA

### SendMessage to an existing task

1. Read the current document and revision.
2. Reject locally if the caller supplied a different expected revision.
3. Append the new message.
4. Advance status as requested.
5. Update the file with the expected GitHub SHA.
6. Translate GitHub stale-write failures into `revision_conflict` for the prototype client.

### CancelTask

Read the task, reject stale revisions, set status to `TASK_STATE_CANCELED`, and update with the expected SHA.

Terminal tasks are not advanced by the prototype.

### ListTasks

Not implemented by the v0 client. A future implementation can enumerate branches under `a2a/task/` and read their task documents, then add filtering/pagination semantics compatible with A2A `ListTasks`.

### Streaming and subscription

GitHub does not provide an A2A event stream directly. v0 clients poll `GetTask`.

A conformant custom binding cannot simply rename polling as streaming. Before this project claims A2A custom-binding conformance, streaming/subscription semantics must either be implemented faithfully with GitHub primitives or explicitly delegated to a thin compatibility adapter in a way permitted by the current A2A specification.

### Push notifications

Not implemented in v0. GitHub Actions and `repository_dispatch` are candidate primitives, but authentication, delivery semantics, retries, ordering, and A2A push-notification configuration behavior must be specified before adoption.

## Execution trigger

`.github/workflows/github-a2a.yml` runs whenever `a2a/task.json` changes on an `a2a/task/**` branch.

The workflow:

- validates the task document with the dependency-free prototype client;
- uses one concurrency group per task branch;
- does not serialize unrelated tasks.

The workflow is intentionally only a validator in v0. An executor can be added later without changing the transport contract.

## Prototype client

`client.py` uses only the Python standard library and GitHub REST API.

Examples:

```bash
export GITHUB_TOKEN=...
export GITHUB_REPOSITORY=entropy356/issuehub

python projects/github-a2a/client.py create "Investigate X"

python projects/github-a2a/client.py get <task-id>

python projects/github-a2a/client.py send <task-id> "Here is the next instruction" \
  --expected-revision <sha>

python projects/github-a2a/client.py cancel <task-id> \
  --expected-revision <sha>
```

For normal collaborative use, callers should pass `--expected-revision` on mutations. Omitting it means "use the revision I just read", which still detects a race between that read and the write but does not protect against the caller acting on older state held elsewhere.

## Validated behavior

The v0 repository-only loop has been exercised with a real task branch.

Two independent writers read the same `a2a/task.json` revision. Writer A updated first. Writer B then attempted an update using the original SHA and GitHub rejected it with HTTP 409 rather than overwriting A. Writer B re-read the latest canonical state, preserved A's change, and retried successfully. The same revision-checked path then canceled the task successfully.

GitHub Actions validated task creation, Writer A's accepted update, Writer B's reconciled retry, and cancellation successfully.

This establishes the v0 architectural claim: GitHub can provide durable task state, optimistic concurrency, and execution triggers without a separate lock service or privately operated always-on application server.

The transport should not expand merely to imitate the whole A2A surface. Additional A2A semantics or a thin standard-A2A adapter should be added only when a concrete interoperability requirement justifies them.
