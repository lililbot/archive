#!/usr/bin/env python3
"""Minimal GitHub-native transport client for issuehub's experimental A2A profile.

No third-party dependencies. Authentication uses a GitHub token from --token or
GITHUB_TOKEN.
"""

from __future__ import annotations

import argparse
import base64
import datetime as dt
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid
from typing import Any

API_VERSION = "2022-11-28"
TASK_PATH = "a2a/task.json"
TASK_BRANCH_PREFIX = "a2a/task/"
TRANSPORT_VERSION = "0"
A2A_PROTOCOL_VERSION = "1.0"

TASK_STATES = {
    "TASK_STATE_SUBMITTED",
    "TASK_STATE_WORKING",
    "TASK_STATE_COMPLETED",
    "TASK_STATE_FAILED",
    "TASK_STATE_CANCELED",
    "TASK_STATE_REJECTED",
    "TASK_STATE_INPUT_REQUIRED",
    "TASK_STATE_AUTH_REQUIRED",
}
TERMINAL_STATES = {
    "TASK_STATE_COMPLETED",
    "TASK_STATE_FAILED",
    "TASK_STATE_CANCELED",
    "TASK_STATE_REJECTED",
}


class GitHubError(RuntimeError):
    def __init__(self, status: int, message: str, payload: Any = None):
        super().__init__(f"GitHub API {status}: {message}")
        self.status = status
        self.payload = payload


class GitHub:
    def __init__(self, repo: str, token: str):
        if "/" not in repo:
            raise ValueError("--repo must be owner/name")
        self.repo = repo
        self.token = token
        self.base = f"https://api.github.com/repos/{repo}"

    def request(self, method: str, path: str, body: Any = None) -> Any:
        url = path if path.startswith("https://") else self.base + path
        data = None if body is None else json.dumps(body).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            method=method,
            headers={
                "Accept": "application/vnd.github+json",
                "Authorization": f"Bearer {self.token}",
                "X-GitHub-Api-Version": API_VERSION,
                "User-Agent": "issuehub-github-a2a-v0",
                **({"Content-Type": "application/json"} if data is not None else {}),
            },
        )
        try:
            with urllib.request.urlopen(req) as resp:
                raw = resp.read()
                return None if not raw else json.loads(raw.decode("utf-8"))
        except urllib.error.HTTPError as exc:
            raw = exc.read().decode("utf-8", errors="replace")
            try:
                payload = json.loads(raw)
                message = payload.get("message", raw)
            except json.JSONDecodeError:
                payload = raw
                message = raw
            raise GitHubError(exc.code, message, payload) from exc

    def repo_info(self) -> dict[str, Any]:
        return self.request("GET", "")

    def ref(self, branch: str) -> dict[str, Any]:
        branch_path = urllib.parse.quote(branch, safe="/")
        return self.request("GET", f"/git/ref/heads/{branch_path}")

    def create_branch(self, branch: str, sha: str) -> None:
        self.request("POST", "/git/refs", {"ref": f"refs/heads/{branch}", "sha": sha})

    def get_file(self, branch: str, path: str = TASK_PATH) -> tuple[dict[str, Any], str]:
        encoded_path = urllib.parse.quote(path, safe="/")
        ref = urllib.parse.quote(branch, safe="")
        result = self.request("GET", f"/contents/{encoded_path}?ref={ref}")
        if result.get("type") != "file":
            raise RuntimeError(f"{path} on {branch} is not a file")
        raw = base64.b64decode(result["content"]).decode("utf-8")
        return json.loads(raw), result["sha"]

    def put_file(
        self,
        branch: str,
        document: dict[str, Any],
        message: str,
        expected_sha: str | None = None,
        path: str = TASK_PATH,
    ) -> dict[str, Any]:
        encoded_path = urllib.parse.quote(path, safe="/")
        body: dict[str, Any] = {
            "message": message,
            "content": base64.b64encode(
                (json.dumps(document, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
            ).decode("ascii"),
            "branch": branch,
        }
        if expected_sha is not None:
            body["sha"] = expected_sha
        return self.request("PUT", f"/contents/{encoded_path}", body)


def utc_now() -> str:
    return (
        dt.datetime.now(dt.timezone.utc)
        .isoformat(timespec="milliseconds")
        .replace("+00:00", "Z")
    )


def task_branch(task_id: str) -> str:
    return TASK_BRANCH_PREFIX + task_id


def new_message(role: str, text: str, task_id: str, context_id: str) -> dict[str, Any]:
    return {
        "role": role,
        "parts": [{"text": text}],
        "messageId": str(uuid.uuid4()),
        "taskId": task_id,
        "contextId": context_id,
    }


def _validate_status(status: Any) -> None:
    if not isinstance(status, dict) or status.get("state") not in TASK_STATES:
        raise ValueError("task.status.state is invalid")
    if not isinstance(status.get("timestamp"), str):
        raise ValueError("task.status.timestamp is required")


def _validate_history(history: Any) -> None:
    if not isinstance(history, list):
        raise ValueError("task.history must be an array")
    for i, message in enumerate(history):
        if not isinstance(message, dict):
            raise ValueError(f"task.history[{i}] must be an object")
        if message.get("role") not in {"ROLE_USER", "ROLE_AGENT"}:
            raise ValueError(f"task.history[{i}].role is invalid")
        if not isinstance(message.get("messageId"), str):
            raise ValueError(f"task.history[{i}].messageId is required")
        if not isinstance(message.get("parts"), list) or not message["parts"]:
            raise ValueError(f"task.history[{i}].parts must be a non-empty array")


def validate_document(document: dict[str, Any]) -> None:
    if document.get("transportVersion") != TRANSPORT_VERSION:
        raise ValueError(f"transportVersion must be {TRANSPORT_VERSION!r}")
    if document.get("protocolVersion") != A2A_PROTOCOL_VERSION:
        raise ValueError(f"protocolVersion must be {A2A_PROTOCOL_VERSION!r}")
    task = document.get("task")
    if not isinstance(task, dict):
        raise ValueError("task must be an object")
    for key in ("id", "contextId", "status", "history", "artifacts"):
        if key not in task:
            raise ValueError(f"task.{key} is required")
    _validate_status(task["status"])
    _validate_history(task["history"])
    if not isinstance(task["artifacts"], list):
        raise ValueError("task.artifacts must be an array")


def cmd_create(args: argparse.Namespace) -> None:
    gh = GitHub(args.repo, args.token)
    info = gh.repo_info()
    base_branch = args.base or info["default_branch"]
    base_sha = gh.ref(base_branch)["object"]["sha"]

    task_id = args.task_id or str(uuid.uuid4())
    context_id = args.context_id or str(uuid.uuid4())
    branch = task_branch(task_id)

    document = {
        "transportVersion": TRANSPORT_VERSION,
        "protocolVersion": A2A_PROTOCOL_VERSION,
        "task": {
            "id": task_id,
            "contextId": context_id,
            "status": {
                "state": "TASK_STATE_SUBMITTED",
                "timestamp": utc_now(),
            },
            "history": [
                new_message("ROLE_USER", args.message, task_id, context_id)
            ],
            "artifacts": [],
        },
    }
    validate_document(document)
    gh.create_branch(branch, base_sha)
    result = gh.put_file(branch, document, f"a2a: create task {task_id}")
    print_json(
        {
            "task": document["task"],
            "branch": branch,
            "revision": result["content"]["sha"],
        }
    )


def cmd_get(args: argparse.Namespace) -> None:
    gh = GitHub(args.repo, args.token)
    document, sha = gh.get_file(task_branch(args.task_id))
    validate_document(document)
    print_json({"task": document["task"], "revision": sha})


def cmd_send(args: argparse.Namespace) -> None:
    gh = GitHub(args.repo, args.token)
    branch = task_branch(args.task_id)
    document, current_sha = gh.get_file(branch)

    expected = args.expected_revision or current_sha
    if args.expected_revision and args.expected_revision != current_sha:
        raise GitHubError(
            409,
            "revision_conflict",
            {"expected": args.expected_revision, "current": current_sha},
        )

    validate_document(document)
    task = document["task"]
    if task["status"]["state"] in TERMINAL_STATES:
        raise ValueError(f"task is terminal: {task['status']['state']}")
    task["history"].append(
        new_message(args.role, args.message, task["id"], task["contextId"])
    )
    task["status"] = {
        "state": args.state or "TASK_STATE_WORKING",
        "timestamp": utc_now(),
    }
    validate_document(document)

    try:
        result = gh.put_file(
            branch,
            document,
            f"a2a: message on task {args.task_id}",
            expected_sha=expected,
        )
    except GitHubError as exc:
        if exc.status in {409, 422}:
            latest, latest_sha = gh.get_file(branch)
            raise GitHubError(
                409,
                "revision_conflict",
                {"expected": expected, "current": latest_sha, "latest": latest["task"]},
            ) from exc
        raise
    print_json({"task": document["task"], "revision": result["content"]["sha"]})


def cmd_cancel(args: argparse.Namespace) -> None:
    gh = GitHub(args.repo, args.token)
    branch = task_branch(args.task_id)
    document, current_sha = gh.get_file(branch)
    expected = args.expected_revision or current_sha
    if args.expected_revision and args.expected_revision != current_sha:
        raise GitHubError(
            409,
            "revision_conflict",
            {"expected": args.expected_revision, "current": current_sha},
        )
    validate_document(document)
    task = document["task"]
    if task["status"]["state"] in TERMINAL_STATES:
        print_json({"task": task, "revision": current_sha})
        return
    task["status"] = {
        "state": "TASK_STATE_CANCELED",
        "timestamp": utc_now(),
    }
    validate_document(document)
    try:
        result = gh.put_file(
            branch,
            document,
            f"a2a: cancel task {args.task_id}",
            expected_sha=expected,
        )
    except GitHubError as exc:
        if exc.status in {409, 422}:
            latest, latest_sha = gh.get_file(branch)
            raise GitHubError(
                409,
                "revision_conflict",
                {"expected": expected, "current": latest_sha, "latest": latest["task"]},
            ) from exc
        raise
    print_json({"task": document["task"], "revision": result["content"]["sha"]})


def cmd_validate(args: argparse.Namespace) -> None:
    with open(args.file, "r", encoding="utf-8") as fh:
        document = json.load(fh)
    validate_document(document)
    print(f"{args.file}: valid")


def print_json(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--repo",
        default=os.environ.get("GITHUB_REPOSITORY"),
        help="GitHub repository as owner/name (or GITHUB_REPOSITORY)",
    )
    parser.add_argument(
        "--token",
        default=os.environ.get("GITHUB_TOKEN"),
        help="GitHub token (or GITHUB_TOKEN)",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    create = sub.add_parser("create")
    create.add_argument("message")
    create.add_argument("--task-id")
    create.add_argument("--context-id")
    create.add_argument("--base")
    create.set_defaults(func=cmd_create)

    get = sub.add_parser("get")
    get.add_argument("task_id")
    get.set_defaults(func=cmd_get)

    send = sub.add_parser("send")
    send.add_argument("task_id")
    send.add_argument("message")
    send.add_argument("--role", choices=["ROLE_USER", "ROLE_AGENT"], default="ROLE_USER")
    send.add_argument("--state", choices=sorted(TASK_STATES))
    send.add_argument("--expected-revision")
    send.set_defaults(func=cmd_send)

    cancel = sub.add_parser("cancel")
    cancel.add_argument("task_id")
    cancel.add_argument("--expected-revision")
    cancel.set_defaults(func=cmd_cancel)

    validate = sub.add_parser("validate")
    validate.add_argument("file")
    validate.set_defaults(func=cmd_validate)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.command != "validate":
        if not args.repo:
            parser.error("--repo or GITHUB_REPOSITORY is required")
        if not args.token:
            parser.error("--token or GITHUB_TOKEN is required")

    try:
        args.func(args)
        return 0
    except (ValueError, RuntimeError) as exc:
        print(str(exc), file=sys.stderr)
        if isinstance(exc, GitHubError) and exc.payload is not None:
            print(json.dumps(exc.payload, ensure_ascii=False, indent=2), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
