# Project index

This file lists current project directions. Implementation should live in dedicated repositories when a direction becomes concrete enough to deserve one.

| Project / direction | State | Default mode | Canonical work item |
| --- | --- | --- | --- |
| GitHub-based AI collaboration system | active exploration | Joint | #3 |
| Cross-platform AI collaboration MCP | validated v0 | Joint | #2 (completed) |
| GitHub-native A2A transport | validated v0 | AI | #8 (completed) |
| Token resources | idea | AI | #1 |
| AI-native OS | exploration | Joint | #4 |
| GitHub-hosted AI memory layer | exploration | Joint | #5 |
| Android text role-play game with Git-like story tree | idea | Joint | #6 |
| Browser Worker (own browser execution layer) | v0 standalone | AI | #20 |

Current protocol surfaces:

- `collab-mcp/PROTOCOL.md` — validated v0 shared collaboration state exposed through MCP; implementation is under `prototypes/collab-mcp`.
- `github-a2a/PROTOCOL.md` — validated experimental repository-native task transport using SHA-checked optimistic writes and Actions; not a conformant A2A custom binding.
- `entropy356/agent-browser` — canonical Browser Worker implementation and protocol: https://github.com/entropy356/agent-browser

Further protocol changes should come from concrete dogfooding evidence or interoperability needs, not speculative expansion.

Move implementation to a dedicated repository only when a direction proves that the boundary is useful.

Keep this index compact. Do not duplicate detailed project plans here.
