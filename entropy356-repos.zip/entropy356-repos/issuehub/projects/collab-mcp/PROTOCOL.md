# Cross-platform AI collaboration MCP — v0

Status: **validated v0, explicit-handoff extension**
Canonical work item: #2 (completed); handoff extension: #24

## Decision

The system is a **shared collaboration state layer exposed through MCP**, not a direct agent-to-agent messaging protocol.

Any AI host that can call ordinary MCP tools can enter the same workspace, inspect the same work item, advance it, and leave a compact resumable state for another host. Agents do not need access to each other's private conversation state.

```text
AI host A ─┐
AI host B ─┼─ MCP ─ collab server ─ backend
AI host C ─┘                    └─ GitHub first
```

Direct agent-to-agent communication, if later required, belongs above or beside this layer and should compose with A2A rather than being reinvented here.

## Core contract

A fresh agent with only workspace access must be able to:

1. discover current workspace state;
2. find a work item;
3. read enough current truth to continue without chat replay;
4. perform one revision-checked transition that advances the work and routes it onward;
5. leave the item equally or more resumable for the next agent.

The semantic contract depends only on ordinary MCP tool calls. MCP Tasks, elicitation, sampling, subscriptions, server-initiated requests, and other optional features are not required for the core handoff loop.

Streamable HTTP is the preferred remote transport; stdio is supported for local use.

## Actors, state, and routing

Two fields carry routing, so a reader does not have to infer who moves next from prose:

- `owner` — the role accountable for the item right now.
- `next_actor` — the role expected to make the next move; empty when the item is closed or parked.

Actor identifiers name a **platform/mode role** (`CodeBuddy`, `ChatGPT`, `Human`), not an agent instance. Replacing a model or starting a new session does not change the actor. Comparisons are exact: a host that rewrites `CodeBuddy` as `codebuddy` creates a different actor, so reuse the spelling already in the WorkItem.

`active` means one actor is actively responsible for continuing the work. Therefore an active WorkItem must route back to itself: `owner` and `next_actor` are both non-empty and equal. An actor that needs someone else to move next must make the reason explicit in state: `review` for reviewable output, `blocked` for a dependency/decision/external wait, or `done` when closure invariants are satisfied. `active` with `owner != next_actor` is rejected rather than leaving an unfinished item ambiguously handed away.

State vocabulary stays small on purpose:

| state | meaning |
| --- | --- |
| `open` | accepted, nobody has started |
| `active` | one actor is implementing/operating and remains next to act |
| `review` | implementation exists and awaits review |
| `blocked` | waiting on a decision, access, or external event |
| `done` | closed with evidence |

The normal loop is:

```text
active (codebuddy) -> review (chatgpt) -> active (codebuddy, if changes) -> review -> done
```

`next_actor` is what distinguishes "the reviewer must look" from "the implementer must continue"; a larger state taxonomy would duplicate it.

**`done` requires evidence.** A transition to `done` is rejected unless the WorkItem carries at least one artifact. An implementer hands off to `review`; it does not self-declare completion. Reviewers close.

Wake is a transport concern and stays outside this protocol, but its routing semantics are edge-triggered by the WorkItem. A host may emit **at most one** pointer such as `[wake:codebuddy] work:#24` when a create/transition newly assigns `next_actor` to that actor. Reading, polling, retrying, or rewriting the WorkItem while `next_actor` remains the same does **not** create another wake. After a wake is consumed, reminder wakes for that same assignment are not part of the protocol. The same actor may be woken again only after routing moves away from it and a later transition assigns `next_actor` back to it. The collaboration core stores no wake history, acknowledgement field, retry timer, or reminder state; a transport may deduplicate delivery using its own ephemeral mechanics.

## Non-goals

v0 does not define:

- agent-to-agent chat or RPC;
- model routing or delegation;
- shared hidden chain-of-thought;
- transcript synchronization;
- autonomous scheduling, or a wake transport;
- a handoff history object;
- a universal artifact store;
- a new identity or authorization system.

Authentication and authorization are backend concerns. Artifact contents remain in their canonical systems and are referenced by URI.

## Shared objects

### Workspace

```json
{
  "id": "string",
  "revision": "opaque-string",
  "summary": "string",
  "active_work": ["work-id"],
  "links": [{"rel": "string", "uri": "string"}]
}
```

`summary` is the smallest useful global resume point. It is current state, not a timeline.

### WorkItem

```json
{
  "id": "string",
  "revision": "opaque-string",
  "title": "string",
  "state": "open | active | review | blocked | done",
  "mode": "ai | human | joint",
  "owner": "string",
  "next_actor": "string",
  "goal": "string",
  "current_truth": "string",
  "constraints": ["string"],
  "next_actions": ["string"],
  "blockers": ["string"],
  "artifacts": [
    {"uri": "string", "role": "string", "label": "string"}
  ]
}
```

The WorkItem is a **current snapshot**. Historical versions belong to backend history rather than the current object. A reader should be able to answer "what is true, what exists, who moves next" from this object alone.

`revision` is opaque and server-generated. It represents the adapter-owned semantic WorkItem fields, not every byte of a human-editable backend document.

Every mutating call uses optimistic concurrency: a stale semantic revision fails with a conflict and returns the latest WorkItem so the caller can reconcile and retry.

### ArtifactRef

Artifacts are referenced, not copied by default.

```json
{
  "uri": "string",
  "role": "input | output | canonical | evidence | implementation",
  "label": "string"
}
```

The URI may identify a GitHub file/commit/PR, Drive document, web resource, local MCP resource, or another system understood by the host. An artifact is what makes a claim checkable; it is also the precondition for `done`.

## Minimal MCP surface

### `collab.workspace.read`

Returns the Workspace snapshot.

### `collab.work.list`

Input: optional state filter.

Returns compact descriptors (`id`, `title`, `state`, `mode`, `revision`). It does not return histories.

### `collab.work.read`

Input: `id`.

Returns one complete current WorkItem. This is the canonical status and resume operation — there is deliberately no separate `status` tool.

### `collab.work.create`

Input: initial WorkItem fields except server-owned `id` and `revision`.

Returns the created WorkItem.

### `collab.work.handoff`

The single write path. One call performs one revision-checked transition:

```json
{
  "id": "string",
  "expected_revision": "opaque-string",
  "set": {
    "state": "required",
    "owner": "required",
    "next_actor": "required",
    "current_truth": "required",
    "next_actions": "required",
    "blockers": "required",
    "artifacts": "required",
    "mode": "optional",
    "goal": "optional",
    "constraints": "optional"
  }
}
```

The seven required fields are the minimum that makes a reader independent of the
old chat: what happens next, who does it, what is true, what exists, what blocks
it. Optional fields exist for refinement, not for carrying the transition.

State, actors, current truth, next actions, blockers, and artifacts change **together**, so no reader observes a half-updated item: an owner without a next action, or a review state without the artifact under review, cannot occur through this surface.

The server applies the change only if `expected_revision` is current, then returns the complete WorkItem with its resulting revision.

State invariants are enforced, not documented:

| state | requirement |
| --- | --- |
| `active` | non-empty `owner`; non-empty `next_actor`; `next_actor == owner` |
| `review` | at least one artifact, and a non-empty `next_actor` |
| `done` | at least one artifact, zero blockers, empty `next_actor` |

`collab.work.create` runs the same validation, so an item cannot be born `done`
without evidence, born in `review` without something to review, or born `active`
while routing the next move to someone other than its owner.

Failure modes are explicit:

- `revision_conflict` — someone else moved first; the response carries the current WorkItem. Re-read, reconcile semantically, retry.
- `handoff_rejected` — the request is well formed but violates an invariant, names a missing required field, or tries `done` without evidence.

Last-write-wins is not acceptable for collaboration state.

## Handoff contract

There is no separate historical `Handoff` object. A handoff succeeds when the resulting WorkItem lets a fresh agent answer, without chat replay:

- what is true now (`current_truth`),
- what exists (`artifacts`),
- what happens next and by whom (`next_actions`, `next_actor`, `owner`),
- what is blocking it (`blockers`).

An actor should not route an unfinished `active` item away from itself merely because it discovered follow-up work for someone else. It first completes its current active actions, then represents the actual boundary explicitly: `review` when there is an artifact to inspect, `blocked` when progress genuinely depends on someone/something else, or `done` when closure is justified. This makes handoff state carry the reason for relinquishing the next move instead of hiding it in prose.

Git/backend history preserves previous snapshots. A conversation may hold much more context than crosses this boundary; only distilled, action-changing information does.

## GitHub backend mapping

For the current adapter:

- Workspace summary ↔ `STATE.md`.
- WorkItem ↔ GitHub Issue.
- WorkItem id ↔ stable issue URI or repository-qualified issue number.
- WorkItem fields ↔ controlled sections `Goal`, `State`, `Mode`, `Owner`, `Next actor`, `Current truth`, `Next actions`, `Blockers`, `Artifacts`, `Constraints`, plus Issue open/closed for `done`.
- ArtifactRef ↔ links to canonical GitHub files/commits/PRs or external resources.
- Revision ↔ server-generated hash of mapped semantic WorkItem fields; callers treat it as opaque.
- Unmapped human-editable Issue sections are preserved but do not change the WorkItem revision.
- History ↔ Git/GitHub history, never copied into the current WorkItem merely for provenance.

The adapter performs a fresh GET before updating an Issue and applies its controlled-section patch to that latest body, preserving unrelated sections seen by that read.

GitHub Issues REST does not provide atomic compare-and-swap for Issue body PATCHes. A GET→PATCH TOCTOU window therefore remains across truly concurrent writers. Expanding the revision hash to the full Issue body does not remove that backend limitation.

If real use requires stronger atomicity, prefer a CAS-capable canonical primitive/backend over coordination locks.

## Relationship to neighboring protocols

- **MCP** is the access boundary: hosts use tools to read/write collaboration state.
- **A2A** is the preferred neighboring standard if direct remote agent-to-agent interaction becomes necessary.
- **ACP** addresses editor/client ↔ coding-agent interoperability and is not the shared-work-state layer.

v0 composes with existing protocols instead of defining another general agent transport.

## Trust boundary

The server treats agent-written text and artifact contents as untrusted data.

At minimum:

- backend authorization decides what a caller may read/write;
- credentials are never stored inside WorkItems;
- artifact URIs do not imply trust;
- revisions prevent accidental semantic overwrite, not malicious writes;
- implementations may log mutations at the backend/protocol boundary without adding those logs to current collaboration state.

## Validated behavior

The base v0 contract has been exercised end to end across two independent client sessions and then across two hosts on separate platforms: create, resume from durable state alone, stale-revision rejection with the current snapshot, reconcile-then-retry, and close.

The explicit-handoff extension is validated by tests against a real HTTP backend stand-in: implementer → review routing, reviewer → implementer with blockers, stale handoff rejection, `done` requiring evidence and closing the issue, and preservation of sections the adapter does not own.

Further protocol changes should be driven by concrete dogfooding failures or interoperability needs rather than speculative expansion.