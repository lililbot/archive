# AGENTS.md

This repository is a coordination surface, not an archive.

## On entry

1. Read `README.md`.
2. Read `STATE.md`.
3. Read `CAPABILITIES.md` before choosing an owner or next actor.
4. Inspect relevant open Issues before creating new work.
5. Read project-specific repositories only when the work item requires them.

## Operating protocol

- Maintain **current truth**; let Git retain prior states.
- Treat principles, protocols, and architecture rules as current truth too. They should evolve by replacement, simplification, or deletion rather than accumulating compatibility layers, deprecation notes, or historical rationale that is no longer useful now.
- Prefer the smallest durable change that makes future resumption easier.
- Do not create session logs, progress diaries, duplicated summaries, chat archives, decision-history files, or principle changelogs by default.
- If a conversation yields a durable fact, decision, constraint, principle, or next action, merge it into the canonical file or Issue where it belongs.
- If something becomes obsolete, replace or delete it rather than preserving both versions in current docs. Git is the history layer.
- Optimize canonical state for the best present model, not compatibility with earlier descriptions of the project.
- Use Issues for unresolved/actionable work. Use files for stable protocols, indexes, and distilled state.
- Avoid turning `STATE.md` into a backlog; link to Issues instead.

## Capability allocation

Every substantial work item should be classified as one of:

- **AI** — agent can execute and verify it with available tools.
- **Human** — requires user judgment, access, physical action, or verification the agent cannot perform reliably.
- **Joint** — benefits from alternating agent execution and human judgment.

Use `CAPABILITIES.md` to choose the concrete platform/mode actor. Capability cards are keyed by `Platform: Mode`, not individual agent instances.

When the classification or practical capability changes, update current state rather than preserving a history of old classifications.

## Concurrency model

- Default to lock-free parallel work. Do not add coordination locks merely because multiple agents may act concurrently.
- Use Git commits as version boundaries. Material work should have an explicit base commit/ref so staleness can be detected mechanically.
- Let Git handle **state concurrency** through branches, commits, merges, expected SHAs, and optimistic updates.
- Keep the collaboration layer focused on **semantic concurrency**: incompatible decisions, overlapping ownership, dependencies, shared contracts, and destructive or externally irreversible actions.
- Delay ordinary file conflicts until merge/reconciliation when practical. Introduce advance claims or serialization only when semantic conflict or the cost of wasted work justifies it.
- A clean textual merge is not proof of semantic compatibility. Revalidate affected contracts, decisions, tests, and assumptions before treating concurrent work as integrated.
- When a write is based on stale state, reconcile against the latest canonical state instead of silently overwriting it.

## Git behavior

- Small maintenance changes to this coordination repository may be committed directly.
- Material project changes should normally happen in the relevant project repository, preferably on a branch/PR when review is useful.
- Do not rewrite shared branch history unless explicitly requested.
- Before destructive edits, inspect the current file/ref and use the latest SHA.

## Completion rule

A work item is complete when its result exists in the canonical current state (code, file, decision, or external system) and any coordinating Issue can be closed without losing information needed to continue future work.
