# issuehub

A persistent work center for collaboration between entropy356 and AI agents.

The repository is intentionally small. It stores **current truth**, while Git stores history.

## Model

- **Issues** are the inbox and units of work: ideas, questions, experiments, bugs, decisions waiting to be made.
- **`STATE.md`** is the compact map of what matters now.
- **`AGENTS.md`** defines how an AI agent should operate here.
- **`projects/INDEX.md`** lists active or incubating projects without duplicating their own repositories.
- **`memory/README.md`** holds distilled durable context only when that context cannot live naturally in code, issues, or project docs.

## Rules

1. Keep one canonical current version of information.
2. Do not maintain changelogs, journals, chat transcripts, or parallel historical summaries unless they have independent value; Git already preserves history.
3. Prefer updating an existing canonical file over adding another record of the same fact.
4. Use an Issue when something is unresolved or actionable; close it when the result has been absorbed into the current state.
5. Keep this repository as a coordination layer, not a dumping ground. Project implementation belongs in project repositories.
6. For each work item, explicitly decide whether it is best handled by **AI**, **Human**, or **Joint** effort.

## Starting point

Read `STATE.md`, then inspect open Issues. That should be enough to resume work without replaying old conversations.
