# HTTP API MCP service

A self-hosted MCP server for controlled outbound HTTPS API calls, intended to run on a user-managed VPS and connect to a private ChatGPT plugin.

The service uses origin-bound server-side credentials, strict outbound destination validation, HTTPS-only requests, no automatic redirects, bounded request/response sizes, and bearer authentication on its MCP endpoint. Secrets are never committed.
