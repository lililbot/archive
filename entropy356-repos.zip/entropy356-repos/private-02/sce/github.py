import hashlib
import json
import re

from .contracts import Task
from .engine import Candidate
from .repository import Repository
from .runtime import blocking, command


def validate_repository(name: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9-]*/[A-Za-z0-9_.-]+", name):
        raise ValueError("GitHub repository must have owner/name form")
    return name


async def gh(*args: str) -> str:
    result = await command(("gh", *args), timeout=30, limit=256000)
    if result.code:
        raise RuntimeError(f"GitHub CLI failed: {result.output[-2000:].strip()}")
    if result.truncated:
        raise RuntimeError("GitHub CLI response exceeded its output limit")
    return result.output.strip()


async def issue_text(repository: str, number: int) -> str:
    value = json.loads(await gh(
        "issue", "view", str(number), "--repo", repository, "--json", "title,body",
    ))
    return f"#{number} {value['title']}\n\n{value['body'] or ''}"


async def publish(
    repo: Repository, repository: str, base_branch: str, task: Task, candidate: Candidate,
) -> str:
    if candidate.status != "qualified" or candidate.applied is None:
        raise ValueError("publishing requires a qualified patch")
    await blocking(repo.git, "check-ref-format", f"refs/heads/{base_branch}")
    branch_query = [
        "api", f"repos/{repository}/git/ref/heads/{base_branch}", "--jq", ".object.sha",
    ]
    if await gh(*branch_query) != task.base:
        raise RuntimeError("GitHub base branch moved or differs from the verified base")
    tree = candidate.applied.tree
    identity = json.dumps([repository.lower(), base_branch, task.base, tree, task.issue, task.constraints])
    key = hashlib.sha256(identity.encode()).hexdigest()[:24]
    head = f"sce/{key}"
    title = f"SCE: {' '.join(task.issue.split())[:100]}"
    timestamp = (await blocking(repo.git, "show", "-s", "--format=%cI", task.base)).decode().strip()
    # commit-tree has no checkout or hooks. Pin dates and identity for repeatable pushes.
    commit = (await blocking(
        repo.commit_tree, tree, task.base, timestamp, f"SCE verified patch {key}",
    )).decode().strip()
    url = f"https://github.com/{repository}.git"
    ref = f"refs/heads/{head}"
    git_transport = (
        "git", "-c", "credential.helper=", "-c", "credential.helper=!gh auth git-credential",
        "-c", "core.hooksPath=/dev/null", "-C", str(repo.path),
    )

    async def remote_head() -> str:
        result = await command((*git_transport, "ls-remote", "--refs", url, ref), timeout=30)
        if result.code:
            raise RuntimeError(f"could not check delivery branch: {result.output.strip()}")
        return result.output.split()[0] if result.output.strip() else ""

    current = await remote_head()
    if not current:
        result = await command(
            (*git_transport, "push", f"--force-with-lease={ref}:", url, f"{commit}:{ref}"), timeout=40,
        )
        if result.code and await remote_head() != commit:
            raise RuntimeError(f"could not push delivery branch: {result.output.strip()}")
    elif current != commit:
        raise RuntimeError("delivery branch already exists with a different commit")

    async def existing_pr() -> str:
        response = await gh(
            "pr", "list", "--repo", repository, "--head", head, "--base", base_branch,
            "--state", "all", "--limit", "1", "--json", "url",
        )
        prs = json.loads(response)
        return prs[0]["url"] if prs else ""

    if existing := await existing_pr():
        return existing
    if await gh(*branch_query) != task.base:
        raise RuntimeError("GitHub base branch moved before Draft PR creation")
    checks = "\n".join(f"- {check.name}: passed" for check in candidate.checks)
    body = (
        f"Verified base: `{task.base}`\n\n"
        f"Solver: `{candidate.strategy}` (wave {candidate.wave})\n\n"
        f"Verification:\n{checks}"
    )
    try:
        return await gh(
            "pr", "create", "--repo", repository, "--base", base_branch, "--head", head,
            "--draft", "--title", title, "--body", body,
        )
    except RuntimeError:
        if existing := await existing_pr():
            return existing
        raise
