from dataclasses import dataclass
from fnmatch import fnmatchcase
from math import isfinite

MAX_PATCH_BYTES = 128 * 1024


@dataclass(frozen=True)
class Check:
    name: str
    kind: str
    argv: tuple[str, ...]
    timeout: float


@dataclass(frozen=True)
class Policy:
    image: str
    allowed_paths: tuple[str, ...]
    protected_paths: tuple[str, ...]
    checks: tuple[Check, ...]
    max_files: int = 12
    max_lines: int = 500

    def permits(self, path: str) -> bool:
        protected = (
            ".git*", "*/.git*", "tests/*", "test/*", "*/tests/*", "*/test/*",
            "test_*.py", "*_test.py", "*/test_*.py", "*/conftest.py", "conftest.py",
            "pyproject.toml", "pytest.ini", "setup.cfg", "tox.ini", "setup.py",
        )
        return any(fnmatchcase(path, glob) for glob in self.allowed_paths) and not any(
            fnmatchcase(path, glob) for glob in (*protected, *self.protected_paths)
        )


@dataclass(frozen=True)
class Options:
    solvers: int | None = None
    repair_solvers: int = 4
    model_parallelism: int = 8
    verify_parallelism: int = 3
    deadline: float = 420
    selection_window: float = 0


@dataclass(frozen=True)
class Task:
    issue: str
    base: str
    constraints: tuple[str, ...] = ()


@dataclass(frozen=True)
class Proposal:
    base_commit: str
    strategy: str
    patch: str
    tests_to_run: tuple[str, ...]
    assumptions: tuple[str, ...]
    risk: tuple[str, ...]

    @classmethod
    def parse(cls, value: object, base: str, strategy: str) -> "Proposal":
        if not isinstance(value, dict) or set(value) != set(cls.__dataclass_fields__):
            raise ValueError("proposal must contain exactly the six contract fields")
        if value["base_commit"] != base or value["strategy"] != strategy:
            raise ValueError("proposal base commit or strategy does not match its request")
        patch = value["patch"]
        if (
            not isinstance(patch, str) or not patch.startswith("diff --git ")
            or not patch.endswith("\n") or "\0" in patch
            or len(patch.encode()) > MAX_PATCH_BYTES
        ):
            raise ValueError("expected a complete, bounded Git unified diff")
        fields = []
        for key in ("tests_to_run", "assumptions", "risk"):
            entries = value[key]
            if not isinstance(entries, list) or len(entries) > 12 or any(
                not isinstance(entry, str) or len(entry) > 500 for entry in entries
            ):
                raise ValueError(f"invalid {key} metadata")
            fields.append(tuple(entries))
        return cls(base, strategy, patch, *fields)


def read_policy(data: object) -> tuple[Policy, Options]:
    if not isinstance(data, dict):
        raise ValueError("configuration must be a JSON object")
    if data.keys() - {
        "image", "allowed_paths", "protected_paths", "checks", "max_files",
        "max_lines", "options",
    }:
        raise ValueError("unknown configuration field")

    def strings(value, label):
        if not isinstance(value, list) or any(
            not isinstance(item, str) or not item.strip() or "\0" in item for item in value
        ):
            raise ValueError(f"{label} must be a list of nonempty strings")
        return tuple(value)

    def count(value, label, low, high):
        if type(value) is not int or not low <= value <= high:
            raise ValueError(f"{label} must be an integer in [{low}, {high}]")
        return value

    def seconds(value, label, low, high):
        if type(value) not in (int, float) or not low <= value <= high or not isfinite(value):
            raise ValueError(f"{label} must be seconds in [{low}, {high}]")
        return float(value)

    image = data.get("image")
    if not isinstance(image, str) or not image or image.startswith("-") or any(
        char.isspace() or char == "\0" for char in image
    ):
        raise ValueError("image must identify a preloaded, trusted Docker image")
    allowed = strings(data.get("allowed_paths"), "allowed_paths")
    if not allowed:
        raise ValueError("allowed_paths must explicitly name editable paths")
    checks = []
    names = set()
    raw_checks = data.get("checks", [])
    if not isinstance(raw_checks, list) or not raw_checks:
        raise ValueError("configure at least one trusted verification check")
    for item in raw_checks:
        if not isinstance(item, dict) or item.keys() - {"name", "kind", "argv", "timeout"}:
            raise ValueError("invalid check configuration")
        name, kind = item.get("name"), item.get("kind")
        argv = strings(item.get("argv"), "check argv")
        if (
            not isinstance(name, str) or not name.strip() or name in names or not argv
            or kind not in ("acceptance", "regression", "syntax", "security", "api")
        ):
            raise ValueError("each check requires a unique name, valid kind, and argv")
        names.add(name)
        checks.append(Check(name, kind, argv, seconds(item.get("timeout", 30), name, 0.01, 600)))
    policy = Policy(
        image, allowed, strings(data.get("protected_paths", []), "protected_paths"),
        tuple(checks), count(data.get("max_files", 12), "max_files", 1, 100),
        count(data.get("max_lines", 500), "max_lines", 1, 10000),
    )
    raw = data.get("options", {})
    defaults = Options()
    if not isinstance(raw, dict) or raw.keys() - Options.__dataclass_fields__.keys():
        raise ValueError("invalid scheduler options")
    solvers = raw.get("solvers")
    options = Options(
        count(solvers, "solvers", 1, 8) if solvers is not None else None,
        count(raw.get("repair_solvers", defaults.repair_solvers), "repair_solvers", 0, 4),
        count(raw.get("model_parallelism", defaults.model_parallelism), "model_parallelism", 1, 8),
        count(raw.get("verify_parallelism", defaults.verify_parallelism), "verify_parallelism", 1, 16),
        seconds(raw.get("deadline", defaults.deadline), "deadline", 0.01, 3600),
        seconds(raw.get("selection_window", defaults.selection_window), "selection_window", 0, 30),
    )
    return policy, options
