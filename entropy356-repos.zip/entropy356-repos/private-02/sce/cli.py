import argparse
import asyncio
from dataclasses import asdict
import json
from pathlib import Path
import sys

from .contracts import Task, read_policy
from .engine import Engine
from .github import issue_text, publish, validate_repository
from .repository import Repository
from .runtime import DockerRunner, Gateway, blocking


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description="Generate and verify speculative coding patches")
    result.add_argument("--repo", type=Path, default=Path.cwd())
    result.add_argument("--base", default="HEAD", help="Git revision to pin before solving")
    source = result.add_mutually_exclusive_group(required=True)
    source.add_argument("--issue", help="task text")
    source.add_argument("--issue-file", type=Path, help="UTF-8 Markdown task description")
    source.add_argument("--github-issue", type=int, help="issue number in --github-repo")
    result.add_argument("--github-repo", help="owner/name for GitHub operations")
    result.add_argument("--constraint", action="append", default=[])
    result.add_argument("--policy", type=Path, required=True, help="trusted verification JSON")
    result.add_argument("--out", type=Path, required=True, help="new directory for report and patch")
    result.add_argument("--publish", action="store_true", help="push a qualified patch and open a Draft PR")
    result.add_argument("--base-branch", help="target GitHub branch for --publish")
    return result


async def run(args: argparse.Namespace) -> int:
    policy, options = read_policy(json.loads(args.policy.read_text(encoding="utf-8")))
    if args.github_repo:
        validate_repository(args.github_repo)
    if (args.github_issue is not None or args.publish) and not args.github_repo:
        raise ValueError("--github-repo is required for GitHub operations")
    if args.publish and not args.base_branch:
        raise ValueError("--base-branch is required with --publish")
    if args.github_issue is not None:
        if args.github_issue < 1:
            raise ValueError("--github-issue must be positive")
        issue = await issue_text(args.github_repo, args.github_issue)
    elif args.issue_file:
        with args.issue_file.open(encoding="utf-8") as source:
            issue = source.read(16001)
    else:
        issue = args.issue
    if not issue.strip() or len(issue) > 16000:
        raise ValueError("task text must contain between 1 and 16000 characters")

    solver = Gateway.from_env()
    runner = DockerRunner(policy.image)
    repo = await blocking(Repository, args.repo)
    base = await blocking(repo.pin, args.base)
    task = Task(issue.strip(), base, tuple(args.constraint))
    await runner.ready()
    # An exclusive directory prevents a failed run from reusing a stale winner.
    args.out.mkdir(mode=0o700, parents=True, exist_ok=False)
    result = await Engine(repo, policy, options, solver, runner).solve(task)
    report = asdict(result)
    for entry in [*report["candidates"], report["selected"]]:
        if entry and entry["proposal"]:
            entry["proposal"].pop("patch")
    if result.selected:
        patch = result.selected.proposal.patch
        (args.out / "selected.patch").write_bytes(patch.encode())
    report_path = args.out / "report.json"
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"{result.status}: {report_path}")
    if args.publish and result.status == "qualified":
        url = await publish(repo, args.github_repo, args.base_branch, task, result.selected)
        report["draft_pr"] = url
        pending = args.out / "report.pending"
        pending.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        pending.replace(report_path)
        print(url)
    return {"qualified": 0, "review": 2, "failed": 3, "deadline": 4}[result.status]


def main() -> int:
    args = parser().parse_args()
    try:
        return asyncio.run(run(args))
    except (OSError, ValueError, RuntimeError, TimeoutError) as error:
        print(f"sce: {error}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
