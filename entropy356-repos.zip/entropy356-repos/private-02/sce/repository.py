import ast
from collections import Counter
from dataclasses import dataclass
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
from tempfile import TemporaryDirectory

from .contracts import Policy, Proposal, Task

GIT_TIMEOUT = 30
MAX_SNAPSHOT = 64 * 1024 * 1024
REGULAR_MODES = {b"100644", b"100755"}
WORD = re.compile(r"[a-zA-Z_][a-zA-Z_0-9]{2,}")
STOP = set("and the for with this that when fix bug from where into should issue expected".split())


class RepositoryError(RuntimeError):
    pass


class PatchError(RepositoryError):
    def __init__(self, kind: str, message: str):
        super().__init__(message)
        self.kind = kind


@dataclass(frozen=True)
class Entry:
    path: str
    mode: bytes
    oid: bytes
    size: int


@dataclass(frozen=True)
class AppliedPatch:
    tree: str
    files: tuple[str, ...]
    lines: int


@dataclass(frozen=True)
class Evidence:
    files: tuple[dict, ...]
    history: str

    def pack(self, strategy: str) -> dict:
        files = list(self.files)
        if strategy in {"test_driven", "edge_cases"}:
            files.sort(key=lambda entry: not entry["test"])
        if strategy in {"minimal_fix", "conservative"}:
            count, chars = 5, 2600
        elif strategy in {"wide_context", "history_guided"}:
            count, chars = 14, 4600
        else:
            count, chars = 9, 3500
        return {
            "files": [
                {
                    "path": entry["path"], "symbols": entry["symbols"], "imports": entry["imports"],
                    "excerpt": excerpt(entry["text"], entry["anchors"], chars),
                }
                for entry in files[:count]
            ],
            "history": self.history if strategy in {"history_guided", "root_cause", "wide_context"} else "",
        } | {"paths": [entry["path"] for entry in self.files[:30]]}


def excerpt(source: str, anchors: list[int], budget: int) -> str:
    lines = source.splitlines()
    if len(source) <= budget:
        return source
    selected = set(range(min(12, len(lines))))
    for anchor in anchors[:8]:
        selected.update(range(max(0, anchor - 5), min(len(lines), anchor + 6)))
    snippets = []
    used = 0
    for index in sorted(selected):
        line = f"{index + 1}: {lines[index][:350]}\n"
        if used + len(line) > budget:
            break
        snippets.append(line)
        used += len(line)
    return "".join(snippets)


class Repository:
    def __init__(self, path: Path):
        self.path = path.resolve()
        self.env = {
            name: value for name, value in os.environ.items() if not name.startswith("GIT_")
        } | {"GIT_CONFIG_GLOBAL": os.devnull, "GIT_CONFIG_NOSYSTEM": "1", "LC_ALL": "C"}
        if self.git("rev-parse", "--is-bare-repository").strip() == b"false":
            self.path = Path(os.fsdecode(self.git("rev-parse", "--show-toplevel").rstrip(b"\n")))

    def git(self, *args: str, data: bytes | None = None, index: str | None = None,
            extra_env: dict | None = None) -> bytes:
        env = self.env | (extra_env or {})
        if index is not None:
            env["GIT_INDEX_FILE"] = index
        try:
            result = subprocess.run(
                ["git", "-c", "core.hooksPath=/dev/null", "-C", str(self.path), *args],
                input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env,
                timeout=GIT_TIMEOUT,
            )
        except subprocess.TimeoutExpired as error:
            raise RepositoryError(f"Git command exceeded {GIT_TIMEOUT}s") from error
        if result.returncode:
            raise RepositoryError(result.stderr.decode(errors="replace")[-3500:].strip())
        return result.stdout

    def pin(self, ref: str) -> str:
        return self.git("rev-parse", "--verify", "--end-of-options", f"{ref}^{{commit}}").decode().strip()

    def commit_tree(self, tree: str, parent: str, date: str, message: str) -> bytes:
        return self.git(
            "-c", "commit.gpgSign=false", "commit-tree", tree, "-p", parent, "-m", message,
            extra_env={
                "GIT_AUTHOR_NAME": "Speculative Coding Engine",
                "GIT_AUTHOR_EMAIL": "sce@users.noreply.github.com",
                "GIT_COMMITTER_NAME": "Speculative Coding Engine",
                "GIT_COMMITTER_EMAIL": "sce@users.noreply.github.com",
                "GIT_AUTHOR_DATE": date, "GIT_COMMITTER_DATE": date,
            },
        )

    def entries(self, tree: str) -> list[Entry]:
        entries = []
        for record in self.git("ls-tree", "-rlz", tree).split(b"\0")[:-1]:
            info, raw_path = record.split(b"\t", 1)
            mode, _, oid, size = info.split()
            path = raw_path.decode()
            entries.append(Entry(path, mode, oid, 0 if size == b"-" else int(size)))
        return entries

    def blobs(self, entries: list[Entry]) -> list[bytes]:
        data = b"".join(entry.oid + b"\n" for entry in entries)
        output = self.git("cat-file", "--batch", data=data)
        offset, blobs = 0, []
        for entry in entries:
            end = output.index(b"\n", offset)
            header = output[offset:end].split()
            if header != [entry.oid, b"blob", str(entry.size).encode()]:
                raise RepositoryError(f"unexpected Git object for {entry.path}")
            offset = end + 1
            blobs.append(output[offset:offset + entry.size])
            offset += entry.size + 1
        return blobs

    def evidence(self, task: Task) -> Evidence:
        terms = set(WORD.findall(task.issue.lower())) - STOP
        entries = [
            entry for entry in self.entries(task.base)
            if entry.mode in REGULAR_MODES and 0 < entry.size <= 48000
        ]
        entries.sort(key=lambda entry: (
            -sum(term in entry.path.lower() for term in terms), entry.size, entry.path
        ))
        ranked = []
        for entry, blob in zip(entries[:800], self.blobs(entries[:800])):
            if b"\0" in blob:
                continue
            source = blob.decode(errors="replace")
            path = entry.path
            hits = Counter()
            anchors = []
            for line_no, line in enumerate(source.splitlines()):
                matches = terms.intersection(WORD.findall(line.lower()))
                if matches:
                    hits.update(matches)
                    anchors.append(line_no)
            symbols, imports = python_structure(path, source)
            path_hits = sum(term in path.lower() for term in terms)
            symbol_hits = sum(term in " ".join(symbols).lower() for term in terms)
            score = 15 * path_hits + 6 * symbol_hits + sum(min(n, 3) for n in hits.values())
            if path in task.issue:
                score += 80
            test = bool(re.search(r"(^|/)(tests?/|test_)|_test\.", path))
            ranked.append((score, {
                "path": path, "text": source, "anchors": anchors, "symbols": symbols,
                "imports": imports, "test": test,
            }))
        ranked.sort(key=lambda item: (-item[0], item[1]["path"]))
        leaders = ranked[:4]
        linked = {
            module.split(".")[-1]
            for score, entry in leaders if score
            for module in entry["imports"]
        }
        ranked.sort(key=lambda item: (
            -(item[0] + 8 * (Path(item[1]["path"]).stem in linked)), item[1]["path"]
        ))
        files = tuple(entry for _, entry in ranked[:30])
        history_paths = [entry["path"] for entry in files[:5]]
        history = self.git(
            "--literal-pathspecs", "log", "-6", "--format=%h %s", task.base, "--", *history_paths,
        ).decode(errors="replace")[:2400]
        return Evidence(files, history)

    def apply(self, proposal: Proposal, policy: Policy) -> AppliedPatch:
        with TemporaryDirectory(prefix="sce-index-") as temp:
            index = str(Path(temp) / "index")
            self.git("read-tree", proposal.base_commit, index=index)
            try:
                self.git(
                    "apply", "--cached", "--whitespace=error", "-",
                    data=proposal.patch.encode(), index=index,
                )
            except RepositoryError as error:
                raise PatchError("apply", str(error)) from error
            diff_args = ("diff", "--cached", "--no-renames", "--no-ext-diff", "--no-textconv")
            changes = self.git(*diff_args, "--numstat", "-z", proposal.base_commit, index=index)
            files, lines = [], 0
            for change in changes.split(b"\0")[:-1]:
                added, removed, raw_path = change.split(b"\t", 2)
                try:
                    path = raw_path.decode()
                except UnicodeDecodeError as error:
                    raise PatchError("policy", "non-UTF-8 path") from error
                if added == b"-" or removed == b"-" or not policy.permits(path):
                    raise PatchError("policy", f"binary or protected change: {path}")
                files.append(path)
                lines += int(added) + int(removed)
            if not files or len(files) > policy.max_files or lines > policy.max_lines:
                raise PatchError("policy", "empty patch or change budget exceeded")
            tree = self.git("write-tree", index=index).decode().strip()
            if any(entry.mode not in REGULAR_MODES for entry in self.entries(tree)):
                raise PatchError("policy", "only regular files are supported")
            return AppliedPatch(tree, tuple(files), lines)

    def export(self, tree: str, target: Path) -> None:
        entries = self.entries(tree)
        if len(entries) > 20000 or sum(entry.size for entry in entries) > MAX_SNAPSHOT:
            raise RepositoryError("snapshot exceeds verification limits")
        for entry in entries:
            path = PurePosixPath(entry.path)
            if (
                entry.mode not in REGULAR_MODES or path.is_absolute()
                or any(part.lower() == ".git" or part == ".." for part in path.parts)
            ):
                raise RepositoryError(f"unsupported snapshot entry: {entry.path}")
        for entry, blob in zip(entries, self.blobs(entries)):
            path = target / entry.path
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(blob)
            path.chmod(0o755 if entry.mode == b"100755" else 0o644)


def python_structure(path: str, source: str) -> tuple[list[str], list[str]]:
    if not path.endswith(".py"):
        return [], []
    try:
        tree = ast.parse(source)
    except (SyntaxError, ValueError, RecursionError):
        return [], []
    symbols, imports = [], []
    for node in ast.walk(tree):
        if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            symbols.append(node.name)
        elif isinstance(node, ast.Import):
            imports.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.extend([node.module] if node.module else [alias.name for alias in node.names])
    return symbols[:50], imports[:40]
