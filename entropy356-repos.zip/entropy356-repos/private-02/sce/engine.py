import asyncio
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from tempfile import TemporaryDirectory
from time import monotonic
from typing import Protocol

from .contracts import Check, Options, Policy, Proposal, Task
from .repository import AppliedPatch, Evidence, PatchError, Repository, RepositoryError
from .runtime import ProcessResult, blocking

STRATEGIES = {
    "minimal_fix": "Make the smallest behavior change that addresses the issue.",
    "root_cause": "Trace related symbols and fix the underlying failure.",
    "test_driven": "Use the existing tests and baseline logs to infer the expected behavior.",
    "edge_cases": "Check boundaries, error handling, and malformed inputs.",
    "conservative": "Preserve compatibility and public interfaces.",
    "wide_context": "Look beyond the immediate file for related code and alternative fixes.",
    "history_guided": "Use changes in the base commit history to identify a likely regression.",
    "alternative": "Find a different implementation that keeps the change focused.",
}
# The first group starts from static evidence. The second group sees baseline logs.
EARLY = ("minimal_fix", "root_cause", "conservative", "history_guided")
HEDGED = ("test_driven", "edge_cases", "wide_context", "alternative")


class Solver(Protocol):
    async def propose(self, task: Task, strategy: str, prompt: dict) -> Proposal: ...


class Runner(Protocol):
    async def run(self, snapshot: Path, check: Check) -> ProcessResult: ...


@dataclass(frozen=True)
class CheckResult:
    name: str
    kind: str
    outcome: str
    log: str


@dataclass
class Candidate:
    wave: int
    strategy: str
    status: str
    detail: str = ""
    proposal: Proposal | None = None
    applied: AppliedPatch | None = None
    checks: list[CheckResult] = field(default_factory=list)

    def rank(self):
        assert self.applied is not None
        return (len(self.applied.files), self.applied.lines, self.wave, self.strategy)


@dataclass
class Run:
    base_commit: str
    status: str
    elapsed_seconds: float
    baseline: list[CheckResult]
    candidates: list[Candidate]
    selected: Candidate | None = None


class Engine:
    def __init__(self, repo: Repository, policy: Policy, options: Options, solver: Solver, runner: Runner):
        self.repo, self.policy, self.options = repo, policy, options
        self.solver, self.runner = solver, runner
        self.models = asyncio.Semaphore(options.model_parallelism)
        self.verifiers = asyncio.Semaphore(options.verify_parallelism)

    async def checks(self, tree: str) -> list[CheckResult]:
        async with self.verifiers:
            with TemporaryDirectory(prefix="sce-snapshot-") as temp:
                root = Path(temp)
                root.chmod(0o755)
                await blocking(self.repo.export, tree, root)
                results = []
                for check in self.policy.checks:
                    try:
                        result = await self.runner.run(root, check)
                        outcome = "pass" if result.code == 0 else "fail"
                        log = ("[output truncated]\n" if result.truncated else "") + result.output
                    except TimeoutError:
                        outcome, log = "timeout", "check exceeded its configured timeout"
                    except (OSError, RuntimeError, ValueError) as error:
                        outcome, log = "infrastructure", str(error)
                    results.append(CheckResult(check.name, check.kind, outcome, log[-12500:]))
                return results

    async def candidate(
        self, task: Task, evidence: Evidence, baseline: asyncio.Task,
        strategy: str, wave: int, hedged: bool, failures: dict | None,
    ) -> Candidate:
        prompt = {
            "issue": task.issue, "base_commit": task.base, "strategy": strategy,
            "instruction": STRATEGIES[strategy],
            "constraints": task.constraints, "evidence": evidence.pack(strategy),
            "allowed_paths": self.policy.allowed_paths, "protected_paths": self.policy.protected_paths,
            "verification": [{"name": check.name, "kind": check.kind} for check in self.policy.checks],
        }
        if hedged or failures is not None:
            prompt["baseline"] = checks_for_prompt(await baseline)
        if failures is not None:
            prompt["instruction"] += " Repair a previous failure and return a full patch against the original base."
            prompt["previous_wave"] = failures
        proposal = None
        applied = None
        try:
            async with self.models:
                proposal = await self.solver.propose(task, strategy, prompt)
            # Enforce the contract even for pluggable solvers.
            if proposal.base_commit != task.base or proposal.strategy != strategy:
                raise ValueError("candidate does not match the pinned task")
        except (ValueError, OSError, RuntimeError, TimeoutError) as error:
            return Candidate(wave, strategy, "solver", str(error))

        try:
            applied = await blocking(self.repo.apply, proposal, self.policy)
            results = await self.checks(applied.tree)
        except PatchError as error:
            return Candidate(wave, strategy, error.kind, str(error), proposal)
        except (RepositoryError, OSError, TimeoutError, ValueError) as error:
            return Candidate(wave, strategy, "infrastructure", str(error), proposal, applied)

        failed = next((result for result in results if result.outcome != "pass"), None)
        if failed:
            status = failed.kind if failed.outcome == "fail" else failed.outcome
            return Candidate(wave, strategy, status, f"{failed.name}: {failed.outcome}", proposal, applied, results)

        original = await baseline
        acceptance_failed = any(check.kind == "acceptance" and check.outcome == "fail" for check in original)
        other_passed = all(
            check.outcome == "pass" or (check.kind == "acceptance" and check.outcome == "fail")
            for check in original
        )
        if acceptance_failed and other_passed:
            return Candidate(wave, strategy, "qualified", proposal=proposal, applied=applied, checks=results)
        return Candidate(
            wave, strategy, "review",
            "no clean baseline with a reproduced acceptance failure",
            proposal, applied, results,
        )

    async def wave(self, task, evidence, baseline, strategies, number, deadline, candidates, failures=None):
        pending = {
            asyncio.create_task(self.candidate(task, evidence, baseline, strategy, number, hedged, failures)):
            strategy for strategy, hedged in strategies
        }
        qualified = []
        cutoff = deadline
        try:
            while pending:
                remaining = cutoff - monotonic()
                if remaining <= 0:
                    break
                completed, _ = await asyncio.wait(pending, timeout=remaining, return_when=asyncio.FIRST_COMPLETED)
                if not completed:
                    break
                for job in sorted(completed, key=pending.get):
                    pending.pop(job)
                    candidate = job.result()
                    candidates.append(candidate)
                    if candidate.status == "qualified":
                        if not qualified:
                            cutoff = min(deadline, monotonic() + self.options.selection_window)
                        qualified.append(candidate)
            return min(qualified, key=Candidate.rank, default=None)
        finally:
            for job, strategy in pending.items():
                job.cancel()
                status = "deadline" if monotonic() >= deadline else "cancelled"
                candidates.append(Candidate(number, strategy, status))
            await asyncio.gather(*pending, return_exceptions=True)

    async def solve(self, task: Task) -> Run:
        start = monotonic()
        deadline = start + self.options.deadline
        candidates = []
        baseline = asyncio.create_task(self.baseline(task.base))
        winner = None
        status = "failed"
        try:
            try:
                async with asyncio.timeout(max(0, deadline - monotonic())):
                    evidence = await blocking(self.repo.evidence, task)
            except TimeoutError:
                status = "deadline"
            else:
                budget = self.options.solvers or estimate_budget(task, evidence)
                early = (budget + 1) // 2
                plan = [(strategy, False) for strategy in EARLY[:early]]
                plan += [(strategy, True) for strategy in HEDGED[:budget - early]]
                winner = await self.wave(task, evidence, baseline, plan, 1, deadline, candidates)
                if winner is None and not any(item.status == "review" for item in candidates):
                    repair = self.options.repair_solvers
                    actionable = any(item.status in {
                        "solver", "apply", "policy", "acceptance", "regression", "syntax", "security", "api",
                    } for item in candidates)
                    if repair and actionable and monotonic() < deadline:
                        failures = compile_failures(candidates)
                        plan = [(strategy, True) for strategy in (
                            "root_cause", "test_driven", "minimal_fix", "wide_context"
                        )[:repair]]
                        winner = await self.wave(task, evidence, baseline, plan, 2, deadline, candidates, failures)
                if winner:
                    status = "qualified"
                else:
                    winner = min(
                        (item for item in candidates if item.status == "review"),
                        key=Candidate.rank, default=None,
                    )
                    if winner:
                        status = "review"
                    elif monotonic() >= deadline:
                        status = "deadline"
        finally:
            if not baseline.done():
                baseline.cancel()
            await asyncio.gather(baseline, return_exceptions=True)
        return Run(
            task.base, status, round(monotonic() - start, 3),
            [] if baseline.cancelled() else baseline.result(), candidates, winner,
        )

    async def baseline(self, base: str) -> list[CheckResult]:
        try:
            return await self.checks(base)
        except (RepositoryError, OSError, TimeoutError, ValueError) as error:
            return [CheckResult("snapshot", "infrastructure", "infrastructure", str(error))]


def estimate_budget(task: Task, evidence: Evidence) -> int:
    mentioned = [entry for entry in evidence.files if entry["path"] in task.issue]
    if len({Path(entry["path"]).parent for entry in mentioned}) >= 3:
        return 8
    if len(mentioned) >= 2 or any(word in task.issue.lower() for word in ("traceback", "assert", "regression")):
        return 4
    return 2


def checks_for_prompt(results: list[CheckResult]) -> list[dict]:
    return [
        {"name": result.name, "kind": result.kind, "outcome": result.outcome, "log": result.log[-1500:]}
        for result in results[:12]
    ]


def compile_failures(candidates: list[Candidate]) -> dict:
    counts = Counter(candidate.status for candidate in candidates)
    best = sorted(
        (candidate for candidate in candidates if candidate.applied and candidate.proposal),
        key=lambda candidate: (-sum(result.outcome == "pass" for result in candidate.checks), candidate.rank()),
    )[:2]
    return {
        "counts": dict(counts),
        "diagnostics": [
            {"strategy": candidate.strategy, "status": candidate.status, "detail": candidate.detail[:800]}
            for candidate in candidates
        ],
        "near_misses": [
            {"strategy": candidate.strategy, "patch_excerpt": candidate.proposal.patch[:12000],
             "checks": checks_for_prompt(candidate.checks)}
            for candidate in best
        ],
    }
