# Speculative Coding Engine

SCE 是面向高首 Token 延迟模型的代码修复 CLI。它在固定 Git 提交上收集代码证据，并发请求完整补丁，并把验证通过的候选交给确定性选择器。

## 快速体验

需要 Python 3.11+、Git、curl 和本机 Docker。先下载示例使用的镜像，再运行本地模型模拟器。模拟器提供一个已知补丁，验证器会在真实 Docker 容器里运行原有测试。示例无需模型密钥。

```sh
docker pull python:3.12-slim
python3 examples/demo.py --out .sce/demo
```

成功时，`.sce/demo/report.json` 记录固定提交、基线结果和候选状态，`.sce/demo/selected.patch` 保存胜出的补丁。输出目录必须是新目录。

## 使用真实模型

准备一个已经安装项目依赖、没有声明 Docker volumes 的可信本机镜像。把验证策略放在可信位置，根据目标仓库配置可修改的路径、受保护文件、检查命令和预算。可从 [Python 策略示例](examples/python-policy.json) 开始。

```sh
export SCE_MODEL_URL='https://your-model-gateway.example/v1/chat/completions'
export SCE_MODEL='your-model'
# 从凭据管理器设置 SCE_API_KEY。
python3 -m sce.cli \
  --repo /path/to/checkout --base HEAD \
  --issue-file /path/to/issue.md --policy /path/to/policy.json \
  --out .sce/run-1
```

网关使用 OpenAI 兼容的 Chat Completions 接口，从 `choices[0].message.content` 读取严格 JSON。每个候选调用一次，模型无工具权限。模型只返回 `base_commit`、`strategy`、`patch`、`tests_to_run`、`assumptions` 和 `risk`。后三项只作记录。配置的模型端点会收到 Issue、筛选过的代码片段及部分基线或候选日志。

使用 GitHub Issue 或发布时，安装并认证 `gh`。待发布仓库的目标分支必须指向已验证的提交。发布为显式选项。

```sh
python3 -m sce.cli \
  --repo /path/to/checkout --base origin/main \
  --github-repo owner/repo --github-issue 42 \
  --policy /path/to/policy.json --out .sce/issue-42 \
  --publish --base-branch main
```

通过后使用专属 `sce/*` 分支创建 Draft PR。同一任务、基准和结果树会使用同一个分支，重试可复用已创建的 PR。发布前会校验远端基准，结果报告先写到本地。

## 调度与验证

1. **编译与检索。** 固定基准提交，用路径、关键词、Python 符号和导入关系对已提交内容排序。按策略分配不同大小和优先级的证据包。Git 历史只取基准及其祖先。
2. **推测执行。** 证据检索与基线验证重叠。第一批用静态证据，后续批次带基线日志。默认按任务特征选 2、4 或 8 个候选。模型和验证分别有并发上限。
3. **验证。** 临时 Git 索引应用补丁，检查路径白名单、受保护文件和修改预算。每个检查使用独立容器，挂载只读的候选快照，关闭外部网络，并限制 CPU、内存、进程数和运行时间。目标工作树和 Git 分支不受验证修改。
4. **选择与修复。** 可信验收检查至少一项在基准上失败并在候选上通过，其余基准检查通过，且候选通过全部检查时，才标记 `qualified`。默认选第一个合格候选。可配置短比较窗口，在合格候选中优先选修改文件和行数更少的补丁。首轮无可交付候选且存在可修复失败时，最多再运行一轮，并附上分类诊断和接近通过的候选。
5. **结果。** 无可复现验收失败但候选通过全部配置检查时，标记 `review`，并保存补丁供人工复核。其余结果保留失败诊断。退出码依次是 `0` 合格、`1` 启动或交付错误、`2` 人工复核、`3` 未找到候选、`4` 超过求解时限。

策略文件由操作者控制。请把验收入口、运行器配置及会影响测试发现的文件纳入保护规则，并使用能区分断言失败和基础设施故障的验收命令。容器隔离依赖本机 Docker 和可信镜像，面向敌对代码的生产部署仍需专用隔离基础设施。取消会停止本地模型请求，供应商是否停止服务端推理由其网关决定。截止时间后可能还需等待 Git 或 Docker 清理。

本版是单机原型。仓库快照仅支持普通文件，默认大小上限 64 MiB。检索最多扫描 800 个小文件，符号和导入索引仅针对 Python；通用文件仍可使用路径和关键词检索。分布式调度、持久任务队列、长期仓库索引和历史 Issue 基准评测留待后续。

## 开发测试

```sh
python3 -m unittest discover -s tests -v
```

测试使用真实临时 Git 仓库、本地 HTTP 模型模拟器和注入的验证运行器。Docker 实跑可用上面的 demo 验证。
