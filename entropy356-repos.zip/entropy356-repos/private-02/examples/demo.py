"""Run the production CLI against a tiny Git repository and a local model fixture."""

import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from threading import Thread


PROJECT = Path(__file__).resolve().parents[1]
PATCH = """diff --git a/calc.py b/calc.py
--- a/calc.py
+++ b/calc.py
@@ -1,2 +1,2 @@
 def total(x, y):
-    return x - y
+    return x + y
"""
TEST = """import unittest
from calc import total


class CalculatorTest(unittest.TestCase):
    def test_total(self):
        self.assertEqual(total(4, {operand}), {expected})
"""


class ModelFixture(BaseHTTPRequestHandler):
    def do_POST(self):
        request = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        prompt = json.loads(request["messages"][-1]["content"])
        proposal = {
            "base_commit": prompt["base_commit"],
            "strategy": prompt["strategy"],
            "patch": PATCH,
            "tests_to_run": [],
            "assumptions": [],
            "risk": [],
        }
        response = json.dumps({"choices": [{"message": {"content": json.dumps(proposal)}}]}).encode()
        self.send_response(200)
        self.send_header("Content-Length", str(len(response)))
        self.end_headers()
        self.wfile.write(response)

    def log_message(self, *args):
        pass


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True, help="new directory for the demo results")
    args = parser.parse_args()
    with TemporaryDirectory(prefix="sce-demo-") as directory:
        repo = Path(directory)
        (repo / "tests").mkdir()
        (repo / "calc.py").write_text("def total(x, y):\n    return x - y\n")
        (repo / "tests" / "test_acceptance.py").write_text(TEST.format(operand=2, expected=6))
        (repo / "tests" / "test_regression.py").write_text(TEST.format(operand=0, expected=4))
        for command in (
            ("init", "-q"),
            ("add", "."),
            ("-c", "user.name=SCE Demo", "-c", "user.email=sce@example.com",
             "-c", "commit.gpgSign=false", "-c", "core.hooksPath=/dev/null", "commit", "-qm", "Seed"),
        ):
            subprocess.run(("git", *command), cwd=repo, check=True)
        with ThreadingHTTPServer(("127.0.0.1", 0), ModelFixture) as server:
            thread = Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                env = os.environ | {
                    "SCE_MODEL_URL": f"http://127.0.0.1:{server.server_port}/v1/chat/completions",
                    "SCE_MODEL": "demo", "SCE_API_KEY": "", "NO_PROXY": "127.0.0.1", "no_proxy": "127.0.0.1",
                }
                result = subprocess.run((
                    sys.executable, "-m", "sce.cli", "--repo", str(repo),
                    "--issue", "Fix total in calc.py so it adds both inputs.",
                    "--policy", str(PROJECT / "examples" / "python-policy.json"),
                    "--out", str(args.out.resolve()),
                ), cwd=PROJECT, env=env)
            finally:
                server.shutdown()
                thread.join()
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
