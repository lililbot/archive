import asyncio
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory
from threading import Thread
import unittest
from unittest.mock import patch

from sce.contracts import Check, Options, Policy, Proposal, Task, read_policy
from sce.engine import Engine
from sce.github import publish
from sce.repository import PatchError, Repository
from sce.runtime import Gateway, ProcessResult, command


DIFF = """diff --git a/calc.py b/calc.py
--- a/calc.py
+++ b/calc.py
@@ -1,2 +1,2 @@
 def total(x, y):
-    return x - y
+    return x + y
"""
BROKEN = DIFF.replace("+    return x + y", "+    return x * y")
TEST_DIFF = """diff --git a/tests/test_calc.py b/tests/test_calc.py
--- a/tests/test_calc.py
+++ b/tests/test_calc.py
@@ -1 +1 @@
-# trusted test
+# changed test
"""


@contextmanager
def fixture():
    with TemporaryDirectory() as directory:
        path = Path(directory)
        subprocess.run(["git", "init", "-q", directory], check=True)
        (path / "tests").mkdir()
        (path / "tests" / "test_calc.py").write_text("# trusted test\n")
        (path / "calc.py").write_text("def total(x, y):\n    return x - y\n")
        repo = Repository(path)
        repo.git("add", ".")
        repo.git("-c", "user.name=Test", "-c", "user.email=test@example.com",
                 "-c", "commit.gpgSign=false", "commit", "-qm", "Initial calculator")
        yield repo, Task("Fix total in calc.py so it adds the inputs", repo.pin("HEAD"))


def proposal(task, strategy, diff=DIFF):
    return Proposal.parse({
        "base_commit": task.base, "strategy": strategy, "patch": diff,
        "tests_to_run": ["this is advisory"], "assumptions": [], "risk": [],
    }, task.base, strategy)


POLICY = Policy("test-image", ("*.py",), (), (
    Check("correct result", "acceptance", ("trusted-acceptance",), 2),
    Check("existing behavior", "regression", ("trusted-regression",), 2),
))


class FakeRunner:
    def __init__(self, baseline_pass=False):
        self.baseline_pass = baseline_pass
        self.baseline_started = asyncio.Event()
        self.release_baseline = asyncio.Event()
        self.release_baseline.set()
        self.snapshots = set()

    async def run(self, snapshot, check):
        assert not (snapshot / ".git").exists()
        assert (snapshot / "tests/test_calc.py").read_text() == "# trusted test\n"
        self.snapshots.add(snapshot)
        code = (snapshot / "calc.py").read_text()
        baseline = "x - y" in code
        if baseline:
            self.baseline_started.set()
            await self.release_baseline.wait()
        passed = check.kind == "regression" or "x + y" in code or (baseline and self.baseline_pass)
        return ProcessResult(int(not passed), "" if passed else "actual result disagrees", False)


class EngineTests(unittest.IsolatedAsyncioTestCase):
    async def test_static_starts_early_hedged_sees_logs_and_loser_is_cancelled(self):
        with fixture() as (repo, task):
            runner = FakeRunner()
            runner.release_baseline.clear()
            calls = {}
            cancelled = asyncio.Event()

            class Solver:
                async def propose(self, task, strategy, prompt):
                    calls[strategy] = prompt
                    if strategy == "minimal_fix":
                        await runner.baseline_started.wait()
                        assert "baseline" not in prompt
                        runner.release_baseline.set()
                        try:
                            await asyncio.sleep(60)
                        finally:
                            cancelled.set()
                    return proposal(task, strategy)

            result = await Engine(repo, POLICY, Options(solvers=2, deadline=5), Solver(), runner).solve(task)
            self.assertEqual(result.status, "qualified")
            self.assertEqual(result.selected.strategy, "test_driven")
            self.assertEqual(calls["test_driven"]["baseline"][0]["outcome"], "fail")
            self.assertTrue(cancelled.is_set())
            self.assertEqual(len(runner.snapshots), 2)
            self.assertTrue(all(not path.exists() for path in runner.snapshots))
            self.assertEqual(repo.git("status", "--porcelain"), b"")
            self.assertEqual(repo.pin("HEAD"), task.base)

    async def test_repair_wave_receives_diagnostics_and_reuses_original_base(self):
        with fixture() as (repo, task):
            calls = []

            class Solver:
                async def propose(self, task, strategy, prompt):
                    calls.append(prompt)
                    if failure := prompt.get("previous_wave"):
                        assert failure["counts"] == {"acceptance": 1}
                        assert failure["near_misses"][0]["checks"][0]["log"]
                        assert prompt["base_commit"] == task.base
                        return proposal(task, strategy)
                    return proposal(task, strategy, BROKEN)

            result = await Engine(
                repo, POLICY, Options(solvers=1, repair_solvers=1), Solver(), FakeRunner(),
            ).solve(task)
            self.assertEqual(result.status, "qualified")
            self.assertEqual(result.selected.wave, 2)
            self.assertEqual(len(calls), 2)

    async def test_passing_baseline_requires_review(self):
        with fixture() as (repo, task):
            class Solver:
                async def propose(self, task, strategy, prompt):
                    return proposal(task, strategy)
            result = await Engine(
                repo, POLICY, Options(solvers=1), Solver(), FakeRunner(baseline_pass=True),
            ).solve(task)
            self.assertEqual(result.status, "review")
            self.assertEqual(result.selected.wave, 1)

    async def test_failed_regression_cannot_be_qualified(self):
        with fixture() as (repo, task):
            class Solver:
                async def propose(self, task, strategy, prompt):
                    return proposal(task, strategy)

            class Runner(FakeRunner):
                async def run(self, snapshot, check):
                    if check.kind == "regression" and "x + y" in (snapshot / "calc.py").read_text():
                        return ProcessResult(1, "regression", False)
                    return await super().run(snapshot, check)

            result = await Engine(
                repo, POLICY, Options(solvers=1, repair_solvers=0), Solver(), Runner(),
            ).solve(task)
            self.assertEqual(result.status, "failed")
            self.assertEqual(result.candidates[0].status, "regression")

    async def test_optional_window_can_select_smaller_verified_patch(self):
        with fixture() as (repo, task):
            bigger = DIFF.replace("+1,2", "+1,3").replace(
                "+    return", "+    # explanation\n+    return",
            )

            class Solver:
                async def propose(self, task, strategy, prompt):
                    if strategy == "test_driven":
                        await asyncio.sleep(0.05)
                    return proposal(task, strategy, bigger if strategy == "minimal_fix" else DIFF)

            result = await Engine(
                repo, POLICY, Options(solvers=2, selection_window=1), Solver(), FakeRunner(),
            ).solve(task)
            self.assertEqual(result.selected.strategy, "test_driven")
            self.assertEqual(sum(item.status == "qualified" for item in result.candidates), 2)

    async def test_deadline_cancels_models_and_prevents_repair(self):
        with fixture() as (repo, task):
            cancelled = asyncio.Event()

            class Solver:
                async def propose(self, task, strategy, prompt):
                    try:
                        await asyncio.sleep(60)
                    finally:
                        cancelled.set()

            result = await Engine(
                repo, POLICY, Options(solvers=1, deadline=0.4), Solver(), FakeRunner(),
            ).solve(task)
            self.assertEqual(result.status, "deadline")
            self.assertEqual(result.candidates[0].status, "deadline")
            self.assertTrue(cancelled.is_set())


class ContractTests(unittest.TestCase):
    def test_wrong_base_and_model_supplied_commands_rejected(self):
        with fixture() as (repo, task):
            value = {
                "base_commit": "wrong", "strategy": "minimal_fix", "patch": DIFF,
                "tests_to_run": [], "assumptions": [], "risk": [],
            }
            with self.assertRaises(ValueError):
                Proposal.parse(value, task.base, "minimal_fix")
            value["base_commit"] = task.base
            value["command"] = "sh"
            with self.assertRaises(ValueError):
                Proposal.parse(value, task.base, "minimal_fix")

    def test_protected_test_cannot_be_changed_and_bad_diff_fails(self):
        with fixture() as (repo, task):
            with self.assertRaisesRegex(PatchError, "protected"):
                repo.apply(proposal(task, "minimal_fix", TEST_DIFF), POLICY)
            with self.assertRaises(PatchError) as caught:
                repo.apply(proposal(task, "minimal_fix", DIFF.replace("x - y", "x / y")), POLICY)
            self.assertEqual(caught.exception.kind, "apply")
            self.assertEqual(repo.git("status", "--porcelain"), b"")

    def test_only_committed_code_in_bounded_strategy_specific_evidence(self):
        with fixture() as (repo, task):
            (repo.path / "calc.py").write_text("dirty workspace secret")
            evidence = repo.evidence(task)
            self.assertEqual(evidence.pack("minimal_fix")["files"][0]["path"], "calc.py")
            self.assertEqual(evidence.pack("test_driven")["files"][0]["path"], "tests/test_calc.py")
            self.assertNotIn("dirty workspace secret", json.dumps(evidence.pack("root_cause")))
            self.assertIn("Initial calculator", evidence.pack("root_cause")["history"])

    def test_policy_rejects_invalid_budget(self):
        config = {"image": "test", "allowed_paths": ["src/*"], "checks": [
            {"name": "tests", "kind": "acceptance", "argv": ["test"]},
        ], "options": {"solvers": 9}}
        with self.assertRaisesRegex(ValueError, "solvers"):
            read_policy(config)


class GatewayTests(unittest.IsolatedAsyncioTestCase):
    async def test_real_local_http_adapter_sends_one_call_without_tools(self):
        requests = []
        task = Task("Fix total", "a" * 40)

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                requests.append((self.headers["Authorization"], json.loads(
                    self.rfile.read(int(self.headers["Content-Length"])),
                )))
                response = json.dumps({"choices": [{"message": {"content": json.dumps({
                    "base_commit": task.base, "strategy": "minimal_fix", "patch": DIFF,
                    "tests_to_run": [], "assumptions": [], "risk": [],
                })}}]}).encode()
                self.send_response(200)
                self.end_headers()
                self.wfile.write(response)

            def log_message(self, *args):
                pass

        with ThreadingHTTPServer(("127.0.0.1", 0), Handler) as server:
            thread = Thread(target=server.serve_forever, kwargs={"poll_interval": 0.02}, daemon=True)
            thread.start()
            try:
                solver = Gateway(f"http://127.0.0.1:{server.server_port}/v1/chat/completions", "mock", "fake")
                result = await solver.propose(task, "minimal_fix", {"issue": 'Quotes " and slash \\'})
            finally:
                await asyncio.to_thread(server.shutdown)
                thread.join()
        self.assertEqual(result.patch, DIFF)
        self.assertEqual(len(requests), 1)
        auth, request = requests[0]
        self.assertEqual(auth, "Bearer fake")
        self.assertNotIn("tools", request)
        self.assertEqual(json.loads(request["messages"][1]["content"])["issue"], 'Quotes " and slash \\')

    async def test_timeout_of_async_subprocess(self):
        with self.assertRaises(TimeoutError):
            await command(("sleep", "10"), timeout=0.05)


class DeliveryTests(unittest.IsolatedAsyncioTestCase):
    async def test_retries_reuse_commit_branch_and_existing_pr(self):
        with fixture() as (repo, task):
            class Solver:
                async def propose(self, task, strategy, prompt):
                    return proposal(task, strategy)
            result = await Engine(
                repo, POLICY, Options(solvers=1), Solver(), FakeRunner(),
            ).solve(task)
            remote = {}
            pr = []
            url = "https://github.com/owner/repo/pull/1"

            async def fake_git(argv, **kwargs):
                if "ls-remote" in argv:
                    return ProcessResult(0, remote.get(argv[-1], ""), False)
                self.assertIn("push", argv)
                commit, ref = argv[-1].split(":")
                self.assertIn(f"--force-with-lease={ref}:", argv)
                remote[ref] = f"{commit}\t{ref}"
                return ProcessResult(0, "", False)

            async def fake_gh(*argv):
                if argv[0] == "api":
                    return task.base
                if argv[:2] == ("pr", "list"):
                    return json.dumps(pr)
                self.assertIn("--draft", argv)
                pr.append({"url": url})
                return url

            with patch("sce.github.command", fake_git), patch("sce.github.gh", fake_gh):
                for _ in range(2):
                    self.assertEqual(await publish(repo, "owner/repo", "main", task, result.selected), url)
            self.assertEqual(len(remote), 1)
            self.assertEqual(len(pr), 1)
