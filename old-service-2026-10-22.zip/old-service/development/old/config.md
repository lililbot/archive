# config.md — 配置项与默认值

> 改动前看 `../doc_maintenance.md`。

> 语义与结构见 `design.md`。默认值选定的原因见 `explain.md`。

运行时通过 `SBX_` 前缀环境变量覆盖。

有两种例外不走 `SBX_` 前缀，均属 Docker 约定：

| 变量 | 作用 |
|---|---|
| `DOCKER_HOST` | daemon 地址，默认 `/var/run/docker.sock`；可写 `unix://` 前缀 |
| `PORT` | 平台注入；仅在 `SBX_LISTEN_ADDR` 未设置时生效 |

## 容器资源

| 环境变量 | 默认值 | 说明 |
|---|---|---|
| `SBX_CONTAINER_CPU` | `2` | 容器 CPU 核数 |
| `SBX_CONTAINER_MEMORY_MB` | `4096` | 容器内存上限（MB） |

## 磁盘

| 环境变量 | 默认值 | 说明 |
|---|---|---|
| `SBX_USER_DISK_MB` | `16384` | 每 user 的 `/home/user` + `/tmp` 合计上限（MB） |
| `SBX_OUTPUT_TMP_QUOTA_MB` | `1024` | 单 job 输出上限（MB），非磁盘配额 |
| `SBX_HOME_VOLUME_ROOT` | `/var/lib/sandbox-exec/home` | 持久卷根目录 |

## 网络

| 环境变量 | 默认值 | 说明 |
|---|---|---|
| `SBX_DOCKER_NETWORK` | `sandbox-egress` | 容器网络名 |
| `SBX_EGRESS_SUBNET_BASE` | `172.20.0.0/16` | 出站子网基数，在其上切分每 user 的 `/30` |
| `SBX_EGRESS_BLOCK_CIDRS` | 见下 | 屏蔽网段，逗号分隔 |
| `SBX_EGRESS_ENFORCE_HOST` | `true` | 是否下发宿主侧规则 |
| `SBX_APK_MIRROR` | `mirrors.aliyun.com` | 容器内 apk 镜像源主机 |

`SBX_EGRESS_BLOCK_CIDRS` 默认值：

```
127.0.0.0/8,10.0.0.0/8,172.16.0.0/12,192.168.0.0/16,
169.254.0.0/16,100.64.0.0/10,100.100.100.200/32
```

## 并发与超时

| 环境变量 | 默认值 | 说明 |
|---|---|---|
| `SBX_PER_USER_MAX_JOBS` | `64` | 单 user 的 pending 上限 |
| `SBX_CONTAINER_TOTAL_LIMIT` | `0` | 全局容器并发上限，`0` 为不限 |
| `SBX_EXEC_SYNC_WAIT_S` | `10` | `/exec` 同步等待秒数 |
| `SBX_TIMEOUT_MAX_S` | `300` | `timeout` 参数上限（秒） |

## 内容与输出

| 环境变量 | 默认值 | 说明 |
|---|---|---|
| `SBX_CONTENT_MAX_BYTES` | `65536` | `/write` 单次内容上限（字节） |
| `SBX_CAT_MAX_BYTES` | `1048576` | `/cat` 单次返回上限（字节），`0` 为不限 |
| `SBX_OUTPUT_HEAD_BYTES` | `2048` | 正常场景 `output_head` 长度 |
| `SBX_OUTPUT_HEAD_BYTES_FALLBACK` | `512` | 异常场景与 piggyback 的 `output_head` 长度 |
| `SBX_BINARY_CHECK_WINDOW` | `8192` | 二进制判定窗口（字节） |
| `SBX_BINARY_INVALID_RATIO` | `0.3` | 无效 UTF-8 字节占比阈值 |

## piggyback

| 环境变量 | 默认值 | 说明 |
|---|---|---|
| `SBX_PIGGYBACK_MAX_ITEMS` | `20` | 单次附随条目上限 |
| `SBX_PIGGYBACK_UNDELIVERED_RETENTION_S` | `3600` | 未投递记录的保留秒数 |

## 回收

| 环境变量 | 默认值 | 说明 |
|---|---|---|
| `SBX_GC_IDLE_CONTAINER_S` | `1800` | 容器空闲回收阈值（秒） |
| `SBX_GC_JOB_RETENTION_S` | `600` | 已投递 job 记录的保留秒数 |
| `SBX_GC_TOMBSTONE_RETENTION_S` | `600` | 墓碑保留秒数 |
| `SBX_GC_JOB_RECORD_LIMIT` | `1000` | job 记录总量上限（不计墓碑） |
| `SBX_GC_SCAN_INTERVAL_S` | `60` | GC 扫描周期（秒） |

## 服务

| 环境变量 | 默认值 | 说明 |
|---|---|---|
| `SBX_LISTEN_ADDR` | `0.0.0.0:8080` | 监听地址；优先于平台注入的 `PORT` |
| `SBX_BASE_IMAGE` | `alpine:3.19` | 基础镜像 |
| `SBX_USER_ALLOWLIST` | 空（拒绝所有） | 允许的 user，逗号分隔 |

## 启动校验

以下规则不满足时**启动失败**：

| 规则 |
|---|
| `output_tmp_quota_mb < user_disk_mb` |
| `piggyback_undelivered_retention_s >= gc_job_retention_s` |
| `timeout_max_s >= exec_sync_wait_s` |
| `output_head_bytes >= output_head_bytes_fallback` |
| `piggyback_max_items >= 1` |
| `binary_check_window >= 1` |
| `0 < binary_invalid_ratio < 1` |
| `container_cpu >= 1` |
| `container_memory_mb >= 64` |
| `user_disk_mb >= 1` |
| `content_max_bytes >= 1` |
| `cat_max_bytes >= 0` |
| `gc_scan_interval_s >= 1` |
| `egress_subnet_base` 为合法 IPv4 CIDR 且掩码不短于 `/24` |
| `egress_enforce_host` 为真时 `egress_block_cidrs` 非空 |

## 部署脚本预设

`deploy-start.sh` 在默认值之上覆盖：

| 变量 | 值 | 用途 |
|---|---|---|
| `SBX_USER_ALLOWLIST` | `alice,bob,demo` | 演示白名单 |
| `SBX_HOME_VOLUME_ROOT` | `/tmp/sandbox-exec-home` | 脚本内固定，与文档默认值不同（`explain.md` 23） |
| `SBX_CONTAINER_TOTAL_LIMIT` | `8` | 限制总量 |
| `SBX_TIMEOUT_MAX_S` | `60` | 收紧超时 |
| `SBX_GC_IDLE_CONTAINER_S` | `600` | 加快回收 |

## 预留项

以下字段存在于配置结构中，但**没有任何环境变量入口**，取值恒定：

| 字段 | 当前值 | 说明 |
|---|---|---|
| `EgressDNS` | 空 | 空即继承宿主 `/etc/resolv.conf`；保留字段以备指定容器 DNS |
