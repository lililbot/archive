# REQ.local.md — 落地环境相关需求与限制

> 改动前看 `../doc_maintenance.md`。

> 本文件只记录**在目标落地环境中新增或收紧的需求/限制**，以及该环境实测所得的事实约束。
> 环境无关的原始需求见 `REQ.md`。

## 运行环境

| 项 | 值 |
|---|---|
| 宿主 OS | Ubuntu 22.04 |
| 容器运行时 | Docker Engine（Unix socket `/var/run/docker.sock`） |
| 宿主文件系统 | overlay2 on `/`，`/dev/vdb` 为 ext4 |
| 可执行文件位置 | `/workspace/sandbox-exec/bin/sandbox-exec` |

## 环境附加限制

| 编号 | 限制 | 来源 |
|---|---|---|
| L1 | 服务经平台反向代理暴露，前置 WAF 会拦截含 `cmd=`、`command=`、`://` 的查询串 | 实测 |
| L2 | 客户端真实 IP 仅在 `X-Forwarded-For[0]`；`RemoteAddr` 恒为 `[::1]` | 实测 |
| L3 | 平台会强制覆盖 `Authorization`、`X-Space-Key`、`X-Real-Ip`、`X-Forwarded-For` | 实测 |
| L4 | 平台注入的 JWT 为 `HS256` 对称签名，且无 JWKS 端点，服务侧无法自主验签 | 实测 |
| L5 | 沙箱本身有完整出网能力 | 实测 |
| L6 | 宿主为 overlay2 + ext4，**无 XFS pquota**，Docker `HostConfig.StorageOpt` 不可用 | 实测 |
| L7 | 容器默认无 `CAP_NET_ADMIN`，容器内 `iptables` / `ip route` 不可用 | 实测 |
| L8 | 容器无 IPv6 路由，仅需处理 IPv4 | 实测 |
| L9 | 平台就绪探针依赖日志中出现 `serving http` 字样；平台注入 `PORT` 环境变量 | 实测 |

## 网络可达性矩阵（容器内，bridge 网络）

| 目标 | 可达 |
|---|---|
| `mirrors.aliyun.com` | ✅ |
| `mirrors.cloud.tencent.com` | ✅ |
| `registry.npmmirror.com` | ✅ |
| `goproxy.cn` | ✅ |
| `dl-cdn.alpinelinux.org` | ❌ |
| `mirrors.tuna.tsinghua.edu.cn` | ❌ |
| `pypi.tuna.tsinghua.edu.cn` | ❌ |
| `github.com` | ❌ |

## 落地后新增的需求

| 编号 | 需求 | 说明 |
|---|---|---|
| LA1 | 全部功能必须可由纯 GET 达成 | 调用方是 LLM，POST 仅可作为人工上传的补充通道，不得成为必需路径 |
| LA2 | 容器网络直接开 bridge | 不放行出站则无法满足 F4/F5 |
| LA3 | 容器出站须屏蔽内网与云元数据地址 | 开放出站后新增的风险面 |
| LA4 | 基础镜像需预配可达的包管理镜像源 | 见网络可达性矩阵 |

> 管理页面（原 F7）已拆分为独立服务，其落地需求见 `../new/REQ.local.md`。
