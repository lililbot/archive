# explain.md — 取舍与原因（沙箱执行服务）

> 改动前看 `../doc_maintenance.md`。

> 本文件收敛**原因、取舍与论证**中，`security.md` 未覆盖的部分。
> 安全相关事宜见 `security.md`。
> `design.md` / `config.md` 只描述"是什么"，不解释"为什么"。
> 阅读设计前若对某个选择存疑，在此查找。
>
> 管理页面服务的取舍见 `../new/explain.md`。

## 1. 输入 URL 上限与 GET-only 约束

**约束**：`REQ.md` C2 规定调用方仅能 GET。

**后果**：载荷只能承载在 URL 中。而 URL 受三重限制：

| 限制 | 量级 |
|---|---|
| HTTP 请求行上限 | 约 8 KB |
| 百分号编码膨胀 | 约 ×3 |
| `content_max_bytes` | 64 KB（名义值） |

三者取最小，实际单次 `/write` 可用载荷约 **2 KB**。`content_max_bytes` 的名义值
在 GET-only 下无法真正用满。

**取舍**：不为大写入新开接口，而是把大文件写入引导到 `/exec`
（经 heredoc 或 base64 写入）。理由：`/exec` 已是通用逃生口，
新增分片接口会引入"部分写入状态"这一新的失败模式（需处理中断、重放、并发写同一文件），
而 `/exec` 天然是原子的单次执行。

## 2. 强制百分号编码

**做法**：拒绝 `+`、裸非 ASCII 字节、非法/截断转义、裸 `\`。

**理由**：安全考量见 `security.md` 5。

**代价**：

- URL 可读性下降，手工调试易踩坑（已在 `docs/` 中给出 `--data-urlencode` 示例）
- 载荷膨胀约 3 倍，与第 1 节的上限问题叠加
- 反直觉特例需额外说明：裸 `\` 拒绝，但编码后的 `%5C` 必须放行
  （解码后它只是普通字符，不构成路径穿越）

**结论**：收益（消除歧义与绕过面）大于代价（编码繁琐），故采纳。

## 3. 磁盘配额采用软配额

**约束**：`REQ.local.md` L6 —— 宿主为 overlay2 + ext4，**无 XFS pquota**，
Docker `HostConfig.StorageOpt size=` 不可用（该选项依赖 XFS project quota）。

**可选方案**：

| 方案 | 可行性 |
|---|---|
| Docker `StorageOpt size` | ❌ 宿主无 XFS pquota |
| 每 user 一个 loop 设备 / 独立卷 | 可行，但需宿主特权与设备管理，运维成本高 |
| 服务侧计量 + 下发前预检 | ✅ 无宿主额外要求 |
| 服务侧计量 + 容器内 `ulimit -f` | 可行，但会误伤正常的单大文件写入 |

**取舍**：选服务侧计量 + 预检。安全影响见 `security.md` 4。

## 4. 清理类命令豁免（破死锁）

**问题**：配额预检会拦下**所有** `/exec`。若不做例外，用户把磁盘写满后，
连 `rm` 都会被 507 拒绝——用户无法自行恢复，只能等待容器被回收。这是死锁。

**做法**：命令以清理类动词开头时豁免预检（`rm` / `rmdir` / `unlink` / `shred` /
`find` / `truncate` 等）。

**取舍**：豁免是**前缀匹配**，不追求完备，只覆盖最常见清理动作。
风险可控：即便有人借 `find -exec` 之类写入文件，下一次预检仍会生效。

## 5. `/tmp` 为 bind mount 而非 tmpfs

**设计初衷**：`/tmp` 用 tmpfs，占用计入容器内存配额，无需额外磁盘预算。

**实现结果**：`/tmp` 改为宿主机 bind mount（`design.md` 4.2）。

**原因**：Docker 的 archive API（`docker cp`）**无法读取 tmpfs 挂载点内的文件**，
返回 `Could not find the file /tmp/.out_1 in container <id>`。这会导致输出文件
永远取不回，`output_head` 恒为空、`/cat` 恒 404。这是 Docker 的既有限制。

**语义损失**：`/tmp` 不再占用容器内存配额。

**补偿**：`/tmp` 与 `/home/user` 合并计入 `user_disk_mb` 磁盘预算，
并在 `/exec` 前预检。因此"容器把宿主磁盘写满"的风险已被覆盖，
仅失去"内存配额"这一维度的约束。

**连带的取舍**：输出配额的上限约束随之改变。原规则
`output_tmp_quota_mb < container_memory_mb` 的前提是 `/tmp` 占内存，
该前提消失后改为 `output_tmp_quota_mb < user_disk_mb`（`config.md` 启动校验）。

## 6. 出站管控放在宿主侧而非容器内

**约束**：`REQ.local.md` L7 —— 容器默认无 `CAP_NET_ADMIN`。

**实测**：容器内 `iptables -A OUTPUT ...` 返回
`Permission denied (you must be root)`；`ip route add` 返回
`RTNETLINK answers: Operation not permitted`。二者同属 `NET_ADMIN`。

**可选方案**：

| 方案 | 评价 |
|---|---|
| 容器内 iptables | ❌ 需 `--cap-add NET_ADMIN` |
| 容器内静态路由 | ❌ 同样需 NET_ADMIN |
| 改 `/etc/hosts` / `resolv.conf` | ❌ 可写，但只挡域名解析，挡不住直连 IP |
| **宿主侧 `FORWARD` 链** | ✅ 无需额外 capability |

**取舍**：选宿主侧。安全理由见 `security.md` 3。

**代价**：依赖宿主 `iptables` 权限；需要为每 user 分配独立网段以便按源网段精确匹配
（默认 `bridge` 的 `172.17.0.0/16` 被所有容器共用，按段拒绝会误伤其它容器）。

## 7. 自建 `SBX_EGRESS` 链而非 `DOCKER-USER`

**理由**：

- `DOCKER-USER` 由 Docker 管理，在部分版本/配置下可能不存在或被重建
- 本服务需要**按 user 源网段**分流，自建链 + 每 user 子链的结构更清晰、幂等性更好控制

**插入位置**：`-I FORWARD 1`，确保先于 Docker 自身规则命中
（Docker 亦使用 `-I` 插到链首）。

## 8. 使用 `REJECT` 而非 `DROP`

**理由**：`DROP` 会让容器内的连接尝试静默挂起，调用方（LLM）会误判为"网络慢"
并反复重试，浪费超时预算。`REJECT` 立即返回错误，意图明确。

## 9. 容器间通信关闭（`enable_icc=false`）

**理由**：用户之间不应能互相访问。文件与进程已由独立容器隔离，
关闭 ICC 补上网络这一维度（见 `security.md` 3）。

**注意**：需放行到网关的流量（DNS 与出站经 NAT），ICC 仅阻断容器↔容器。

## 10. 输出经文件重定向而非管道

**做法**：`/bin/sh -c '<cmd> > /tmp/.out_<jobid> 2>&1'`，执行结束后读文件。

**理由**：文件描述符重定向**无用户态缓冲层**。若用管道，管道缓冲区与
用户态缓冲会让"进程已退出"与"输出已可读"之间出现不确定窗口，
`output_head` 就无法保证是 `output_file` 的确定前缀。

## 11. 两个必须避开的执行陷阱

| 陷阱 | 现象 | 正确做法 |
|---|---|---|
| 用 `setsid` 包装命令 | busybox 的 `setsid` fork 后立即返回，exec 早于命令结束就退出 → **超时完全失效、退出码恒为 0** | 用 `sh -c` 直接执行，靠外层 shell 等待 |
| `AttachStdout:false` + `Detach:false` | `/exec/start` 立即返回，服务无法感知命令何时结束 → 同上 | 必须 `AttachStdout/Stderr: true` |

两者都会造成"命令看起来成功但实际没跑完"，是联调中最易踩的坑。

## 12. 超时靠进入容器 kill 进程

**理由**：取消 exec 的 HTTP 流只会断开服务与 daemon 的连接，
**容器内进程仍在运行**，超时形同虚设。

**做法**：定时器到期后进入容器，以输出文件 `/tmp/.out_<jobid>` 为标记，
遍历 `/proc/<pid>/fd` 用 `readlink` 定位持有该文件的进程，再终止；
兜底按命令行匹配标记。

**关键约束**：只杀与**本 job 标记相关**的进程，**不做无差别 `pkill`**，
否则会误杀同容器内其它并发 job 的进程。

## 13. 输出配额打满不终止进程

**理由**：`truncated=true` 的语义是"不写入配额之外的字节"，
不包含"终止进程"。持续输出的命令（如 `yes`）会运行到 `timeout`。

**后果**：**`timeout` 是这类命令的唯一终止手段**，调用方必须设置合理值。

## 14. 读取期二进制判定不回写 job 状态

**理由**：`/status` 的结果须保持幂等。若 `/cat` 的读取期判定回写 `outcome`，
同一 job 多次查询会得到不同结果。

**做法**：`/cat` 命中二进制时返回该 job 的结果结构并附 `note` 字段说明，
但不改动已发布的 `outcome`。

## 15. 墓碑不计入记录上限，且新代次立即失效

**理由**：

- 墓碑若不独立存储，会挤占 `gc_job_record_limit`，导致活跃 job 被提前清理
- 若新代次启动时不失效历史墓碑，同一 `job_id` 可能同时命中墓碑与活跃记录，
  查询结果不确定

## 16. 进程启动时清理孤儿容器与网络规则

**问题**：服务进程异常退出（崩溃、被 kill）后，容器仍在运行；
新进程的内存态为空，GC 遍历不到这些容器，会永久泄漏并占满 `container_total_limit`。
网络规则同理，且按段序号命名，重启后无法对应。

**取舍**：清理而非保留。内存态（job 记录、代次）已丢失，保留容器只会得到无主实例。

## 17. 先监听再做对账

**理由**：对账需遍历 Docker 容器，可能耗时数秒。若放在监听之前，
平台就绪探针会在该窗口期内探测失败。

**代价**：对账期间容器数短暂偏高，由后续 GC 收敛。

## 18. 就绪日志措辞

**约束**：`REQ.local.md` L9 —— 平台探针依赖日志中的 `serving http` 字样。

**做法**：保留 `[init] serving http on <addr>` 这一措辞，并在注释中标明不可改动。

## 19. 参数别名

**约束**：`REQ.local.md` L1 —— 前置 WAF 拦截含 `cmd=`、`command=`、`://` 的查询串。

**做法**：同一语义接受多个参数名（见 `design.md` 2.2），
使调用方可绕开被拦截的写法。语义完全等价。

## 20. 容器内预配包管理镜像源

**约束**：`REQ.local.md` 网络可达性矩阵 —— alpine 默认源 `dl-cdn.alpinelinux.org`
实测不可达。不配置则无法满足 `REQ.md` F5（自行安装所需包）。

**做法**：容器启动后重写 `/etc/apk/repositories` 为可达镜像
（默认 `mirrors.aliyun.com`），并注入 `PIP_INDEX_URL` / `PIP_TRUSTED_HOST`。

**失败处理**：配置失败仅告警，不阻断容器创建——服务可用性优先于该增强能力。

## 21. 不引入 Docker SDK

**理由**：SDK 的传递依赖要求 Go ≥ 1.25，而项目以标准库实现可直接编译。
直接使用 Docker Engine HTTP API 亦减少了依赖面与供应链风险。

## 22. 不做鉴权

**约束**：`REQ.md` C1 —— 运行在可信环境，不考虑鉴权。

**做法**：`user` 白名单仅做**参数格式校验与调用侧隔离**，不构成认证。

**安全影响**：见 `security.md` 1 与 2。

## 23. 部署脚本覆盖 `home_volume_root`

**背景**：`config.md` 的默认值是 `/var/lib/sandbox-exec/home`，
而 `deploy-start.sh` 与 `run-local.sh` 都把它设为 `/tmp/sandbox-exec-home`。

**原因**：脚本运行在**容器内的临时环境**，`/var/lib` 不保证可写且不持久；
`/tmp` 在容器内总可写。文档默认值面向的是**真实宿主部署**。

**取舍**：两者不一致是刻意的，脚本不承担"给出生产默认值"的职责。
真实部署应显式设置该变量，不应依赖脚本。

**需注意**：新服务（`../new/config.md` 的 `MGR_HOME_VOLUME_ROOT`）
必须与此处最终生效的值一致，否则会管理一个空目录。
