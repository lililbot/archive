# design.md — 设计文档

> 改动前看 `../doc_maintenance.md`。

> 需求见 `REQ.md` / `REQ.local.md`。方案取舍的原因见 `explain.md`。
> 参数默认值的选定见 `config.md`。

## 1. 总体结构

```
调用方 ──GET──▶ HTTP API 层 ──▶ 执行器 ──Docker Engine API──▶ Docker daemon
                    │              │                                │
                    ▼              ▼                                ▼
                 状态存储      宿主侧出站规则                  每用户一个容器
```

四个组成部分：

| 组件 | 职责 |
|---|---|
| API 层 | 参数校验、编码解析、错误码映射、响应组装 |
| 执行器 | 容器生命周期、命令执行编排、文件操作、磁盘配额 |
| 状态存储 | job 状态机、代次、墓碑、piggyback 队列 |
| 出站管控 | 每用户网段分配、宿主侧防火墙规则下发 |

## 2. 接口

全部为 `GET`，响应 `application/json; charset=utf-8`，统一带 `Cache-Control: no-store`。

| 接口 | 作用 |
|---|---|
| `GET /exec` | 提交命令 |
| `GET /status` | 查询 job 状态 |
| `GET /cat` | 读文件（分页） |
| `GET /write` | 写文件 |
| `GET /ls` | 列目录 |
| `GET /healthz` | 健康检查 |

除 `/healthz` 外，每个接口都要求 `user`，且查询参数为**严格白名单**：
出现未列出的参数即 `400`。

| 接口 | 接受的参数 |
|---|---|
| `/exec` | `user`、`cmd`/`q`/`command`、`timeout_s`/`timeout` |
| `/cat` | `user`、`path`/`p`、`offset`、`max_bytes`/`limit` |
| `/write` | `user`、`path`/`p`、`content`/`text`/`d` |
| `/ls` | `user`、`path`/`p` |
| `/status` | `user`、`job_id` |

### 2.1 通用参数

| 参数 | 必填 | 约束 |
|---|---|---|
| `user` | ✅ | `^[A-Za-z0-9_-]{1,64}$`，且在白名单内 |
| `job_id` | 仅 `/status` | 十进制整数，`1 ≤ job_id ≤ 2^31-1` |
`user` 的校验次序为**先格式后白名单**：格式不合法 → `400`，格式合法但不在白名单 → `403`。

### 2.2 参数别名

同一语义接受多个参数名，语义完全等价：

| 语义 | 接受的参数名 |
|---|---|
| 命令 | `cmd` / `q` / `command` |
| 超时 | `timeout_s` / `timeout` |
| 路径 | `path` / `p` |
| 单次读取上限 | `max_bytes` / `limit` |
| 写入内容 | `content` / `text` / `d` |

`user`、`job_id`、`offset` 无别名。

### 2.3 编码规则

查询串接受**百分号编码**。以下一律 `400`：

- `+`（不作为空格，空格须写 `%20`）
- 裸非 ASCII 字节
- 非法转义（`%ZZ`）与截断转义（`%A`）
- 裸 `\`

解码后的字符属于普通数据，不再二次解析。

### 2.4 错误码

| 码 | `error` | 触发条件 |
|---|---|---|
| 400 | `invalid argument` | 参数缺失/格式错/越界/未预期；编码不合规 |
| 403 | `user not allowed` | `user` 格式合法但不在白名单 |
| 404 | `not found` | 文件或 job 不存在 |
| 409 | `target is a directory` | 写入目标为目录 |
| 413 | `content too large` | 写入内容超过 `content_max_bytes` |
| 429 | `too many jobs` | 该 user 的 pending 数达上限 |
| 503 | `no capacity` | 全局容器数达上限 |
| 507 | `disk quota exceeded` | 磁盘用量达 `user_disk_mb` |

## 3. 状态模型

`state` 与 `result.outcome` 两个维度**正交**。

### 3.1 `state`

| 值 | 含义 |
|---|---|
| `pending` | 执行中 |
| `finished` | 已结束（成功或失败均属此类） |
| `recycled` | 所属容器已回收，结果不可得 |

容器回收后，`/status` 返回 `200` + `recycled`（非 404）。该记录称为**墓碑**。

### 3.2 `result.outcome`

| 值 | 含义 |
|---|---|
| `ok` | 进程正常结束（退出码非零亦属此类） |
| `unusable` | 结果不可用 |

`unusable` 的三种原因（`result.error`）：

| `error` | 触发条件 |
|---|---|
| `timeout` | 超过 `timeout` 未结束 |
| `binary output` | 输出判定为二进制 |
| `output quota exceeded` | 输出超过 `output_tmp_quota_mb` |

### 3.3 job 标识

`(user, generation, job_id)` 唯一确定一个 job。`job_id` 在每个代次内从 1 递增。

## 4. 容器模型

容器运行时为 Docker Engine，服务经 Unix socket 直连 Engine HTTP API，API 版本 `v1.47`。

### 4.1 生命周期

每 user 一个容器，按需冷启动。容器内 `Cmd` 为 `sleep infinity`，命令经 `docker exec` 驱动。

| 事件 | 行为 |
|---|---|
| 首次请求该 user | 创建并启动容器，`generation` 自增，失效该 user 的历史墓碑 |
| 空闲超时 | 由 GC 回收，写墓碑 |
| 请求已回收的 user | 重新冷启动，`job_id` 从 1 重新计数 |

### 4.2 挂载

| 容器内路径 | 宿主目录 | 语义 |
|---|---|---|
| `/home/user` | `<root>/<user>/home` | 持久卷，跨代次保留 |
| `/tmp` | `<root>/<user>/tmp` | 易失工作区，回收时清空 |

`/tmp` 为宿主机 bind mount，**不是 tmpfs**——Docker archive API 读不到 tmpfs 内的文件，
取不回输出。代价是该目录不占用容器内存配额，改由磁盘预算覆盖（第 6 节、`explain.md` 5）。

### 4.3 资源限制

| 项 | 施加方式 |
|---|---|
| 内存 | `HostConfig.Memory`，`MemorySwap` 取同值以禁用 swap |
| CPU | `HostConfig.NanoCpus`，由核数换算 |
| 进程数 | `HostConfig.PidsLimit`，固定 `512` |
| 磁盘 | 服务侧计量 + 下发前预检 |

## 5. 命令执行

### 5.1 输出路径

命令的 stdout/stderr 经 shell 重定向到容器内 `/tmp/.out_<job_id>`：

```
/bin/sh -c '<用户命令> > /tmp/.out_<job_id> 2>&1'
```

执行结束后，服务从该文件读回输出。

### 5.2 摘要与完整输出

| 字段 | 内容 |
|---|---|
| `result.output_head` | 输出前缀，长度按 `output_head_bytes` / `output_head_bytes_fallback` 择一 |
| `result.output_file` | `tmp/.out_<job_id>`，可经 `/cat` 读取完整内容 |

`output_head` 是 `output_file` 内容的确定前缀。

### 5.3 超时

到期后终止容器内该 job 的进程，等待其退出，取真实退出码。

### 5.4 输出配额

单 job 输出超过 `output_tmp_quota_mb` 时，截断并置 `result.truncated=true`，
**不终止进程**。

### 5.5 二进制判定

命中条件（满足其一）：

- 输出中出现 NUL 字节
- 判定窗口内无效 UTF-8 字节占比超过 `binary_invalid_ratio`

判定窗口为 `binary_check_window` 字节。读取期（`/cat`）判定命中不回写 job 状态。

## 6. 磁盘配额

### 6.1 计量范围

`/home/user` 与 `/tmp` 的**合计**占用，上限为 `user_disk_mb`。

### 6.2 检查点

| 位置 | 时机 |
|---|---|
| `/write` | 写入前；覆盖写时扣除目标文件原有大小 |
| `/exec` | 命令下发前 |

超限返回 `507`。

### 6.3 清理类命令豁免

命令以清理类**前缀**开头时，豁免 `/exec` 的预检。前缀为白名单，不追求完备：

```
rm   rmdir   unlink   shred   find   truncate   dd if=/dev/null
```

判定前先剥去 `sudo`／`command`／`exec` 三种包装前缀，使 `sudo rm ...` 同样命中。

## 7. 网络

### 7.1 容器网络

每 user 连接独立网络，分配独占 `/30` 网段，子网基数由 `egress_subnet_base` 决定。

容器间通信关闭。

### 7.2 出站策略

**禁内网与元数据，公网自由。**

默认屏蔽网段：

| 网段 | 含义 |
|---|---|
| `127.0.0.0/8` | 回环 |
| `10.0.0.0/8` | 私网 |
| `172.16.0.0/12` | 私网 |
| `192.168.0.0/16` | 私网 |
| `169.254.0.0/16` | 链路本地与云元数据 |
| `100.64.0.0/10` | CGNAT |
| `100.100.100.200/32` | 云元数据服务 |

### 7.3 规则位置

规则施加于**宿主侧** `FORWARD` 链，按容器源网段匹配。

规则链结构：

```
SBX_EGRESS            各屏蔽网段的 REJECT 规则
SBX_EGRESS_USER_<n>   每 user 链，仅一句跳转到 SBX_EGRESS
FORWARD               -s <user /30> -j SBX_EGRESS_USER_<n>，插在链首
```

链名与每 user 链的后缀序号均由服务自行编号，重启后重建。

### 7.4 DNS

`egress_dns` 为空（默认）时容器继承宿主 `/etc/resolv.conf`；
非空则以 `HostConfig.Dns` 覆盖容器 DNS。当前无环境变量入口（`config.md` 预留项）。

## 8. 隔离

| 维度 | 手段 |
|---|---|
| 文件 | 每 user 独立宿主目录，仅该目录挂载进容器 |
| 进程 | 每 user 独立容器 |
| 网络 | 每 user 独立 `/30`，关闭容器间通信 |
| 路径 | 仅接受相对路径；绝对路径与 `..` 逃逸一律 `400` |

保留路径 `tmp/.out_*` 不可经 `/write` 写入。

## 9. 附随投递（piggyback）

为避免轮询，`/exec`、`/write`、`/cat`、`/ls` 的响应中附带该 user **尚未投递**的 job 摘要。

| 项 | 规则 |
|---|---|
| 不附加于 | `/status` |
| 条目上限 | `piggyback_max_items` |
| 排序 | `job_id` 升序 |
| `output_head` | 按 `output_head_bytes_fallback` 截断 |
| 投递即标记已读 | 不再出现在后续响应 |
| 未投递保留 | `piggyback_undelivered_retention_s` 后由 GC 清理 |

`/exec` 走同步等待路径时，其结果即算已投递，不再进入 piggyback。

## 10. 回收

后台 GC 周期为 `gc_scan_interval_s`，负责：

| 对象 | 条件 |
|---|---|
| 空闲容器 | 空闲超过 `gc_idle_container_s` |
| job 记录 | 已投递且超过 `gc_job_retention_s`；总量超 `gc_job_record_limit` |
| 墓碑 | 超过 `gc_tombstone_retention_s` |

进程启动时清理上一进程遗留的容器与网络规则，并重新编号每 user 链。
