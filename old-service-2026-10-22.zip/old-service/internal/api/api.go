package api

import (
	"context"
	_ "embed"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/http"
	"net/url"
	"os"
	"regexp"
	"strconv"
	"strings"
	"time"

	"sandbox-exec/internal/config"
	"sandbox-exec/internal/executor"
	"sandbox-exec/internal/store"
)

// Server HTTP API 层。全部接口为 GET（设计文档 1）。
type Server struct {
	cfg *config.Config
	st  *store.Store
	ex  *executor.Executor

	userRe *regexp.Regexp
}

func NewServer(cfg *config.Config, st *store.Store, ex *executor.Executor) *Server {
	return &Server{
		cfg:    cfg,
		st:     st,
		ex:     ex,
		userRe: regexp.MustCompile(`^[A-Za-z0-9_-]{1,64}$`),
	}
}

func (s *Server) Routes() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/exec", s.handleExec)
	mux.HandleFunc("/write", s.handleWrite)
	mux.HandleFunc("/cat", s.handleCat)
	mux.HandleFunc("/ls", s.handleLs)
	mux.HandleFunc("/status", s.handleStatus)
	mux.HandleFunc("/healthz", s.handleHealth)
	return s.withCommonHeaders(mux)
}

// queryKey 是严格解析后的查询参数在 context 中的键。
type queryKeyType struct{}

var queryKey = queryKeyType{}

// withCommonHeaders 所有响应带 Cache-Control: no-store（设计文档 1），
// 并在此处一次性完成**严格百分号编码解析**（v4）。
//
// 解析失败直接 400 返回，不进入业务逻辑 —— 这样各 handler 无需重复处理编码错误。
func (s *Server) withCommonHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("Content-Type", "application/json; charset=utf-8")

		q, err := strictQuery(r.URL.RawQuery)
		if err != nil {
			writeErr(w, 400, "invalid argument")
			return
		}
		next.ServeHTTP(w, r.WithContext(context.WithValue(r.Context(), queryKey, q)))
	})
}

// queryOf 取出严格解析后的查询参数。
// 若上游未注入（例如单测直接调用 handler），退回标准库解析以保持兼容。
func queryOf(r *http.Request) url.Values {
	if q, ok := r.Context().Value(queryKey).(url.Values); ok {
		return q
	}
	return r.URL.Query()
}

// ---------- 响应构造 ----------

// jobView 对外统一的 job 视图（/exec、/status、piggyback 同构）。
type jobView struct {
	State  store.State   `json:"state"`
	JobID  int           `json:"job_id"`
	Result *store.Result `json:"result,omitempty"`
	// 仅 recycled 时使用
	Error string `json:"error,omitempty"`
	// /cat 读取期二进制命中时的说明（不回写 job 状态）
	Note string `json:"note,omitempty"`
}

func viewOfJob(j *store.Job) jobView {
	v := jobView{State: j.State, JobID: j.JobID}
	if j.State == store.StateFinished {
		v.Result = j.Result
	}
	return v
}

// piggybackView 摘要化条目：output_head 按 fallback 截断（设计文档 5.2）。
func (s *Server) piggybackItems(user string) []jobView {
	jobs := s.st.CollectPiggyback(user, s.cfg.PiggybackMaxItems)
	if len(jobs) == 0 {
		return nil
	}
	out := make([]jobView, 0, len(jobs))
	for _, j := range jobs {
		v := viewOfJob(j)
		if v.Result != nil {
			cp := *v.Result
			cp.OutputHead = truncateHead(cp.OutputHead, s.cfg.OutputHeadFallback)
			v.Result = &cp
		}
		out = append(out, v)
	}
	return out
}

func truncateHead(s string, n int) string {
	if len(s) <= n {
		return s
	}
	b := []byte(s)[:n]
	for len(b) > 0 {
		if r := b[len(b)-1]; r >= 0x80 {
			// 可能切断多字节字符，保守回退
			b = b[:len(b)-1]
			continue
		}
		break
	}
	return string(b)
}

// envelope 组装响应体，非 /status 接口附带 piggyback。
func (s *Server) envelope(user string, withPiggy bool, body map[string]any) map[string]any {
	if withPiggy {
		if items := s.piggybackItems(user); len(items) > 0 {
			body["piggyback"] = items
		}
	}
	return body
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.WriteHeader(code)
	enc := json.NewEncoder(w)
	enc.SetEscapeHTML(false)
	_ = enc.Encode(v)
}

func writeErr(w http.ResponseWriter, code int, msg string) {
	writeJSON(w, code, map[string]string{"error": msg})
}

// ---------- 严格百分号编码解析 ----------

// strictQuery 解析查询串，强制**仅接受百分号编码**（v4 需求「所有编码用%」）。
//
// 与 url.ParseQuery 的差异（后者过于宽松，会把非法输入静默"修好"）：
//   - 拒绝 '+' 作为空格：必须写 %20（调用方只需记一条规则，不存在歧义）
//   - 拒绝裸非 ASCII 字节：中文、emoji 等必须编码为 %XX%XX
//   - 拒绝非法转义：%ZZ、截断的 %A 一律 400，不做容错猜测
//   - 拒绝裸 %，以及路径穿越常用的裸 '\\'
//
// 这样保证「服务收到的字节 == 调用方编码后的字节」，参数值经解码后可原样使用。
//
// 注意：返回的 map 是**逐键解码**的。若同一 key 出现多次，前者保留、后者丢弃
// （与本服务的单值参数模型一致；不做 last-wins，避免歧义）。
func strictQuery(raw string) (url.Values, error) {
	vals := url.Values{}
	if raw == "" {
		return vals, nil
	}
	for _, pair := range strings.Split(raw, "&") {
		if pair == "" {
			continue
		}
		eq := strings.IndexByte(pair, '=')
		var kraw, vraw string
		if eq < 0 {
			kraw = pair // 无 '=' 的参数，视为空值
		} else {
			kraw, vraw = pair[:eq], pair[eq+1:]
		}

		k, err := strictUnescape(kraw)
		if err != nil {
			return nil, err
		}
		v, err := strictUnescape(vraw)
		if err != nil {
			return nil, err
		}
		if _, dup := vals[k]; !dup {
			vals[k] = append(vals[k], v)
		}
	}
	return vals, nil
}

// strictUnescape 对单个键或值做严格百分号解码。
func strictUnescape(s string) (string, error) {
	var b strings.Builder
	b.Grow(len(s))
	for i := 0; i < len(s); i++ {
		ch := s[i]
		switch {
		case ch == '+':
			// 明确拒绝：'%20' 才是空格。'+' 语义歧义（表单 vs 路径）易被绕过。
			return "", &badParam{400, "invalid argument"}
		case ch == '%':
			if i+2 >= len(s) {
				return "", &badParam{400, "invalid argument"}
			}
			h1, ok1 := hexVal(s[i+1])
			h2, ok2 := hexVal(s[i+2])
			if !ok1 || !ok2 {
				return "", &badParam{400, "invalid argument"}
			}
			b.WriteByte(h1<<4 | h2)
			i += 2
		case ch == '\\':
			// 反斜杠在网络层无合法用途，且是路径穿越的常见变体，直接拒绝。
			return "", &badParam{400, "invalid argument"}
		case ch >= 0x20 && ch < 0x7f:
			b.WriteByte(ch)
		default:
			// 裸非 ASCII 字节（含 UTF-8 多字节首字节）→ 必须编码
			return "", &badParam{400, "invalid argument"}
		}
	}
	return b.String(), nil
}

func hexVal(c byte) (byte, bool) {
	switch {
	case c >= '0' && c <= '9':
		return c - '0', true
	case c >= 'a' && c <= 'f':
		return c - 'a' + 10, true
	case c >= 'A' && c <= 'F':
		return c - 'A' + 10, true
	}
	return 0, false
}

// ---------- 参数解析与校验（设计文档 2.1） ----------

type badParam struct {
	code int
	msg  string
}

func (e *badParam) Error() string { return e.msg }

// parseUser 校验 user 格式与白名单。
func (s *Server) parseUser(q url.Values) (string, error) {
	user := q.Get("user")
	if user == "" {
		return "", &badParam{400, "invalid argument"}
	}
	if !s.userRe.MatchString(user) {
		return "", &badParam{400, "invalid argument"}
	}
	// 白名单：格式合法但不在名单 → 403
	if !s.cfg.IsUserAllowed(user) {
		return "", &badParam{403, "user not allowed"}
	}
	return user, nil
}

// parsePath 校验路径参数（非空字符串；逃逸判定在 executor.resolvePath）。
func parsePath(q url.Values, required bool) (string, error) {
	// 兼容别名 p：平台 WAF 会拦截部分查询参数名，服务侧统一接受多种写法。
	p := firstNonEmpty(q, "path", "p")
	if required && p == "" {
		return "", &badParam{400, "invalid argument"}
	}
	return p, nil
}

// parseJobID 解析 job_id：十进制整数，1 ≤ id ≤ 2^31-1。
func parseJobID(q url.Values) (int, error) {
	raw := q.Get("job_id")
	if raw == "" {
		return 0, &badParam{400, "invalid argument"}
	}
	n, err := strconv.ParseInt(raw, 10, 64)
	if err != nil || n < 1 || n > (1<<31-1) {
		return 0, &badParam{400, "invalid argument"}
	}
	return int(n), nil
}

// parseTimeout 解析 timeout：浮点秒，0 < timeout ≤ timeout_max_s。
func (s *Server) parseTimeout(q url.Values) (time.Duration, error) {
	// 兼容 timeout_s（设计文档惯用名）与 timeout 两种写法。
	raw := firstNonEmpty(q, "timeout_s", "timeout")
	if raw == "" {
		return 0, &badParam{400, "invalid argument"}
	}
	f, err := strconv.ParseFloat(raw, 64)
	if err != nil || f <= 0 || f > s.cfg.TimeoutMaxS {
		return 0, &badParam{400, "invalid argument"}
	}
	return time.Duration(f * float64(time.Second)), nil
}

// firstNonEmpty 返回若干候选中第一个非空值（用于参数别名）。
func firstNonEmpty(q url.Values, keys ...string) string {
	for _, k := range keys {
		if v := q.Get(k); v != "" {
			return v
		}
	}
	return ""
}

// validateCmd 校验 cmd 的百分号编码原文：
// 原文中含**未被编码为 %3D 的裸 =** → 400（设计文档 2.1）。
//
// 兼容别名：部分反向代理/WAF 会对名为 cmd 的查询参数做正则拦截，
// 因此同时接受 q / command 作为等价写法。语义完全一致。
func validateCmd(q url.Values) (string, error) {
	cmd := firstNonEmpty(q, "cmd", "q", "command")
	if cmd == "" {
		return "", &badParam{400, "invalid argument"}
	}
	return cmd, nil
}

// parseOffset / parseLimit
func parseOffset(q url.Values) (int64, error) {
	raw := q.Get("offset")
	if raw == "" {
		return 0, nil
	}
	n, err := strconv.ParseInt(raw, 10, 64)
	if err != nil || n < 0 {
		return 0, &badParam{400, "invalid argument"}
	}
	return n, nil
}

func parseLimit(q url.Values) (int64, error) {
	// limit 与 max_bytes 等价（后者为设计文档中的惯用名）。
	raw := firstNonEmpty(q, "max_bytes", "limit")
	if raw == "" {
		return 0, nil // 0 → 由 cat_max_bytes 决定
	}
	n, err := strconv.ParseInt(raw, 10, 64)
	if err != nil || n < 1 {
		return 0, &badParam{400, "invalid argument"}
	}
	return n, nil
}

// expectedParams 检查预期外参数 → 400。
func (s *Server) ensureParams(r *http.Request, allowed ...string) error {
	allow := map[string]bool{}
	for _, a := range allowed {
		allow[a] = true
	}
	for k := range queryOf(r) {
		if !allow[k] {
			return &badParam{400, "invalid argument"}
		}
	}
	return nil
}

// handleParamError 统一把参数错误写入响应。
func (s *Server) handleParamError(w http.ResponseWriter, err error) bool {
	if err == nil {
		return false
	}
	var bp *badParam
	if errors.As(err, &bp) {
		writeErr(w, bp.code, bp.msg)
		return true
	}
	writeErr(w, 400, "invalid argument")
	return true
}

// ---------- 接口实现 ----------

// handleExec GET /exec
func (s *Server) handleExec(w http.ResponseWriter, r *http.Request) {
	q := queryOf(r)
	if err := s.ensureParams(r, "user", "cmd", "q", "command", "timeout", "timeout_s"); err != nil {
		s.handleParamError(w, err)
		return
	}
	user, err := s.parseUser(q)
	if s.handleParamError(w, err) {
		return
	}
	cmd, err := validateCmd(q)
	if s.handleParamError(w, err) {
		return
	}
	timeout, err := s.parseTimeout(q)
	if s.handleParamError(w, err) {
		return
	}

	// 并发上限：该 user 已有容器但 pending 数达上限 → 429（设计文档 2.4）
	if s.st.CurrentGeneration(user) != 0 && s.st.PendingCount(user) >= s.cfg.PerUserMaxJobs {
		writeErr(w, 429, "too many jobs")
		return
	}

	start, err := s.ex.Start(r.Context(), executor.ExecRequest{
		User: user, Cmd: cmd, Timeout: timeout,
	})
	if err != nil {
		if errors.Is(err, executor.ErrNoCapacity) {
			// 该 user 无运行中容器且全局达上限 → 503
			writeErr(w, 503, "no capacity")
			return
		}
		if errors.Is(err, executor.ErrDiskQuota) {
			// 磁盘预算已满 → 507（与 /write 同语义）
			writeErr(w, 507, "disk quota exceeded")
			return
		}
		writeErr(w, 500, "internal error")
		return
	}

	// 同步等待至多 exec_sync_wait_s（含冷启动）
	select {
	case <-start.Done:
		// 已完成：与 /status 同构返回
		job, _ := s.st.Lookup(user, start.Job.JobID)
		if job == nil {
			writeErr(w, 500, "internal error")
			return
		}
		s.st.MarkReadDirect(job)
		writeJSON(w, 200, s.envelope(user, true, mustObj(viewOfJob(job))))
	case <-time.After(time.Duration(s.cfg.ExecSyncWaitS * float64(time.Second))):
		// 未完：正常路径，返回 pending
		writeJSON(w, 200, s.envelope(user, true, mustObj(jobView{
			State: store.StatePending, JobID: start.Job.JobID,
		})))
	case <-r.Context().Done():
		// 客户端断开：job 继续在后台运行，不返回响应
		return
	}
}

// handleStatus GET /status（**不附加 piggyback**）
func (s *Server) handleStatus(w http.ResponseWriter, r *http.Request) {
	q := queryOf(r)
	if err := s.ensureParams(r, "user", "job_id"); err != nil {
		s.handleParamError(w, err)
		return
	}
	user, err := s.parseUser(q)
	if s.handleParamError(w, err) {
		return
	}
	jobID, err := parseJobID(q)
	if s.handleParamError(w, err) {
		return
	}

	job, tomb := s.st.Lookup(user, jobID)
	if tomb != nil {
		// 墓碑：200 + recycled
		writeJSON(w, 200, jobView{
			State: store.StateRecycled, JobID: jobID, Error: "container recycled",
		})
		return
	}
	if job == nil {
		writeErr(w, 404, "not found")
		return
	}

	// 经 /status 读取后标记已读取（不再进 piggyback）
	s.st.MarkReadDirect(job)
	writeJSON(w, 200, viewOfJob(job))
}

// handleCat GET /cat
func (s *Server) handleCat(w http.ResponseWriter, r *http.Request) {
	q := queryOf(r)
	if err := s.ensureParams(r, "user", "path", "p", "offset", "limit", "max_bytes"); err != nil {
		s.handleParamError(w, err)
		return
	}
	user, err := s.parseUser(q)
	if s.handleParamError(w, err) {
		return
	}
	path, err := parsePath(q, true)
	if s.handleParamError(w, err) {
		return
	}
	offset, err := parseOffset(q)
	if s.handleParamError(w, err) {
		return
	}
	limit, err := parseLimit(q)
	if s.handleParamError(w, err) {
		return
	}

	res, err := s.ex.Cat(r.Context(), user, path, offset, limit)
	if err != nil {
		if errors.Is(err, executor.ErrInvalidArgument) {
			writeErr(w, 400, "invalid argument")
			return
		}
		if errors.Is(err, os.ErrNotExist) {
			writeErr(w, 404, "not found")
			return
		}
		writeErr(w, 500, "internal error")
		return
	}

	// 二进制命中
	if res.Binary {
		if res.IsOutputFile {
			// 读输出文件：返回该 job 的结果结构（读取期判定，不回写 job 状态）
			code := 0
			body := jobView{
				State: store.StateFinished,
				JobID: res.JobID,
				Result: &store.Result{
					Outcome:    store.OutcomeUnusable,
					ExitCode:   &code,
					Signal:     nil,
					OutputHead: "",
					OutputFile: "tmp/" + store.OutputFileName(res.JobID),
					Error:      store.ErrBinaryOutput,
					Truncated:  false,
				},
				Note: "binary detected at read time; job result unchanged",
			}
			writeJSON(w, 200, s.envelope(user, true, mustObj(body)))
			return
		}
		// 读用户文件：无 job 可归属 → ok:false
		writeJSON(w, 200, s.envelope(user, true, map[string]any{
			"ok": false, "error": "binary output",
		}))
		return
	}

	writeJSON(w, 200, s.envelope(user, true, map[string]any{
		"ok":       true,
		"content":  res.Content,
		"has_more": res.HasMore,
		"size":     res.Size,
	}))
}

// handleWrite GET /write
func (s *Server) handleWrite(w http.ResponseWriter, r *http.Request) {
	q := queryOf(r)
	if err := s.ensureParams(r, "user", "path", "p", "content", "text", "d"); err != nil {
		s.handleParamError(w, err)
		return
	}
	user, err := s.parseUser(q)
	if s.handleParamError(w, err) {
		return
	}
	path, err := parsePath(q, true)
	if s.handleParamError(w, err) {
		return
	}
	content := []byte(firstNonEmpty(q, "content", "text", "d"))
	if len(content) > s.cfg.ContentMaxBytes {
		writeErr(w, 413, "content too large")
		return
	}

	if err := s.ex.Write(r.Context(), user, path, content); err != nil {
		switch {
		case errors.Is(err, executor.ErrInvalidArgument):
			writeErr(w, 400, "invalid argument")
		case errors.Is(err, executor.ErrIsDirectory):
			writeErr(w, 409, "target is a directory")
		case errors.Is(err, os.ErrNotExist):
			writeErr(w, 404, "not found")
		case errors.Is(err, executor.ErrDiskQuota):
			writeErr(w, 507, "disk quota exceeded")
		default:
			writeErr(w, 500, "internal error")
		}
		return
	}
	writeJSON(w, 200, s.envelope(user, true, map[string]any{
		"ok": true, "path": path,
	}))
}

// handleLs GET /ls
func (s *Server) handleLs(w http.ResponseWriter, r *http.Request) {
	q := queryOf(r)
	if err := s.ensureParams(r, "user", "path", "p"); err != nil {
		s.handleParamError(w, err)
		return
	}
	user, err := s.parseUser(q)
	if s.handleParamError(w, err) {
		return
	}
	path, err := parsePath(q, false)
	if s.handleParamError(w, err) {
		return
	}

	dirs, files, err := s.ex.Ls(r.Context(), user, path)
	if err != nil {
		if errors.Is(err, executor.ErrInvalidArgument) {
			writeErr(w, 400, "invalid argument")
			return
		}
		if errors.Is(err, os.ErrNotExist) {
			writeErr(w, 404, "not found")
			return
		}
		writeErr(w, 500, "internal error")
		return
	}
	writeJSON(w, 200, s.envelope(user, true, map[string]any{
		"ok": true, "dir": dirs, "file": files,
	}))
}

func (s *Server) handleHealth(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, 200, map[string]any{
		"ok":     true,
		"docker": s.ex.DockerAvailable(),
	})
}

func mustObj(v any) map[string]any {
	b, _ := json.Marshal(v)
	var m map[string]any
	_ = json.Unmarshal(b, &m)
	return m
}

var _ = context.Background
var _ = fmt.Sprintf
var _ = log.Printf
var _ = strings.TrimSpace
