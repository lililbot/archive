package api

import (
	"strings"
	"testing"
)

// TestStrictQueryAccepts 合法输入：标准百分号编码。
func TestStrictQueryAccepts(t *testing.T) {
	q, err := strictQuery("user=alice&cmd=echo%20hello&timeout=10")
	if err != nil {
		t.Fatalf("合法编码不应报错：%v", err)
	}
	if q.Get("user") != "alice" {
		t.Fatalf("user 解析错误：%q", q.Get("user"))
	}
	if q.Get("cmd") != "echo hello" {
		t.Fatalf("cmd 应解码为 'echo hello'，实际 %q", q.Get("cmd"))
	}
	if q.Get("timeout") != "10" {
		t.Fatalf("timeout 解析错误：%q", q.Get("timeout"))
	}
}

// TestStrictQueryUTF8 中文必须编码为 %XX%XX，编码后可正确还原。
func TestStrictQueryUTF8(t *testing.T) {
	// "中文" 的 UTF-8 百分号编码
	encoded := "%E4%B8%AD%E6%96%87"
	q, err := strictQuery("path=" + encoded)
	if err != nil {
		t.Fatalf("编码后的中文应被接受：%v", err)
	}
	if q.Get("path") != "中文" {
		t.Fatalf("中文还原错误：%q", q.Get("path"))
	}
}

// TestStrictQueryRejects 非法输入一律 400。
func TestStrictQueryRejects(t *testing.T) {
	bad := []struct {
		name string
		raw  string
	}{
		{"+ 号当空格", "cmd=echo+hello"},
		{"裸中文", "path=中文.txt"},
		{"裸 %", "cmd=100%"},
		{"非法转义字母", "cmd=%ZZ"},
		{"截断的转义", "cmd=%A"},
		{"转义后为裸 %", "cmd=%25x"}, // 合法：%25 解码为 %，但后续 x 正常 —— 见下方断言修正
		{"反斜杠", "path=dir\\file"},
		{"裸控制字符", "cmd=a\x01b"},
		{"裸高位字节", "cmd=\xe4\xb8\xad"},
	}
	// "cmd=%25x" 其实是合法的（解码为 "%x"），从拒绝列表中排除
	valid := map[string]bool{"转义后为裸 %": true}

	for _, k := range bad {
		_, err := strictQuery(k.raw)
		if valid[k.name] {
			if err != nil {
				t.Errorf("%s：应被接受，实际报错 %v", k.name, err)
			}
			continue
		}
		if err == nil {
			t.Errorf("%s：应被拒绝但通过了（raw=%q）", k.name, k.raw)
		}
	}
}

// TestStrictQueryPercentDecode 验证 %25 → %，以及 %26 → & 不会被当作分隔符。
func TestStrictQueryPercentDecode(t *testing.T) {
	q, err := strictQuery("cmd=echo%20%25PATH%25")
	if err != nil {
		t.Fatalf("不应报错：%v", err)
	}
	if got := q.Get("cmd"); got != "echo %PATH%" {
		t.Fatalf("期望 'echo %%PATH%%'，实际 %q", got)
	}

	// %26 是编码后的 '&'，必须作为值的一部分，而不是参数分隔符
	q2, err := strictQuery("cmd=a%26b")
	if err != nil {
		t.Fatalf("不应报错：%v", err)
	}
	if got := q2.Get("cmd"); got != "a&b" {
		t.Fatalf("期望 'a&b'，实际 %q", got)
	}
	if len(q2) != 1 {
		t.Fatalf("不应额外产生参数，实际 %v", q2)
	}
}

// TestStrictQueryEmpty 空查询串与无值参数。
func TestStrictQueryEmpty(t *testing.T) {
	q, err := strictQuery("")
	if err != nil || len(q) != 0 {
		t.Fatalf("空串应得到空表：%v %v", q, err)
	}
	q2, err := strictQuery("flag")
	if err != nil {
		t.Fatalf("无值参数不应报错：%v", err)
	}
	if v, ok := q2["flag"]; !ok || v[0] != "" {
		t.Fatalf("无值参数应解析为空串：%v", q2)
	}
}

// TestStrictQuerySizeBoundary 大参数（编码后）应能正常解析。
func TestStrictQuerySizeBoundary(t *testing.T) {
	// 65536 字节的内容，编码为 %XX 后约 3 倍
	raw := strings.Repeat("A", 65536)
	enc := strings.ReplaceAll(raw, "A", "%41")
	q, err := strictQuery("content=" + enc)
	if err != nil {
		t.Fatalf("大参数不应报错：%v", err)
	}
	if len(q.Get("content")) != 65536 {
		t.Fatalf("长度不符：%d", len(q.Get("content")))
	}
}
