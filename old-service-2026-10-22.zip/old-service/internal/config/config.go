package config

import (
	"fmt"
	"net"
	"os"
	"strconv"
	"strings"
)

// Config 对应《工程文档》第 8 节的全部配置项。
//
// v4 调整（新需求）：可信环境无需鉴权、调用方仅 GET、资源 4G内存/16G磁盘/双核。
type Config struct {
	// 容器
	ContainerCPU     int // container_cpu
	ContainerMemMB   int // container_memory_mb
	OutputTmpQuotaMB int // output_tmp_quota_mb（单次输出上限，非磁盘配额）
	// 用户
	UserDiskMB     int // user_disk_mb：/home/user + /tmp 的合计磁盘预算
	PerUserMaxJobs int // per_user_max_jobs
	// 服务
	ContainerTotalLimit            int      // container_total_limit, 0 = 不限
	UserAllowlist                  []string // user_allowlist, 空表 = 拒绝所有
	ExecSyncWaitS                  float64  // exec_sync_wait_s
	TimeoutMaxS                    float64  // timeout_max_s
	ContentMaxBytes                int      // content_max_bytes
	OutputHeadBytes                int      // output_head_bytes
	OutputHeadFallback             int      // output_head_bytes_fallback
	BinaryCheckWindow              int      // binary_check_window
	BinaryInvalidRatio             float64  // binary_invalid_ratio
	CatMaxBytes                    int64    // cat_max_bytes, 0 = 不限
	PiggybackMaxItems              int      // piggyback_max_items
	PiggybackUndeliveredRetentionS int      // piggyback_undelivered_retention_s
	GCIdleContainerS               int      // gc_idle_container_s
	GCJobRetentionS                int      // gc_job_retention_s
	GCTombstoneRetentionS          int      // gc_tombstone_retention_s
	GCJobRecordLimit               int      // gc_job_record_limit（墓碑不计入）
	GCScanIntervalS                int      // gc_scan_interval_s

	// 运行时
	ListenAddr     string
	BaseImage      string
	HomeVolumeRoot string // 每用户 /home/user 持久卷的宿主机根目录
	DockerNetwork  string

	// v4：容器出站管控（禁内网/元数据，公网自由）
	//
	// 实现方式：为每个用户分配一个 /30 独占子网，服务在**宿主机侧**建立
	// FORWARD 链按源网段拒绝私网与元数据地址。
	// 这样容器**不需要** NET_ADMIN，规则也不在容器内（无法被自身移除）。
	EgressSubnetBase  string   // 形如 172.20.0.0/16，服务在其上切分 /30
	EgressBlockCIDRs  []string // 要拒绝的目标网段/地址
	EgressEnforceHost bool     // 置 false 可关闭宿主侧规则下发（无 iptables 权限的环境）
	EgressDNS         []string // 容器内 DNS 服务器；空则继承宿主 /etc/resolv.conf
	ApkMirror         string   // 容器内 /etc/apk/repositories 的镜像源主机
}

// Default 返回文档规定的全部默认值。
//
// v4 关键变化（对齐新需求「资源限制:4G内存/16G磁盘/双核」）：
//   - ContainerMemMB: 1024 → 4096
//   - UserDiskMB:     1024 → 16384（且覆盖 /exec，见 executor.EnforceDiskQuota）
//   - OutputTmpQuotaMB: 256 → 1024（单次输出上限；/tmp 已是 bind mount，
//     不再占用容器内存，因此无需再受 container_memory_mb 约束）
//   - DockerNetwork:  none → bridge（容器需自行联网装包）
func Default() *Config {
	return &Config{
		ContainerCPU:     2,
		ContainerMemMB:   4096,
		OutputTmpQuotaMB: 1024,

		UserDiskMB:     16384,
		PerUserMaxJobs: 64,

		ContainerTotalLimit:            0,
		UserAllowlist:                  []string{},
		ExecSyncWaitS:                  10,
		TimeoutMaxS:                    300, // 取值沿用 v3 文档
		ContentMaxBytes:                65536,
		OutputHeadBytes:                2048,
		OutputHeadFallback:             512,
		BinaryCheckWindow:              8192,
		BinaryInvalidRatio:             0.3,
		CatMaxBytes:                    1048576, // 取值沿用 v3 文档
		PiggybackMaxItems:              20,
		PiggybackUndeliveredRetentionS: 3600,

		GCIdleContainerS:      1800,
		GCJobRetentionS:       600,
		GCTombstoneRetentionS: 600,
		GCJobRecordLimit:      1000,
		GCScanIntervalS:       60,

		ListenAddr:     "0.0.0.0:8080",
		BaseImage:      "alpine:3.19",
		HomeVolumeRoot: "/var/lib/sandbox-exec/home",
		DockerNetwork:  "sandbox-egress",

		// 每用户独占 /30（4 个地址：网络号、网关、容器、广播）。
		// /16 可容纳 16384 个用户段，足够。
		EgressSubnetBase: "172.20.0.0/16",
		EgressBlockCIDRs: []string{
			"127.0.0.0/8",        // 回环
			"10.0.0.0/8",         // 私网 A
			"172.16.0.0/12",      // 私网 B（含 Docker 默认 bridge 172.17/16）
			"192.168.0.0/16",     // 私网 C
			"169.254.0.0/16",     // 链路本地 + 云元数据 169.254.169.254
			"100.64.0.0/10",      // CGNAT（部分云内网在用）
			"100.100.100.200/32", // 阿里云元数据服务
		},
		EgressEnforceHost: true,
		ApkMirror:         "mirrors.aliyun.com",
	}
}

// Load 从环境变量覆盖默认值（SBX_ 前缀），再做config.md 的启动校验。
func Load() (*Config, error) {
	c := Default()

	envInt("SBX_CONTAINER_CPU", &c.ContainerCPU)
	envInt("SBX_CONTAINER_MEMORY_MB", &c.ContainerMemMB)
	envInt("SBX_OUTPUT_TMP_QUOTA_MB", &c.OutputTmpQuotaMB)
	envInt("SBX_USER_DISK_MB", &c.UserDiskMB)
	envInt("SBX_PER_USER_MAX_JOBS", &c.PerUserMaxJobs)
	envInt("SBX_CONTAINER_TOTAL_LIMIT", &c.ContainerTotalLimit)
	envFloat("SBX_EXEC_SYNC_WAIT_S", &c.ExecSyncWaitS)
	envFloat("SBX_TIMEOUT_MAX_S", &c.TimeoutMaxS)
	envInt("SBX_CONTENT_MAX_BYTES", &c.ContentMaxBytes)
	envInt("SBX_OUTPUT_HEAD_BYTES", &c.OutputHeadBytes)
	envInt("SBX_OUTPUT_HEAD_BYTES_FALLBACK", &c.OutputHeadFallback)
	envInt("SBX_BINARY_CHECK_WINDOW", &c.BinaryCheckWindow)
	envFloat("SBX_BINARY_INVALID_RATIO", &c.BinaryInvalidRatio)
	envInt64("SBX_CAT_MAX_BYTES", &c.CatMaxBytes)
	envInt("SBX_PIGGYBACK_MAX_ITEMS", &c.PiggybackMaxItems)
	envInt("SBX_PIGGYBACK_UNDELIVERED_RETENTION_S", &c.PiggybackUndeliveredRetentionS)
	envInt("SBX_GC_IDLE_CONTAINER_S", &c.GCIdleContainerS)
	envInt("SBX_GC_JOB_RETENTION_S", &c.GCJobRetentionS)
	envInt("SBX_GC_TOMBSTONE_RETENTION_S", &c.GCTombstoneRetentionS)
	envInt("SBX_GC_JOB_RECORD_LIMIT", &c.GCJobRecordLimit)
	envInt("SBX_GC_SCAN_INTERVAL_S", &c.GCScanIntervalS)

	envStr("SBX_LISTEN_ADDR", &c.ListenAddr)
	envStr("SBX_BASE_IMAGE", &c.BaseImage)
	envStr("SBX_HOME_VOLUME_ROOT", &c.HomeVolumeRoot)
	envStr("SBX_DOCKER_NETWORK", &c.DockerNetwork)
	envStr("SBX_EGRESS_SUBNET_BASE", &c.EgressSubnetBase)
	envStr("SBX_APK_MIRROR", &c.ApkMirror)
	envBool("SBX_EGRESS_ENFORCE_HOST", &c.EgressEnforceHost)
	if v := os.Getenv("SBX_EGRESS_BLOCK_CIDRS"); v != "" {
		c.EgressBlockCIDRs = splitComma(v)
	}

	// PORT 支持：平台注入 PORT 时优先采用，并绑定 0.0.0.0（反代可达）。
	// 显式设置的 SBX_LISTEN_ADDR 优先于 PORT。
	if os.Getenv("SBX_LISTEN_ADDR") == "" {
		if p := os.Getenv("PORT"); p != "" {
			c.ListenAddr = "0.0.0.0:" + p
		}
	}

	// SBX_USER_ALLOWLIST：逗号分隔
	if v := os.Getenv("SBX_USER_ALLOWLIST"); v != "" {
		c.UserAllowlist = splitComma(v)
	}

	if err := c.Validate(); err != nil {
		return nil, err
	}
	return c, nil
}

// Validate 实现config.md 的启动校验，不满足则启动失败。
func (c *Config) Validate() error {
	type rule struct {
		ok  bool
		msg string
	}
	rules := []rule{
		// v4 修订：原规则「output_tmp_quota_mb < container_memory_mb」的前提是
		// /tmp 为 tmpfs（占用容器内存）。落地时 /tmp 已改为宿主机 bind mount
		// （Docker archive API 无法读取 tmpfs，会导致输出取不回），
		// 因此该约束不再成立。改为约束**输出配额不得吃掉用户磁盘预算**：
		// 单次输出上限必须显著小于磁盘总量，否则一次命令即可撑满 16G。
		{c.OutputTmpQuotaMB < c.UserDiskMB,
			fmt.Sprintf("output_tmp_quota_mb(%d) 必须 < user_disk_mb(%d)：单次输出上限不得吃掉全部磁盘预算",
				c.OutputTmpQuotaMB, c.UserDiskMB)},
		{c.PiggybackUndeliveredRetentionS >= c.GCJobRetentionS,
			fmt.Sprintf("piggyback_undelivered_retention_s(%d) 必须 >= gc_job_retention_s(%d)：未投递记录窗口不得短于已投递窗口",
				c.PiggybackUndeliveredRetentionS, c.GCJobRetentionS)},
		{c.TimeoutMaxS >= c.ExecSyncWaitS,
			fmt.Sprintf("timeout_max_s(%v) 必须 >= exec_sync_wait_s(%v)：否则同步路径永远等不到最长命令",
				c.TimeoutMaxS, c.ExecSyncWaitS)},
		{c.OutputHeadBytes >= c.OutputHeadFallback,
			fmt.Sprintf("output_head_bytes(%d) 必须 >= output_head_bytes_fallback(%d)：摘要长度阶梯不得倒挂",
				c.OutputHeadBytes, c.OutputHeadFallback)},
		{c.PiggybackMaxItems >= 1,
			fmt.Sprintf("piggyback_max_items(%d) 必须 >= 1：投递上限不得为 0，否则 piggyback 永不生效", c.PiggybackMaxItems)},
		{c.BinaryCheckWindow >= 1,
			fmt.Sprintf("binary_check_window(%d) 必须 >= 1：窗口非空", c.BinaryCheckWindow)},
		{c.BinaryInvalidRatio > 0 && c.BinaryInvalidRatio < 1,
			fmt.Sprintf("binary_invalid_ratio(%v) 必须落在 (0,1)：占比阈值须为有效比例", c.BinaryInvalidRatio)},
		{c.ContainerCPU >= 1,
			fmt.Sprintf("container_cpu(%d) 必须 >= 1", c.ContainerCPU)},
		{c.ContainerMemMB >= 64,
			fmt.Sprintf("container_memory_mb(%d) 必须 >= 64", c.ContainerMemMB)},
		{c.UserDiskMB >= 1,
			fmt.Sprintf("user_disk_mb(%d) 必须 >= 1", c.UserDiskMB)},
		{c.ContentMaxBytes >= 1,
			fmt.Sprintf("content_max_bytes(%d) 必须 >= 1", c.ContentMaxBytes)},
		{c.CatMaxBytes >= 0,
			fmt.Sprintf("cat_max_bytes(%d) 必须 >= 0", c.CatMaxBytes)},
		{c.GCScanIntervalS >= 1,
			fmt.Sprintf("gc_scan_interval_s(%d) 必须 >= 1", c.GCScanIntervalS)},
		{EgressSubnetOK(c.EgressSubnetBase),
			fmt.Sprintf("egress_subnet_base(%q) 必须是合法的 IPv4 CIDR 且掩码 <= /24：每用户需要 4 个地址的 /30",
				c.EgressSubnetBase)},
		{!c.EgressEnforceHost || len(c.EgressBlockCIDRs) > 0,
			"egress_enforce_host 为真时 egress_block_cidrs 不得为空：否则等于未做任何出站管控"},
	}
	for _, r := range rules {
		if !r.ok {
			return fmt.Errorf("配置校验失败：%s", r.msg)
		}
	}
	return nil
}

// IsUserAllowed 白名单判定（用户名校验先于本函数，见 api 层）。
func (c *Config) IsUserAllowed(u string) bool {
	for _, a := range c.UserAllowlist {
		if a == u {
			return true
		}
	}
	return false
}

// EgressSubnetOK 校验出站子网基数：必须是 IPv4 CIDR，且掩码不长于 /24
// （至少要能给用户切出若干个 /30，否则立刻耗尽）。
func EgressSubnetOK(s string) bool {
	ip, ipnet, err := net.ParseCIDR(s)
	if err != nil || ip.To4() == nil {
		return false
	}
	ones, _ := ipnet.Mask.Size()
	return ones >= 8 && ones <= 24
}

func envStr(key string, dst *string) {
	if v := os.Getenv(key); v != "" {
		*dst = v
	}
}

func envBool(key string, dst *bool) {
	if v := os.Getenv(key); v != "" {
		switch strings.ToLower(v) {
		case "1", "true", "yes", "on":
			*dst = true
		case "0", "false", "no", "off":
			*dst = false
		}
	}
}

func envInt(key string, dst *int) {
	if v := os.Getenv(key); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			*dst = n
		}
	}
}

func envInt64(key string, dst *int64) {
	if v := os.Getenv(key); v != "" {
		if n, err := strconv.ParseInt(v, 10, 64); err == nil {
			*dst = n
		}
	}
}

func envFloat(key string, dst *float64) {
	if v := os.Getenv(key); v != "" {
		if f, err := strconv.ParseFloat(v, 64); err == nil {
			*dst = f
		}
	}
}

func splitComma(s string) []string {
	var out []string
	cur := ""
	for _, r := range s {
		if r == ',' {
			if cur != "" {
				out = append(out, cur)
			}
			cur = ""
			continue
		}
		cur += string(r)
	}
	if cur != "" {
		out = append(out, cur)
	}
	return out
}
