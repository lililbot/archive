package config

import (
	"strings"
	"testing"
)

// TestDefaultsMatchDoc 校验默认值与文档第 8 节一致（含 v4 的资源调整）。
func TestDefaultsMatchDoc(t *testing.T) {
	c := Default()
	checks := []struct {
		name string
		got  any
		want any
	}{
		{"container_cpu", c.ContainerCPU, 2},
		// v4：4G 内存 / 16G 磁盘 / 双核
		{"container_memory_mb", c.ContainerMemMB, 4096},
		{"output_tmp_quota_mb", c.OutputTmpQuotaMB, 1024},
		{"user_disk_mb", c.UserDiskMB, 16384},
		{"docker_network", c.DockerNetwork, "sandbox-egress"},
		{"egress_subnet_base", c.EgressSubnetBase, "172.20.0.0/16"},
		{"egress_enforce_host", c.EgressEnforceHost, true},
		{"apk_mirror", c.ApkMirror, "mirrors.aliyun.com"},
		{"per_user_max_jobs", c.PerUserMaxJobs, 64},
		{"container_total_limit", c.ContainerTotalLimit, 0},
		{"exec_sync_wait_s", c.ExecSyncWaitS, float64(10)},
		{"timeout_max_s", c.TimeoutMaxS, float64(300)}, // v3：默认 300
		{"content_max_bytes", c.ContentMaxBytes, 65536},
		{"output_head_bytes", c.OutputHeadBytes, 2048},
		{"output_head_bytes_fallback", c.OutputHeadFallback, 512},
		{"binary_check_window", c.BinaryCheckWindow, 8192},
		{"binary_invalid_ratio", c.BinaryInvalidRatio, 0.3},
		{"cat_max_bytes", c.CatMaxBytes, int64(1048576)}, // v3：默认 1MB
		{"piggyback_max_items", c.PiggybackMaxItems, 20},
		{"piggyback_undelivered_retention_s", c.PiggybackUndeliveredRetentionS, 3600},
		{"gc_idle_container_s", c.GCIdleContainerS, 1800},
		{"gc_job_retention_s", c.GCJobRetentionS, 600},
		{"gc_tombstone_retention_s", c.GCTombstoneRetentionS, 600},
		{"gc_job_record_limit", c.GCJobRecordLimit, 1000},
		{"gc_scan_interval_s", c.GCScanIntervalS, 60},
	}
	for _, k := range checks {
		if k.got != k.want {
			t.Errorf("%s: 期望 %v，实际 %v", k.name, k.want, k.got)
		}
	}
	if err := c.Validate(); err != nil {
		t.Fatalf("默认配置应通过校验：%v", err)
	}
}

// TestValidateRules 校验config.md 的启动校验规则。
func TestValidateRules(t *testing.T) {
	cases := []struct {
		name   string
		mutate func(*Config)
		expect string // 期望错误信息包含的关键字
	}{
		{"单次输出上限不得吃掉磁盘预算", func(c *Config) { c.OutputTmpQuotaMB = c.UserDiskMB }, "user_disk_mb"},
		{"未投递窗口不得短于已投递窗口", func(c *Config) { c.PiggybackUndeliveredRetentionS = 1 }, "gc_job_retention_s"},
		{"timeout 上限不得小于同步等待", func(c *Config) { c.TimeoutMaxS = 1 }, "exec_sync_wait_s"},
		{"摘要长度阶梯不得倒挂", func(c *Config) { c.OutputHeadBytes = 1; c.OutputHeadFallback = 999 }, "output_head_bytes_fallback"},
		{"piggyback 上限不得为 0", func(c *Config) { c.PiggybackMaxItems = 0 }, "piggyback_max_items"},
		{"判定窗口非空", func(c *Config) { c.BinaryCheckWindow = 0 }, "binary_check_window"},
		{"占比阈值须为有效比例(上界)", func(c *Config) { c.BinaryInvalidRatio = 1 }, "binary_invalid_ratio"},
		{"占比阈值须为有效比例(下界)", func(c *Config) { c.BinaryInvalidRatio = 0 }, "binary_invalid_ratio"},
		{"CPU 下界", func(c *Config) { c.ContainerCPU = 0 }, "container_cpu"},
		{"内存下界", func(c *Config) { c.ContainerMemMB = 8 }, "container_memory_mb"},
		{"磁盘下界", func(c *Config) { c.UserDiskMB = 0 }, "user_disk_mb"},
	}
	for _, k := range cases {
		c := Default()
		k.mutate(c)
		err := c.Validate()
		if err == nil {
			t.Errorf("%s：应校验失败但通过了", k.name)
			continue
		}
		if !strings.Contains(err.Error(), k.expect) {
			t.Errorf("%s：错误信息应含 %q，实际 %v", k.name, k.expect, err)
		}
	}
}

// TestIsUserAllowed 校验白名单语义：空表拒绝所有。
func TestIsUserAllowed(t *testing.T) {
	c := Default()
	if c.IsUserAllowed("alice") {
		t.Fatal("空白名单应拒绝所有 user")
	}
	c.UserAllowlist = []string{"alice", "bob"}
	if !c.IsUserAllowed("alice") || c.IsUserAllowed("mallory") {
		t.Fatal("白名单判定错误")
	}
	// 大小写敏感
	if c.IsUserAllowed("Alice") {
		t.Fatal("user 判定应大小写敏感")
	}
}

// TestSplitComma 校验白名单解析。
func TestSplitComma(t *testing.T) {
	got := splitComma("a,b,c")
	if len(got) != 3 || got[0] != "a" || got[2] != "c" {
		t.Fatalf("解析错误：%v", got)
	}
	if len(splitComma("")) != 0 {
		t.Fatal("空串应得到空列表")
	}
	if len(splitComma("a,,b")) != 2 {
		t.Fatal("空项应被忽略")
	}
}
