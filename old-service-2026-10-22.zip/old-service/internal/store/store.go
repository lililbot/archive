package store

import (
	"crypto/rand"
	"encoding/hex"
	"sort"
	"sync"
	"time"
)

// ---------- 状态枚举（设计文档 3.1） ----------

// State 任务状态：仅描述调度生命周期。
type State string

const (
	StatePending  State = "pending"  // 已受理，尚未产生终态结果
	StateFinished State = "finished" // 已产生终态结果，见 result
	StateRecycled State = "recycled" // 容器回收导致任务被终止，结果永久不可用
)

// Outcome 结果可用性（仅 State=finished 时存在）。
type Outcome string

const (
	OutcomeOK       Outcome = "ok"       // 进程正常结束（退出码任意）
	OutcomeUnusable Outcome = "unusable" // 结果不可用
)

// Unusable 原因枚举，共 3 种（设计文档 3.1）。
const (
	ErrTimeout        = "timeout"               // 进程运行超 timeout，服务主动终止
	ErrBinaryOutput   = "binary output"         // 二进制判定命中
	ErrOutputQuotaExc = "output quota exceeded" // /tmp 总配额已满，无法创建输出文件
)

// Result 结果对象。字段"必有"，值不可用时为 null（设计文档 3.1）。
type Result struct {
	Outcome    Outcome `json:"outcome"`
	ExitCode   *int    `json:"exit_code"`   // 必有，可为 null
	Signal     *string `json:"signal"`      // 必有，可为 null
	OutputHead string  `json:"output_head"` // 必有，为 output_file 的前缀
	OutputFile string  `json:"output_file"` // 必有，tmp/.out_<jobid>
	Error      string  `json:"error,omitempty"`
	Truncated  bool    `json:"truncated"`
}

// ---------- 内部记录 ----------

// Job 一条 job 记录。以 (user, generation, job_id) 标识。
type Job struct {
	User       string
	Generation int
	JobID      int

	State  State
	Result *Result

	// 已读取：经 /status 或 piggyback 投递过；/exec 同步返回也视为已读取
	Read bool

	// 终态时间（用于 GC 计龄）
	FinishedAt time.Time
	CreatedAt  time.Time

	// 是否有输出文件（场景 B 无文件）
	HasOutputFile bool

	// 进程句柄等运行时信息，由 executor 填充，store 不解释
	Runtime any
}

// Tombstone 墓碑：容器回收时为未达终态的 job 写入（设计文档 6.3）。
type Tombstone struct {
	User       string
	Generation int
	JobID      int
	CreatedAt  time.Time
}

// userState 一个用户的全部状态。
//
// 不变量（设计文档 6.3）：
//   - 墓碑始终绑定其 generation，且仅存在于"该代次已回收、新代次尚未启动"的窗口内。
//   - 新代次启动时，该 user 的历史墓碑立即失效并删除。
//   - 因此同一个 job_id 不可能同时命中墓碑与活跃记录。
type userState struct {
	mu sync.Mutex

	generation int // 当前代次；0 表示尚无容器

	jobs      map[int]*Job       // 当前代次活跃记录
	tombstone map[int]*Tombstone // 仅当 generation 对应容器已回收时存在
}

// Store 全局状态容器。
type Store struct {
	mu    sync.RWMutex
	users map[string]*userState
}

func New() *Store {
	return &Store{users: make(map[string]*userState)}
}

func (s *Store) user(user string) *userState {
	s.mu.RLock()
	us, ok := s.users[user]
	s.mu.RUnlock()
	if ok {
		return us
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if us, ok = s.users[user]; ok {
		return us
	}
	us = &userState{jobs: make(map[int]*Job), tombstone: make(map[int]*Tombstone)}
	s.users[user] = us
	return us
}

// ---------- 代次管理 ----------

// StartGeneration 启动新容器代次：generation 递增、清空活跃记录、
// 并**立即失效删除该 user 的全部历史墓碑**（设计文档 6.3 关键规则）。
// 返回新代次与本次分配的 job_id 起点（恒为 1）。
func (s *Store) StartGeneration(user string) int {
	us := s.user(user)
	us.mu.Lock()
	defer us.mu.Unlock()
	us.generation++
	us.jobs = make(map[int]*Job)
	us.tombstone = make(map[int]*Tombstone) // 历史墓碑立即失效
	return us.generation
}

// CurrentGeneration 返回当前代次（0 表示尚未启动容器）。
func (s *Store) CurrentGeneration(user string) int {
	us := s.user(user)
	us.mu.Lock()
	defer us.mu.Unlock()
	return us.generation
}

// Recycle 回收容器：为所有未达终态的 job 写墓碑，丢弃 job 记录与输出文件名。
// 返回被终止的 job_id 列表（供 executor 终止进程）。
func (s *Store) Recycle(user string) []int {
	us := s.user(user)
	us.mu.Lock()
	defer us.mu.Unlock()

	now := time.Now()
	var killed []int
	for id, j := range us.jobs {
		if j.State == StatePending {
			us.tombstone[id] = &Tombstone{
				User: user, Generation: us.generation, JobID: id, CreatedAt: now,
			}
			killed = append(killed, id)
		}
	}
	sort.Ints(killed)

	// 丢弃 job 记录与 /tmp（输出文件由 executor 随容器销毁一并丢弃）
	us.jobs = make(map[int]*Job)
	// generation 保持不变，直到新代次启动时递增
	return killed
}

// ---------- job 操作 ----------

// NewJob 在当前代次登记一条 pending job。
func (s *Store) NewJob(user string) (*Job, error) {
	us := s.user(user)
	us.mu.Lock()
	defer us.mu.Unlock()

	// 分配 job_id：该代次内单调递增，从 1 起
	next := 1
	for id := range us.jobs {
		if id >= next {
			next = id + 1
		}
	}
	j := &Job{
		User:       user,
		Generation: us.generation,
		JobID:      next,
		State:      StatePending,
		CreatedAt:  time.Now(),
	}
	us.jobs[next] = j
	return j, nil
}

// FinishJob 将 job 置为终态。
func (s *Store) FinishJob(user string, generation, jobID int, r *Result) {
	us := s.user(user)
	us.mu.Lock()
	defer us.mu.Unlock()
	j, ok := us.jobs[jobID]
	if !ok || j.Generation != generation {
		return
	}
	j.State = StateFinished
	j.Result = r
	j.FinishedAt = time.Now()
}

// Lookup 查询 job，实现设计文档 3.3 的查询域规则：
// 只针对当前 generation 的活跃记录；未命中则查墓碑。
// 返回 (job, tombstone, found)。墓碑仅在"代次已回收、新代次未启动"窗口内存在。
func (s *Store) Lookup(user string, jobID int) (job *Job, tomb *Tombstone) {
	us := s.user(user)
	us.mu.Lock()
	defer us.mu.Unlock()
	if j, ok := us.jobs[jobID]; ok {
		return j, nil
	}
	if t, ok := us.tombstone[jobID]; ok {
		return nil, t
	}
	return nil, nil
}

// MarkRead 标记已投递（不再进入 piggyback）。
func (s *Store) MarkRead(user string, generation, jobID int) {
	us := s.user(user)
	us.mu.Lock()
	defer us.mu.Unlock()
	if j, ok := us.jobs[jobID]; ok && j.Generation == generation {
		j.Read = true
	}
}

// MarkReadDirect 仅供已持有 *Job 的调用方使用。
func (s *Store) MarkReadDirect(j *Job) {
	us := s.user(j.User)
	us.mu.Lock()
	defer us.mu.Unlock()
	if cur, ok := us.jobs[j.JobID]; ok && cur == j {
		cur.Read = true
	}
}

// PendingCount 当前 pending job 数（用于 per_user_max_jobs 判定）。
func (s *Store) PendingCount(user string) int {
	us := s.user(user)
	us.mu.Lock()
	defer us.mu.Unlock()
	n := 0
	for _, j := range us.jobs {
		if j.State == StatePending {
			n++
		}
	}
	return n
}

// CollectPiggyback 取出已完成且未被读取的结果，按 job_id 升序，最多 limit 条，
// 并标记为已读取（设计文档 5.2）。
// 返回值同时带 generation 以便正确回写。
func (s *Store) CollectPiggyback(user string, limit int) []*Job {
	us := s.user(user)
	us.mu.Lock()
	defer us.mu.Unlock()

	ids := make([]int, 0, len(us.jobs))
	for id, j := range us.jobs {
		if j.State == StateFinished && !j.Read {
			ids = append(ids, id)
		}
	}
	sort.Ints(ids)
	if len(ids) > limit {
		ids = ids[:limit]
	}
	out := make([]*Job, 0, len(ids))
	for _, id := range ids {
		j := us.jobs[id]
		j.Read = true
		out = append(out, j)
	}
	return out
}

// ---------- GC ----------

// GCStats 一次 GC 扫描的删除结果。
type GCStats struct {
	JobsDeleted       int
	TombstonesDeleted int
	FilesToDelete     []string // 相对 /tmp 的输出文件名
}

// GCSweep 执行一次该 user 的 GC（设计文档 6.2 / 6.3）：
//   - 已读取终态记录：gc_job_retention_s 后删除
//   - 未读取终态记录：保留至 piggyback_undelivered_retention_s
//   - gc_job_record_limit 淘汰：按 job_id 升序、仅终态（墓碑不计入）
//   - 墓碑：gc_tombstone_retention_s 后删除
func (s *Store) GCSweep(user string, gcJobRetention, gcUndelivered, gcTombstone time.Duration, recordLimit int) GCStats {
	us := s.user(user)
	us.mu.Lock()
	defer us.mu.Unlock()

	var st GCStats
	now := time.Now()

	// 1) 按时限删除
	type cand struct {
		id int
		at time.Time
	}
	var expired []cand
	for id, j := range us.jobs {
		if j.State != StateFinished {
			continue
		}
		ttl := gcUndelivered
		if j.Read {
			ttl = gcJobRetention
		}
		if now.Sub(j.FinishedAt) >= ttl {
			expired = append(expired, cand{id, j.FinishedAt})
		}
	}
	sort.Slice(expired, func(a, b int) bool { return expired[a].id < expired[b].id })
	for _, c := range expired {
		st.FilesToDelete = append(st.FilesToDelete, outputFileName(c.id))
		delete(us.jobs, c.id)
		st.JobsDeleted++
	}

	// 2) 记录数上限淘汰（仅终态，按 job_id 升序）；墓碑不占名额
	if recordLimit > 0 && len(us.jobs) > recordLimit {
		ids := make([]int, 0, len(us.jobs))
		for id, j := range us.jobs {
			if j.State == StateFinished {
				ids = append(ids, id)
			}
		}
		sort.Ints(ids)
		over := len(us.jobs) - recordLimit
		for i := 0; i < len(ids) && over > 0; i++ {
			st.FilesToDelete = append(st.FilesToDelete, outputFileName(ids[i]))
			delete(us.jobs, ids[i])
			st.JobsDeleted++
			over--
		}
	}

	// 3) 墓碑过期删除
	for id, t := range us.tombstone {
		if now.Sub(t.CreatedAt) >= gcTombstone {
			delete(us.tombstone, id)
			st.TombstonesDeleted++
		}
	}
	return st
}

// Users 返回全部已登记用户（供 GC 遍历）。
func (s *Store) Users() []string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	out := make([]string, 0, len(s.users))
	for u := range s.users {
		out = append(out, u)
	}
	sort.Strings(out)
	return out
}

// outputFileName 输出文件相对名，对应容器内 /tmp/.out_<jobid>。
func outputFileName(jobID int) string {
	return ".out_" + itoa(jobID)
}

// OutputFileName 导出给 executor 使用。
func OutputFileName(jobID int) string { return outputFileName(jobID) }

func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	neg := n < 0
	if neg {
		n = -n
	}
	var b [20]byte
	i := len(b)
	for n > 0 {
		i--
		b[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		b[i] = '-'
	}
	return string(b[i:])
}

// randHex 生成随机串（用于内部占位标识）。
func randHex(n int) string {
	b := make([]byte, n)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}
