package store

import (
	"testing"
	"time"
)

// TestJobIDRestartsPerGeneration 验证 job_id 按代次重新计数（设计文档 3.3）。
func TestJobIDRestartsPerGeneration(t *testing.T) {
	s := New()
	user := "alice"
	s.StartGeneration(user)

	j1, _ := s.NewJob(user)
	j2, _ := s.NewJob(user)
	if j1.JobID != 1 || j2.JobID != 2 {
		t.Fatalf("期望 job_id 从 1 递增，实际 %d %d", j1.JobID, j2.JobID)
	}

	// 回收后新代次应从 1 重新计数
	s.Recycle(user)
	gen := s.StartGeneration(user)
	j3, _ := s.NewJob(user)
	if j3.JobID != 1 {
		t.Fatalf("新代次 job_id 应重新从 1 起，实际 %d", j3.JobID)
	}
	if j3.Generation != gen {
		t.Fatalf("代次不匹配：%d vs %d", j3.Generation, gen)
	}
}

// TestTombstoneInvalidatedOnNewGeneration 验证新代次启动时历史墓碑立即失效，
// 因此同一 job_id 不可能同时命中墓碑与活跃记录（设计文档 6.3 关键规则）。
func TestTombstoneInvalidatedOnNewGeneration(t *testing.T) {
	s := New()
	user := "alice"
	s.StartGeneration(user)

	// 代次 1：job 1 未完成
	j, _ := s.NewJob(user)
	if j.JobID != 1 {
		t.Fatal("job_id 应为 1")
	}

	// 回收 → 写墓碑
	killed := s.Recycle(user)
	if len(killed) != 1 || killed[0] != 1 {
		t.Fatalf("应终止 job 1，实际 %v", killed)
	}
	if _, tomb := s.Lookup(user, 1); tomb == nil {
		t.Fatal("回收后应能查到墓碑")
	}

	// 新代次启动：历史墓碑必须立即失效
	s.StartGeneration(user)
	if _, tomb := s.Lookup(user, 1); tomb != nil {
		t.Fatal("新代次启动后墓碑应已失效删除")
	}

	// 新代次的 job 1 是独立记录，不与墓碑冲突
	nj, _ := s.NewJob(user)
	if nj.JobID != 1 {
		t.Fatalf("新代次 job_id 应为 1，实际 %d", nj.JobID)
	}
	got, tomb := s.Lookup(user, 1)
	if tomb != nil {
		t.Fatal("不应命中墓碑")
	}
	if got == nil || got.Generation != nj.Generation {
		t.Fatal("应命中新代次的活跃记录")
	}
}

// TestTombstoneNotCountedInRecordLimit 验证墓碑不占用 gc_job_record_limit 名额。
func TestTombstoneNotCountedInRecordLimit(t *testing.T) {
	s := New()
	user := "alice"
	s.StartGeneration(user)

	// 建立 3 个已完成记录
	for i := 0; i < 3; i++ {
		j, _ := s.NewJob(user)
		code := 0
		s.FinishJob(user, j.Generation, j.JobID, &Result{Outcome: OutcomeOK, ExitCode: &code})
		s.MarkReadDirect(j)
	}
	// 再建 2 个 pending 后回收 → 2 条墓碑
	s.NewJob(user)
	s.NewJob(user)
	s.Recycle(user)

	// limit=3 时不应因墓碑挤掉已完成记录
	st := s.GCSweep(user, time.Hour, time.Hour, time.Hour, 3)
	if st.JobsDeleted != 0 {
		t.Fatalf("墓碑不应触发记录淘汰，实际删除 %d 条", st.JobsDeleted)
	}
}

// TestPiggybackDeliveredOnceAndCapped 验证 piggyback 只投递一次且受条数上限约束。
func TestPiggybackDeliveredOnceAndCapped(t *testing.T) {
	s := New()
	user := "alice"
	s.StartGeneration(user)

	for i := 0; i < 5; i++ {
		j, _ := s.NewJob(user)
		code := 0
		s.FinishJob(user, j.Generation, j.JobID, &Result{Outcome: OutcomeOK, ExitCode: &code})
	}

	first := s.CollectPiggyback(user, 2)
	if len(first) != 2 {
		t.Fatalf("上限 2，实际 %d", len(first))
	}
	if first[0].JobID != 1 || first[1].JobID != 2 {
		t.Fatalf("应按 job_id 升序，实际 %d %d", first[0].JobID, first[1].JobID)
	}
	// 第二次不应再投递已读的
	second := s.CollectPiggyback(user, 10)
	if len(second) != 3 {
		t.Fatalf("剩余应为 3 条，实际 %d", len(second))
	}
	// 第三次应为空
	if third := s.CollectPiggyback(user, 10); len(third) != 0 {
		t.Fatalf("已全部投递，应无剩余，实际 %d", len(third))
	}
}

// TestGCUndeliveredRetentionLonger 验证未读取记录按更长的保留期回收。
func TestGCUndeliveredRetentionLonger(t *testing.T) {
	s := New()
	user := "alice"
	s.StartGeneration(user)

	jRead, _ := s.NewJob(user)
	code := 0
	s.FinishJob(user, jRead.Generation, jRead.JobID, &Result{Outcome: OutcomeOK, ExitCode: &code})
	s.MarkReadDirect(jRead)

	jUnread, _ := s.NewJob(user)
	s.FinishJob(user, jUnread.Generation, jUnread.JobID, &Result{Outcome: OutcomeOK, ExitCode: &code})

	// 已读取保留 0，未读取保留 1 小时 → 只有已读取的被清掉
	st := s.GCSweep(user, 0, time.Hour, time.Hour, 0)
	if st.JobsDeleted != 1 {
		t.Fatalf("应只删除 1 条已读取记录，实际 %d", st.JobsDeleted)
	}
	if _, tomb := s.Lookup(user, jUnread.JobID); tomb != nil {
		t.Fatal("未读取记录应保留")
	}
	if j, _ := s.Lookup(user, jUnread.JobID); j == nil {
		t.Fatal("未读取记录应仍可查")
	}
}

// TestPendingCount 验证 pending 计数只统计未完成 job。
func TestPendingCount(t *testing.T) {
	s := New()
	user := "alice"
	s.StartGeneration(user)

	a, _ := s.NewJob(user)
	s.NewJob(user)
	if got := s.PendingCount(user); got != 2 {
		t.Fatalf("期望 2 个 pending，实际 %d", got)
	}
	code := 0
	s.FinishJob(user, a.Generation, a.JobID, &Result{Outcome: OutcomeOK, ExitCode: &code})
	if got := s.PendingCount(user); got != 1 {
		t.Fatalf("完成后期望 1 个 pending，实际 %d", got)
	}
}
