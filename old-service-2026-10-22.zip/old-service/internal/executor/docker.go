package executor

import (
	"archive/tar"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"
)

// dockerClient 直接通过 Docker Engine API（Unix socket）与 daemon 通信。
//
// 不依赖 docker SDK：SDK 的传递依赖要求 Go >= 1.25，而本项目以标准库实现，
// 既可编译又减少依赖面。所有接口均为 Docker Engine HTTP API。
type dockerClient struct {
	httpc *http.Client
	host  string // unix socket 路径
	api   string // 例如 v1.47
}

func newDockerClient() *dockerClient {
	sock := os.Getenv("DOCKER_HOST")
	sock = strings.TrimPrefix(sock, "unix://")
	if sock == "" {
		sock = "/var/run/docker.sock"
	}
	tr := &http.Transport{
		DialContext: func(ctx context.Context, _, _ string) (net.Conn, error) {
			var d net.Dialer
			return d.DialContext(ctx, "unix", sock)
		},
		DisableCompression: true,
	}
	return &dockerClient{
		httpc: &http.Client{Transport: tr},
		host:  sock,
		api:   "v1.47",
	}
}

func (d *dockerClient) url(path string) string {
	return "http://docker/" + d.api + path
}

func (d *dockerClient) ping(ctx context.Context) error {
	resp, err := d.do(ctx, http.MethodGet, "/_ping", nil, "")
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	io.Copy(io.Discard, resp.Body)
	if resp.StatusCode != 200 {
		return fmt.Errorf("docker ping: %s", resp.Status)
	}
	return nil
}

func (d *dockerClient) do(ctx context.Context, method, path string, body io.Reader, contentType string) (*http.Response, error) {
	req, err := http.NewRequestWithContext(ctx, method, d.url(path), body)
	if err != nil {
		return nil, err
	}
	if contentType != "" {
		req.Header.Set("Content-Type", contentType)
	}
	return d.httpc.Do(req)
}

// ---------- 容器 ----------

type dockerRunSpec struct {
	Image     string
	User      string
	CPU       int
	MemoryMB  int
	HomeDir   string
	TmpDir    string
	Network   string
	Subnet    string // 独占 /30（出站管控用），空则不指定静态 IP
	Gateway   string
	ApkMirror string   // 非空则在容器内重写 /etc/apk/repositories
	DNS       []string // 非空则覆盖容器 DNS
}

// ensureNetwork 幂等创建容器网络，并指定子网。
//
// 为什么要独立网络而不是默认 bridge：
// 出站管控按**源网段**匹配。默认 bridge 是 172.17.0.0/16，所有容器共用，
// 按段拒绝会误伤宿主上其它容器；且无法将"本服务创建的容器"与其它容器区分。
// 因此使用独立子网，服务在其上为每个用户切 /30。
//
// 返回 nil 表示网络已存在或创建成功。
func (d *dockerClient) ensureNetwork(ctx context.Context, name, subnet string) error {
	if name == "" {
		return fmt.Errorf("网络名不得为空")
	}
	// 已存在？
	resp, err := d.do(ctx, http.MethodGet, "/networks/"+url.PathEscape(name), nil, "")
	if err == nil {
		io.Copy(io.Discard, resp.Body)
		code := resp.StatusCode
		resp.Body.Close()
		if code == 200 {
			return nil
		}
	}

	body := map[string]any{
		"Name":           name,
		"Driver":         "bridge",
		"CheckDuplicate": true,
	}
	if subnet != "" {
		body["IPAM"] = map[string]any{
			"Driver": "default",
			"Config": []map[string]string{{"Subnet": subnet}},
		}
	}
	// 关闭 ICC：容器间不得互相通信（用户隔离的补充防线）。
	// 注意：仍需放行到网关的流量（DNS/出站经 NAT），ICC 仅阻断容器↔容器。
	body["Options"] = map[string]string{
		"com.docker.network.bridge.enable_icc": "false",
	}
	b, _ := json.Marshal(body)
	resp2, err := d.do(ctx, http.MethodPost, "/networks/create", bytes.NewReader(b), "application/json")
	if err != nil {
		return err
	}
	defer resp2.Body.Close()
	rb, _ := io.ReadAll(resp2.Body)
	if resp2.StatusCode != 201 && resp2.StatusCode != 200 {
		// 已存在（并发创建）不算失败
		if strings.Contains(string(rb), "already exists") {
			return nil
		}
		return fmt.Errorf("创建网络失败：%s %s", resp2.Status, truncate(string(rb), 300))
	}
	return nil
}

// createAndStart 创建并启动容器，返回容器 ID。
func (d *dockerClient) createAndStart(ctx context.Context, spec dockerRunSpec) (string, error) {
	mem := int64(spec.MemoryMB) * 1024 * 1024
	// 容器内 /home/user 与 /tmp 均挂载宿主机目录。
	//
	// 实现说明：文档要求 /tmp 为 tmpfs（计入容器内存配额）。但 Docker 的
	// archive（docker cp）API **无法读取 tmpfs 挂载点内的文件**，会导致输出无法取回。
	// 因此落地时 /tmp 改为 bind mount 到宿主机独立目录，语义上仍是"易失工作区"：
	//   - 容器回收时该目录内容被清空，等价于 tmpfs 的易失性
	//   - 容量上限由 output_tmp_quota_mb 在服务侧强制（见 executor.canAllocate）
	//   - git 磁盘预算由 user_disk_mb 统一覆盖 home+tmp（见 executor.diskUsage）
	// 这是实现层对文档的**有意偏离**，已在 README 中记录。

	// 出站管控：静态 IP + 网关（缺一则退回网络的自动分配）
	netCfg := &networkEndpoint{}
	if spec.Subnet != "" && spec.Gateway != "" {
		netCfg = &networkEndpoint{IP: hostAddrIn(spec.Subnet, 2), Gateway: spec.Gateway}
	}

	createBody := map[string]any{
		"Image": spec.Image,
		"Cmd":   []string{"sleep", "infinity"},
		"Tty":   false,
		"Labels": map[string]string{
			"sandbox-exec.user": spec.User,
		},
		"Env": []string{
			"HOME=/home/user",
			"TMPDIR=/tmp",
			"PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
			// 便于 LLM 在容器内自助安装 Python 包（容器默认无此变量）
			"PIP_INDEX_URL=https://mirrors.aliyun.com/pypi/simple/",
			"PIP_TRUSTED_HOST=mirrors.aliyun.com",
		},
		"WorkingDir": "/home/user",
		"HostConfig": map[string]any{
			"Binds": []string{
				spec.HomeDir + ":/home/user:rw",
				spec.TmpDir + ":/tmp:rw",
			},
			"Memory":      mem,
			"MemorySwap":  mem,
			"NanoCpus":    int64(spec.CPU) * 1_000_000_000,
			"NetworkMode": networkMode(spec.Network),
			"AutoRemove":  false,
			// 与内存配额匹配的容器级限制：禁止 fork 炸弹、限制进程数，
			// 并关掉内核 OOM 之外最常见的资源耗尽路径。
			"PidsLimit": int64(512),
		},
	}

	if spec.DNS != nil {
		createBody["HostConfig"].(map[string]any)["Dns"] = spec.DNS
	}

	// 需要静态 IP 时，走 NetworkingConfig 指定端点
	if netCfg.IP != "" {
		createBody["NetworkingConfig"] = map[string]any{
			"EndpointsConfig": map[string]any{
				spec.Network: map[string]any{
					"IPAMConfig": map[string]string{
						"IPv4Address": netCfg.IP,
					},
					"Gateway": netCfg.Gateway,
				},
			},
		}
	}
	b, _ := json.Marshal(createBody)

	name := "sandbox-exec-" + sanitizeName(spec.User) + "-" + strconv.FormatInt(time.Now().UnixNano(), 36)
	resp, err := d.do(ctx, http.MethodPost, "/containers/create?name="+url.QueryEscape(name), bytes.NewReader(b), "application/json")
	if err != nil {
		return "", fmt.Errorf("创建容器失败：%w", err)
	}
	defer resp.Body.Close()
	rb, _ := io.ReadAll(resp.Body)
	if resp.StatusCode != 201 {
		return "", fmt.Errorf("创建容器失败：%s %s", resp.Status, truncate(string(rb), 300))
	}
	var cr struct {
		ID string `json:"Id"`
	}
	json.Unmarshal(rb, &cr)

	resp2, err := d.do(ctx, http.MethodPost, "/containers/"+cr.ID+"/start", nil, "")
	if err != nil {
		return "", fmt.Errorf("启动容器失败：%w", err)
	}
	defer resp2.Body.Close()
	io.Copy(io.Discard, resp2.Body)
	if resp2.StatusCode != 204 && resp2.StatusCode != 304 {
		return "", fmt.Errorf("启动容器失败：%s", resp2.Status)
	}

	// 基础镜像预配：镜像源与 pip 源（容器默认的 dl-cdn.alpinelinux.org 实测不可达）。
	// 失败仅告警 —— 不影响服务可用性，只是容器内无法直接 apk add。
	if spec.ApkMirror != "" {
		if err := d.setupMirrors(ctx, cr.ID, spec.ApkMirror); err != nil {
			log.Printf("[warn] 容器 %s 镜像源配置失败：%v", cr.ID[:12], err)
		}
	}
	return cr.ID, nil
}

type networkEndpoint struct {
	IP      string
	Gateway string
}

// hostAddrIn 返回子网内第 n 个可用地址（1=网关，2=首个容器地址）。
func hostAddrIn(cidr string, n int) string {
	_, ipnet, err := net.ParseCIDR(cidr)
	if err != nil {
		return ""
	}
	ip := ipnet.IP.To4()
	v := uint32(ip[0])<<24 | uint32(ip[1])<<16 | uint32(ip[2])<<8 | uint32(ip[3])
	v += uint32(n)
	return fmt.Sprintf("%d.%d.%d.%d", byte(v>>24), byte(v>>16), byte(v>>8), byte(v))
}

// setupMirrors 在容器内配置 apk / pip 镜像源。
//
// 原因：alpine 默认源 dl-cdn.alpinelinux.org 在本平台实测不可达
// （mirrors.tuna/pypi.tuna 亦不可达；aliyun / cloud.tencent / npmmirror 可达）。
// 不配置的话 LLM 在容器内 `apk add` 会直接失败，无法"自行安装所需包"。
func (d *dockerClient) setupMirrors(ctx context.Context, cid, mirror string) error {
	m := shq(mirror)
	// 重写 /etc/apk/repositories：把默认域名替换为可用镜像
	script := `set -e
if [ -f /etc/apk/repositories ]; then
  sed -i "s|dl-cdn.alpinelinux.org|` + mirror + `|g" /etc/apk/repositories
fi
# 顺带把 apk 索引预热，避免首次 apk add 需要 update（省一次往返，失败不阻塞）
apk update >/dev/null 2>&1 || true
true
`
	_ = m
	_, err := d.execSimple(ctx, cid, script)
	return err
}

func networkMode(n string) string {
	if n == "" {
		return "bridge"
	}
	return n
}

func (d *dockerClient) isRunning(ctx context.Context, id string) bool {
	resp, err := d.do(ctx, http.MethodGet, "/containers/"+id+"/json", nil, "")
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return false
	}
	var info struct {
		State struct {
			Running bool `json:"Running"`
		} `json:"State"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&info); err != nil {
		return false
	}
	return info.State.Running
}

func (d *dockerClient) remove(ctx context.Context, id string) error {
	resp, err := d.do(ctx, http.MethodDelete, "/containers/"+id+"?force=true&v=false", nil, "")
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	io.Copy(io.Discard, resp.Body)
	return nil
}

// ---------- 执行 ----------

// execAndWait 在容器内执行命令并等待结束。
//
// 关键：命令的 stdout/stderr 已在 shell 侧重定向到 /tmp/.out_<jobid>（文件描述符重定向），
// 因此这里不收集输出，只等待退出码。这满足文档"重定向下无用户态缓冲"的要求。
//
// timeout 实现：**不能**靠取消 HTTP 流 —— 那只会断开服务与 daemon 的连接，
// 容器内的进程仍在运行。正确做法是到点后进入容器 kill 掉该进程组，
// 再等 exec 自然结束，从而拿到真实退出码。
func (d *dockerClient) execAndWait(rp *runningProc, c *UserContainer, shCmd string, timeout time.Duration) (*int, *string, bool) {
	ctx := context.Background()
	code, sig, err := d.execCollect(ctx, c.ContainerID, shCmd, timeout, rp)
	if err != nil {
		if rp.isTimedOut() {
			c := 137
			return &c, ptrStr("SIGKILL"), true
		}
		c := -1
		return &c, nil, false
	}
	return code, sig, rp.isTimedOut()
}

// execCollect 创建 exec 实例、启动、等待结束，返回退出码。
func (d *dockerClient) execCollect(ctx context.Context, cid, shCmd string, timeout time.Duration, rp *runningProc) (*int, *string, error) {
	// 包装命令：在容器内执行，并把 stdout/stderr 重定向到 /tmp/.out_<jobid>
	// （文件描述符重定向，非管道 —— 见设计文档 5.1）。
	//
	// 结构：/bin/sh -c '<用户命令> > /tmp/.out_<jobid> 2>&1'
	//   - 外层 sh 负责重定向并**等待**内层命令结束，exec 的 HTTP 流因此跨越整个命令生命周期
	//   - 不用 `exec` 前缀：用户命令常是复合命令（cd ... && ...），exec 无法替换复合命令
	//   - 不用 setsid：busybox 的 setsid fork 后立即返回，会导致 exec 提前结束（超时失效）
	//
	// 超时强杀由 killJob 在容器内按 /proc/*/fd 定位该输出文件的持有者完成（见下）。
	wrapped := shCmd + " > /tmp/.out_" + itoa(rp.jobID) + " 2>&1"

	body := map[string]any{
		// 必须 AttachStdout/Stderr 为 true：否则 /exec/start 会立即返回，
		// 服务无法感知命令何时结束（超时与退出码都会失真）。
		// 输出虽已重定向到文件，这里仍需要 attach 以获得"阻塞到命令结束"的语义。
		"AttachStdout": true,
		"AttachStderr": true,
		"Tty":          false,
		"Cmd":          []string{"/bin/sh", "-c", wrapped},
		"WorkingDir":   "/home/user",
	}
	b, _ := json.Marshal(body)
	resp, err := d.do(ctx, http.MethodPost, "/containers/"+cid+"/exec", bytes.NewReader(b), "application/json")
	if err != nil {
		return nil, nil, err
	}
	rb, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	if resp.StatusCode != 201 {
		return nil, nil, fmt.Errorf("创建 exec 失败：%s %s", resp.Status, truncate(string(rb), 300))
	}
	var er struct {
		ID string `json:"Id"`
	}
	json.Unmarshal(rb, &er)

	// 启动 exec（detach=false 会在响应体返回前流式输出；因已在 shell 侧重定向，这里无输出）
	startBody := map[string]any{"Detach": false, "Tty": false}
	sb, _ := json.Marshal(startBody)

	// timeout 到期：**进入容器 kill 掉该进程组**（真正终止），而不是取消 HTTP 流
	var timer *time.Timer
	if timeout > 0 {
		timer = time.AfterFunc(timeout, func() {
			rp.setTimedOut()
			d.killJob(cid, rp.jobID)
		})
		defer timer.Stop()
	}

	resp2, err := d.do(ctx, http.MethodPost, "/exec/"+er.ID+"/start", bytes.NewReader(sb), "application/json")
	if err != nil {
		if rp.isTimedOut() {
			return nil, ptrStr("SIGKILL"), nil
		}
		return nil, nil, err
	}
	// 排空输出（应为空，仅为让 exec 跑完）
	_, _ = io.Copy(io.Discard, resp2.Body)
	resp2.Body.Close()

	// 查询退出码
	insp, err := d.do(ctx, http.MethodGet, "/exec/"+er.ID+"/json", nil, "")
	if err != nil {
		if rp.isTimedOut() {
			code := 137
			return &code, ptrStr("SIGKILL"), nil
		}
		return nil, nil, err
	}
	defer insp.Body.Close()
	var ei struct {
		Running  bool `json:"Running"`
		ExitCode int  `json:"ExitCode"`
	}
	if err := json.NewDecoder(insp.Body).Decode(&ei); err != nil {
		return nil, nil, err
	}
	if ei.Running {
		// 仍在运行（超时后未及退出）：强制终止
		d.killJob(cid, rp.jobID)
		if rp.isTimedOut() {
			code := 137
			return &code, ptrStr("SIGKILL"), nil
		}
	}
	code := ei.ExitCode
	if rp.isTimedOut() {
		return &code, ptrStr("SIGKILL"), nil
	}
	return &code, nil, nil
}

// killJob 终止某 job 在容器内的进程。
//
// 定位方式：以输出文件 /tmp/.out_<jobid> 为标记，
//  1. 通过 /proc/<pid>/fd 找出打开了该文件的进程（精确，不受命令行影响）
//  2. 兜底按命令行匹配该标记
//
// 只杀与**本 job 标记相关**的进程，绝不做无差别 pkill，
// 否则会误杀容器内其他并发 job 的进程。
func (d *dockerClient) killJob(cid string, jobID int) {
	ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
	defer cancel()
	marker := ".out_" + itoa(jobID)

	script := `marker=%s
hit=""
for pid in $(ls /proc 2>/dev/null); do
  case "$pid" in ''|*[!0-9]*) continue;; esac
  [ "$pid" = "1" ] && continue
  for fd in /proc/$pid/fd/*; do
    tgt=$(readlink "$fd" 2>/dev/null) || continue
    case "$tgt" in
      *"$marker") hit="$hit $pid"; break;;
    esac
  done
done
for pid in $hit; do kill -9 "$pid" 2>/dev/null; done
pkill -9 -f "$marker" 2>/dev/null
true
`
	script = fmt.Sprintf(script, shq(marker))
	d.execSimple(ctx, cid, script)
}

// execSimple 在容器内执行命令并返回 stdout（用于 /ls 等短命令）。
func (d *dockerClient) execSimple(ctx context.Context, cid, shCmd string) (string, error) {
	body := map[string]any{
		"AttachStdout": true,
		"AttachStderr": false,
		"Tty":          false,
		"Cmd":          []string{"/bin/sh", "-c", shCmd},
	}
	b, _ := json.Marshal(body)
	resp, err := d.do(ctx, http.MethodPost, "/containers/"+cid+"/exec", bytes.NewReader(b), "application/json")
	if err != nil {
		return "", err
	}
	rb, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	if resp.StatusCode != 201 {
		return "", fmt.Errorf("创建 exec 失败：%s", resp.Status)
	}
	var er struct {
		ID string `json:"Id"`
	}
	json.Unmarshal(rb, &er)

	sb, _ := json.Marshal(map[string]any{"Detach": false, "Tty": false})
	resp2, err := d.do(ctx, http.MethodPost, "/exec/"+er.ID+"/start", bytes.NewReader(sb), "application/json")
	if err != nil {
		return "", err
	}
	defer resp2.Body.Close()
	raw, err := io.ReadAll(resp2.Body)
	if err != nil {
		return "", err
	}
	return demuxDockerStream(raw), nil
}

// ---------- 文件 ----------

type pathKind int

const (
	pathMissing pathKind = iota
	pathFile
	pathDir
)

// fileSize 返回容器内文件大小；文件不存在返回 error。
func (d *dockerClient) fileSize(ctx context.Context, cid, path string) (int64, error) {
	out, err := d.execSimple(ctx, cid, "stat -c %s "+shq(path)+" 2>/dev/null || echo -1")
	if err != nil {
		return -1, err
	}
	n, err := strconv.ParseInt(strings.TrimSpace(out), 10, 64)
	if err != nil || n < 0 {
		return -1, fmt.Errorf("no file")
	}
	return n, nil
}

func (d *dockerClient) statPath(ctx context.Context, cid, path string) (pathKind, error) {
	out, err := d.execSimple(ctx, cid, "if [ -d "+shq(path)+" ]; then echo DIR; elif [ -e "+shq(path)+" ]; then echo FILE; else echo MISS; fi")
	if err != nil {
		return pathMissing, err
	}
	switch strings.TrimSpace(out) {
	case "DIR":
		return pathDir, nil
	case "FILE":
		return pathFile, nil
	}
	return pathMissing, nil
}

// copyFromContainer 从容器取回文件内容流（tar 解出单文件）。
func (d *dockerClient) copyFromContainer(ctx context.Context, cid, path string) (io.ReadCloser, error) {
	p := "/containers/" + cid + "/archive?path=" + url.QueryEscape(path)
	resp, err := d.do(ctx, http.MethodGet, p, nil, "")
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != 200 {
		resp.Body.Close()
		return nil, fmt.Errorf("读取文件失败：%s", resp.Status)
	}
	// 解 tar，返回文件内容
	tr := tar.NewReader(resp.Body)
	if _, err := tr.Next(); err != nil {
		resp.Body.Close()
		return nil, err
	}
	return &tarFileReader{tr: tr, body: resp.Body}, nil
}

type tarFileReader struct {
	tr   *tar.Reader
	body io.ReadCloser
}

func (t *tarFileReader) Read(p []byte) (int, error) { return t.tr.Read(p) }
func (t *tarFileReader) Close() error               { return t.body.Close() }

// writeFile 向容器写入文件（tar 流）。
func (d *dockerClient) writeFile(ctx context.Context, cid, path string, content []byte) error {
	var buf bytes.Buffer
	tw := tar.NewWriter(&buf)
	hdr := &tar.Header{
		Name: pathBase(path),
		Mode: 0o644,
		Size: int64(len(content)),
	}
	if err := tw.WriteHeader(hdr); err != nil {
		return err
	}
	if _, err := tw.Write(content); err != nil {
		return err
	}
	if err := tw.Close(); err != nil {
		return err
	}

	dir := pathDirOf(path)
	p := "/containers/" + cid + "/archive?path=" + url.QueryEscape(dir)
	resp, err := d.do(ctx, http.MethodPut, p, &buf, "application/x-tar")
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	io.Copy(io.Discard, resp.Body)
	if resp.StatusCode != 200 {
		return fmt.Errorf("写入文件失败：%s", resp.Status)
	}
	return nil
}

func pathDirOf(p string) string {
	i := strings.LastIndex(p, "/")
	if i <= 0 {
		return "/"
	}
	return p[:i]
}

// ---------- 其他 ----------

// listContainers 列出带本项目标签的运行中容器（供启动时对账）。
func (d *dockerClient) listContainers(ctx context.Context) ([]string, error) {
	filters := url.QueryEscape(`{"label":["sandbox-exec.user"],"status":["running"]}`)
	resp, err := d.do(ctx, http.MethodGet, "/containers/json?filters="+filters, nil, "")
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("列出容器失败：%s", resp.Status)
	}
	var list []struct {
		ID string `json:"Id"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&list); err != nil {
		return nil, err
	}
	out := make([]string, 0, len(list))
	for _, c := range list {
		out = append(out, c.ID)
	}
	return out, nil
}

// demuxDockerStream 解析 Docker 多路复用流（8 字节头 + payload）。
func demuxDockerStream(b []byte) string {
	var out bytes.Buffer
	i := 0
	for i+8 <= len(b) {
		streamType := b[i]
		size := int(b[i+4])<<24 | int(b[i+5])<<16 | int(b[i+6])<<8 | int(b[i+7])
		i += 8
		if streamType > 2 || size < 0 || i+size > len(b) {
			// 非标准流（未复用）：直接返回原文
			return string(b)
		}
		out.Write(b[i : i+size])
		i += size
	}
	if i < len(b) {
		out.Write(b[i:])
	}
	return out.String()
}

func sanitizeName(s string) string {
	var b strings.Builder
	for _, r := range s {
		if (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9') || r == '-' || r == '_' {
			b.WriteRune(r)
		} else {
			b.WriteByte('-')
		}
	}
	return b.String()
}

func truncate(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "..."
}

func ptrStr(s string) *string { return &s }

// itoa 十进制转换。
func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	neg := n < 0
	if neg {
		n = -n
	}
	var b [20]byte
	i := len(b)
	for n > 0 {
		i--
		b[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		b[i] = '-'
	}
	return string(b[i:])
}
