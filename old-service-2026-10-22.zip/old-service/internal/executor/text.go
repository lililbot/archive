package executor

import (
	"strings"
	"unicode/utf8"
)

// sanitizeUTF8Prefix 把字节切片安全地转为字符串。
//
// output_head 与 /cat 的 content 都是 JSON 字符串，必须是合法 UTF-8。
// 按**字节数**截断时可能切断多字节字符的中间，这里把尾部不完整序列丢弃，
// 保证返回的始终是最后一个完整字符边界之前的内容。
func sanitizeUTF8Prefix(b []byte) string {
	for len(b) > 0 && !utf8.Valid(b) {
		b = b[:len(b)-1]
	}
	if len(b) == 0 {
		return ""
	}
	return string(b)
}

// sanitizeUTF8Lossy 与 sanitizeUTF8Prefix 类似，但用替换字符保留长度信息（内部调试用）。
func sanitizeUTF8Lossy(b []byte) string {
	return strings.ToValidUTF8(string(b), "\uFFFD")
}
