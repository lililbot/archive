package executor

import (
	"bytes"
	"testing"
)

func TestBinaryHitBytesNUL(t *testing.T) {
	// 任何位置的 NUL 都应命中（全量 NUL 兜底，不只窗口）
	cases := [][]byte{
		[]byte("abc\x00def"),
		[]byte("\x00"),
		bytes.Repeat([]byte("a"), 10000),
	}
	// 最后一个用例无 NUL，单独验
	if binaryHitBytes(cases[0], 8192, 0.3) != true {
		t.Fatal("含 NUL 应命中")
	}
	if binaryHitBytes(cases[1], 8192, 0.3) != true {
		t.Fatal("单 NUL 应命中")
	}
	if binaryHitBytes(cases[2], 8192, 0.3) != false {
		t.Fatal("纯 ASCII 不应命中")
	}

	// 窗口外的 NUL 也必须被兜底检测到（对应"纯文本开头 + 二进制尾巴"的裂缝修补）
	tail := append(bytes.Repeat([]byte("a"), 9000), 0x00)
	if !binaryHitBytes(tail, 8192, 0.3) {
		t.Fatal("窗口外的 NUL 应被全量兜底检测命中")
	}
}

func TestBinaryHitBytesInvalidRatio(t *testing.T) {
	// 前 10 字节中 9 个无效字节 → 占比 0.9 > 0.3，命中
	b := []byte{0xff, 0xfe, 0xfd, 0xfc, 0xfb, 0xfa, 0xf9, 0xf8, 0xf7, 'a'}
	if !binaryHitBytes(b, 8192, 0.3) {
		t.Fatal("无效字节占比超阈值应命中")
	}
	// 合法 UTF-8 中文不应命中
	if binaryHitBytes([]byte("你好世界 hello"), 8192, 0.3) {
		t.Fatal("合法 UTF-8 不应命中")
	}
	// 占比以字节计：值域边界
	if binaryHitBytes([]byte("valid text only"), 8192, 0.3) {
		t.Fatal("纯文本不应命中")
	}
}

func TestSanitizeUTF8Prefix(t *testing.T) {
	// 切断多字节字符时应回退到完整边界
	s := "你好" // 6 字节
	b := []byte(s)
	got := sanitizeUTF8Prefix(b[:4]) // 截断在第二个字符中间
	if got != "你" {
		t.Fatalf("期望回退为完整字符「你」，实际 %q", got)
	}
	if sanitizeUTF8Prefix(nil) != "" {
		t.Fatal("nil 应返回空串")
	}
	if sanitizeUTF8Prefix([]byte("abc")) != "abc" {
		t.Fatal("完整 ASCII 应原样返回")
	}
}

func TestResolvePath(t *testing.T) {
	// 逃逸与绝对路径必须被拒
	for _, bad := range []string{"/etc/passwd", "../escape", "a/../../b"} {
		if _, _, _, err := resolvePath(bad); err == nil {
			t.Fatalf("%q 应被拒绝", bad)
		}
	}
	// 正常用户文件
	isOut, _, p, err := resolvePath("dir/file.txt")
	if err != nil || isOut || p != "/home/user/dir/file.txt" {
		t.Fatalf("解析错误：isOut=%v p=%s err=%v", isOut, p, err)
	}
	// 输出文件映射到 /tmp，并解析出 job_id
	isOut, jobID, p, err := resolvePath("tmp/.out_7")
	if err != nil || !isOut || jobID != 7 || p != "/tmp/.out_7" {
		t.Fatalf("输出文件解析错误：isOut=%v jobID=%d p=%s err=%v", isOut, jobID, p, err)
	}
	// 非输出文件的 tmp 路径
	isOut, _, p, err = resolvePath("tmp/other.txt")
	if err != nil || isOut || p != "/tmp/other.txt" {
		t.Fatalf("tmp 普通文件解析错误：isOut=%v p=%s err=%v", isOut, p, err)
	}
}

func TestOutputRelPath(t *testing.T) {
	if got := outputRelPath(12); got != "tmp/.out_12" {
		t.Fatalf("期望 tmp/.out_12，实际 %s", got)
	}
}

func TestShq(t *testing.T) {
	if got := shq("a'b"); got != `'a'\''b'` {
		t.Fatalf("单引号转义错误：%s", got)
	}
}
