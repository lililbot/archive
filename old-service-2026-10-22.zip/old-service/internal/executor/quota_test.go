package executor

import (
	"os"
	"path/filepath"
	"testing"

	"sandbox-exec/internal/config"
)

// TestIsCleanupCmd 清理类命令的识别（配额死锁防护的核心）。
func TestIsCleanupCmd(t *testing.T) {
	clean := []string{
		"rm -f big.bin",
		"rm -rf /home/user/cache",
		"  rm -f a",
		"\trm -f a",
		"rmdir emptydir",
		"unlink a.txt",
		"shred secret",
		"find . -name '*.log' -delete",
		"truncate -s 0 big.bin",
		"sudo rm -f a",
		"exec rm -f a",
		"command rm -f a",
	}
	for _, c := range clean {
		if !isCleanupCmd(c) {
			t.Errorf("%q 应被识别为清理命令", c)
		}
	}

	// 这些**不得**被误判为清理（否则等于给写操作开了口子）
	write := []string{
		"echo hi",
		"dd if=/dev/zero of=f.bin bs=1M count=100",
		"rmdirx nothing", // 前缀相近但不同命令
		"rmx foo",        // 同上
		"python -c 'open(\"a\",\"w\")'",
		"apk add curl",
		"",                  // 空
		"terraform destroy", // 含 "rm" 子串但非清理
	}
	for _, c := range write {
		if isCleanupCmd(c) {
			t.Errorf("%q 不应被识别为清理命令", c)
		}
	}
}

// TestDirSize 递归统计普通文件大小。
func TestDirSize(t *testing.T) {
	root := t.TempDir()
	if got := dirSize(root); got != 0 {
		t.Fatalf("空目录应为 0，实际 %d", got)
	}
	if err := os.WriteFile(filepath.Join(root, "a.txt"), []byte("12345"), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(filepath.Join(root, "sub"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(root, "sub", "b.txt"), []byte("123"), 0o644); err != nil {
		t.Fatal(err)
	}
	if got := dirSize(root); got != 8 {
		t.Fatalf("应为 5+3=8，实际 %d", got)
	}
	// 不存在的目录不应 panic，返回 0
	if got := dirSize(filepath.Join(root, "nope")); got != 0 {
		t.Fatalf("不存在目录应为 0，实际 %d", got)
	}
}

// TestWithinDiskQuotaCoversBothDirs 配额必须同时覆盖 home 与 tmp。
//
// 这是 v4 修复的核心：旧实现只统计 homeDir，/tmp 下堆积的输出文件不计入，
// 实际磁盘占用被低估。
func TestWithinDiskQuotaCoversBothDirs(t *testing.T) {
	home := t.TempDir()
	tmpd := t.TempDir()

	// 配额 1MB（MB 按 1024*1024 计）
	e := &Executor{cfg: &config.Config{UserDiskMB: 1}}
	c := &UserContainer{homeDir: home, tmpDir: tmpd}

	// 空目录：可写 1MB 内
	if !e.withinDiskQuota(nil, c, "", 0) {
		t.Fatal("空目录应通过配额检查")
	}
	if e.withinDiskQuota(nil, c, "", 2*1024*1024) {
		t.Fatal("超出配额的写入应被拒绝")
	}

	// 在 tmp 放 600KB —— 旧实现看不见这部分
	if err := os.WriteFile(filepath.Join(tmpd, "out.bin"), make([]byte, 600*1024), 0o644); err != nil {
		t.Fatal(err)
	}
	// 已用 600KB，再写 500KB 应超限（600+500 > 1024）
	if e.withinDiskQuota(nil, c, "", 500*1024) {
		t.Fatal("tmp 的占用必须计入配额，此处应超限")
	}
	// 再写 300KB 仍在限额内（600+300 = 900 < 1024）
	if !e.withinDiskQuota(nil, c, "", 300*1024) {
		t.Fatal("600+300 < 1024，应通过")
	}
}

// TestWithinDiskQuotaReplace 覆盖写时扣除原文件大小，避免重复计算。
func TestWithinDiskQuotaReplace(t *testing.T) {
	home := t.TempDir()
	tmpd := t.TempDir()
	e := &Executor{cfg: &config.Config{UserDiskMB: 1}}
	c := &UserContainer{homeDir: home, tmpDir: tmpd}

	// 已存在 900KB 的文件
	target := filepath.Join(home, "big.txt")
	if err := os.WriteFile(target, make([]byte, 900*1024), 0o644); err != nil {
		t.Fatal(err)
	}
	// 覆盖写同样大小（900KB）：应通过（先扣除原 900KB，再计入新 900KB）
	if !e.withinDiskQuota(nil, c, "/home/user/big.txt", 900*1024) {
		t.Fatal("等量覆盖写应通过（扣除原文件后仍为 900KB < 1MB）")
	}
	// 覆盖写 200KB：应通过
	if !e.withinDiskQuota(nil, c, "/home/user/big.txt", 200*1024) {
		t.Fatal("缩小覆盖写应通过")
	}
}

// TestHostPathSize 容器内路径 → 宿主机路径的大小映射。
func TestHostPathSize(t *testing.T) {
	home := t.TempDir()
	tmpd := t.TempDir()
	c := &UserContainer{homeDir: home, tmpDir: tmpd}

	if err := os.WriteFile(filepath.Join(home, "a.txt"), []byte("1234567890"), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(tmpd, ".out_3"), []byte("abc"), 0o644); err != nil {
		t.Fatal(err)
	}

	if got := hostPathSize(c, "/home/user/a.txt"); got != 10 {
		t.Fatalf("home 文件应为 10，实际 %d", got)
	}
	if got := hostPathSize(c, "/tmp/.out_3"); got != 3 {
		t.Fatalf("tmp 文件应为 3，实际 %d", got)
	}
	// 不存在 → 0
	if got := hostPathSize(c, "/home/user/nope.txt"); got != 0 {
		t.Fatalf("不存在文件应为 0，实际 %d", got)
	}
	// 目录本身 → 0
	if got := hostPathSize(c, "/home/user"); got != 0 {
		t.Fatalf("/home/user 本身应为 0，实际 %d", got)
	}
	// 非受管路径 → 0
	if got := hostPathSize(c, "/etc/passwd"); got != 0 {
		t.Fatalf("非受管路径应为 0，实际 %d", got)
	}
}

// TestDiskUsageZeroLimitUnlimited 配额为 0 表示不限。
func TestDiskUsageZeroLimitUnlimited(t *testing.T) {
	e := &Executor{cfg: &config.Config{UserDiskMB: 0}}
	c := &UserContainer{homeDir: t.TempDir(), tmpDir: t.TempDir()}
	if !e.withinDiskQuota(nil, c, "", 1<<40) {
		t.Fatal("user_disk_mb=0 应表示不限")
	}
}
