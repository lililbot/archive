package executor

import (
	"context"
	"log"
	"time"

	"sandbox-exec/internal/config"
	"sandbox-exec/internal/store"
)

// GC 后台任务（设计文档 10）：周期扫描，不在请求处理路径内。
type GC struct {
	cfg *config.Config
	st  *store.Store
	ex  *Executor
}

func NewGC(cfg *config.Config, st *store.Store, ex *Executor) *GC {
	return &GC{cfg: cfg, st: st, ex: ex}
}

// Run 启动周期 GC，阻塞直到 ctx 取消。
func (g *GC) Run(ctx context.Context) {
	t := time.NewTicker(time.Duration(g.cfg.GCScanIntervalS) * time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			g.sweep(ctx)
		}
	}
}

func (g *GC) sweep(ctx context.Context) {
	// 1) 空闲容器回收
	g.reapIdleContainers(ctx)

	// 2) 每用户 job 记录与墓碑清理
	for _, user := range g.st.Users() {
		st := g.st.GCSweep(
			user,
			time.Duration(g.cfg.GCJobRetentionS)*time.Second,
			time.Duration(g.cfg.PiggybackUndeliveredRetentionS)*time.Second,
			time.Duration(g.cfg.GCTombstoneRetentionS)*time.Second,
			g.cfg.GCJobRecordLimit,
		)
		if st.JobsDeleted > 0 || st.TombstonesDeleted > 0 {
			log.Printf("[gc] user=%s jobs_deleted=%d tombstones_deleted=%d", user, st.JobsDeleted, st.TombstonesDeleted)
		}
	}
}

// reapIdleContainers 回收空闲超过 gc_idle_container_s 的容器。
//
// 回收动作（设计文档 10）：运行中 job 一并终止 → 为未达终态的 job 写墓碑
// → job 记录与 /tmp 丢弃 → /home/user 保留。
//
// 注意：**运行中 job 不阻止回收**。
func (g *GC) reapIdleContainers(ctx context.Context) {
	idle := time.Duration(g.cfg.GCIdleContainerS) * time.Second
	for _, c := range g.ex.Snapshot() {
		if time.Since(c.LastActive()) < idle {
			continue
		}
		// 回收：先写墓碑（Recycle 会返回被终止的 job），再销毁容器
		killed := g.st.Recycle(c.User)
		if err := g.ex.Destroy(ctx, c); err != nil {
			log.Printf("[gc] 回收容器失败 user=%s cid=%s err=%v", c.User, c.ContainerID, err)
			continue
		}
		log.Printf("[gc] 回收容器 user=%s cid=%s generation=%d killed_jobs=%v",
			c.User, c.ContainerID, c.Generation, killed)
	}
}
