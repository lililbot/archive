package executor

import (
	"io"
	"os"
	"unicode/utf8"
)

// binaryDetector 实现《设计文档》4.2 / 《工程文档》5.2 的二进制判定。
//
// 规则：内容任一 NUL 字节，**或**前 binary_check_window 字节中
// 无效 UTF-8 **字节**占比 > binary_invalid_ratio（占比以字节计，非字符）。
type binaryDetector struct {
	window       int
	invalidRatio float64

	scanned int  // 已扫描字节数
	invalid int  // 无效 UTF-8 字节数
	sawNUL  bool // 是否出现 NUL 字节
}

func newBinaryDetector(window int, ratio float64) *binaryDetector {
	return &binaryDetector{window: window, invalidRatio: ratio}
}

// hit 报告是否命中二进制。
func (d *binaryDetector) hit() bool {
	if d.sawNUL {
		return true
	}
	if d.scanned == 0 {
		return false
	}
	return float64(d.invalid)/float64(d.scanned) > d.invalidRatio
}

// feed 送入一段数据做判定（可多次调用）。
func (d *binaryDetector) feed(b []byte) {
	for i := 0; i < len(b); i++ {
		if b[i] == 0 {
			d.sawNUL = true
		}
	}
	d.scanned += len(b)
	d.invalid += countInvalidUTF8Bytes(b)
}

// scanWindow 只扫描前 window 字节（job 终态的快速路径）。
func (d *binaryDetector) scanWindow(b []byte) {
	if len(b) > d.window {
		b = b[:d.window]
	}
	d.feed(b)
}

// scanFile 扫描整个文件：
//   - 前 window 字节做完整判定（NUL + 无效 UTF-8 占比）
//   - 超出 window 的部分**仅做 NUL 检测**（低成本，对应"读取期全量兜底"）
//
// 这实现了设计文档 5.5 的"判定窗口用于快速路径，完整读取以全文件 NUL 检测兜底"。
func (d *binaryDetector) scanFile(path string) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()

	win := make([]byte, d.window)
	n, err := io.ReadFull(f, win)
	if err != nil && err != io.ErrUnexpectedEOF && err != io.EOF {
		return err
	}
	d.scanWindow(win[:n])

	// 窗口外：仅 NUL 检测
	buf := make([]byte, 64*1024)
	for {
		m, rerr := f.Read(buf)
		if m > 0 {
			for i := 0; i < m; i++ {
				if buf[i] == 0 {
					d.sawNUL = true
					break
				}
			}
		}
		if rerr != nil {
			break
		}
		if d.sawNUL {
			break
		}
	}
	return nil
}

// binaryHitBytes 对一段完整内容做二进制判定。
//
// 规则（设计文档 5.5）：
//   - 内容**任一** NUL 字节 → 命中
//   - 前 window 字节中无效 UTF-8 **字节**占比 > ratio → 命中
//
// 注意"全量 NUL 兜底"：NUL 检测覆盖**全部**内容（不只窗口），
// 这正是文档要求的"读取期全量 NUL 兜底"，用于修补"纯文本开头 + 二进制尾巴"的裂缝。
func binaryHitBytes(b []byte, window int, ratio float64) bool {
	for i := 0; i < len(b); i++ {
		if b[i] == 0 {
			return true
		}
	}
	if len(b) == 0 {
		return false
	}
	w := b
	if window > 0 && len(w) > window {
		w = w[:window]
	}
	invalid := countInvalidUTF8Bytes(w)
	return float64(invalid)/float64(len(w)) > ratio
}

// countInvalidUTF8Bytes 统计一段数据中无效 UTF-8 的**字节**数。
//
// 说明：按字节统计（非字符），与文档"占比以字节计"一致。
// 遇到非法序列时，按该序列实际消耗的长度计为无效字节。
func countInvalidUTF8Bytes(b []byte) int {
	invalid := 0
	i := 0
	for i < len(b) {
		r, size := utf8.DecodeRune(b[i:])
		if r == utf8.RuneError {
			if size == 1 {
				// 非法单字节
				invalid++
				i++
				continue
			}
			// 合法编码的 U+FFFD（size==3），不算无效
			i += size
			continue
		}
		i += size
	}
	return invalid
}
