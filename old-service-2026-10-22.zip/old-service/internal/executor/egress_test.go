package executor

import (
	"testing"

	"sandbox-exec/internal/config"
)

// TestSubnetForSequence 每用户 /30 顺序切分，且同用户稳定。
func TestSubnetForSequence(t *testing.T) {
	g := newEgressGuard(&config.Config{EgressSubnetBase: "172.20.0.0/16"})

	a1, err := g.subnetFor("alice")
	if err != nil {
		t.Fatal(err)
	}
	if a1 != "172.20.0.0/30" {
		t.Fatalf("首个用户应得 172.20.0.0/30，实际 %s", a1)
	}

	b1, err := g.subnetFor("bob")
	if err != nil {
		t.Fatal(err)
	}
	if b1 != "172.20.0.4/30" {
		t.Fatalf("第二个用户应得 172.20.0.4/30，实际 %s", b1)
	}

	// 同一用户重复调用必须返回同一段（容器重建不换段）
	a2, err := g.subnetFor("alice")
	if err != nil {
		t.Fatal(err)
	}
	if a2 != a1 {
		t.Fatalf("同用户应保持稳定：%s != %s", a2, a1)
	}

	// 不应重复分配
	if a1 == b1 {
		t.Fatal("不同用户不得共用网段")
	}
}

// TestSubnetForExhaustion 段耗尽应报错而非静默回绕。
func TestSubnetForExhaustion(t *testing.T) {
	// /24 基址 → 2^(30-24) = 64 个 /30
	g := newEgressGuard(&config.Config{EgressSubnetBase: "10.9.0.0/24"})
	for i := 0; i < 64; i++ {
		if _, err := g.subnetFor(string(rune('a'+i%26)) + string(rune('0'+i/26))); err != nil {
			t.Fatalf("第 %d 个用户分配失败：%v", i, err)
		}
	}
	if _, err := g.subnetFor("overflow"); err == nil {
		t.Fatal("段耗尽后应报错")
	}
}

// TestSubnetForInvalidBase 非法基址应报错。
func TestSubnetForInvalidBase(t *testing.T) {
	for _, bad := range []string{"", "not-a-cidr", "2001:db8::/64", "300.1.1.1/24"} {
		g := newEgressGuard(&config.Config{EgressSubnetBase: bad})
		if _, err := g.subnetFor("x"); err == nil {
			t.Errorf("基址 %q 应被拒绝", bad)
		}
	}
}

// TestGatewayFor 网关是子网内第 1 个可用地址。
func TestGatewayFor(t *testing.T) {
	g := newEgressGuard(&config.Config{EgressSubnetBase: "172.20.0.0/16"})
	cases := map[string]string{
		"172.20.0.0/30":   "172.20.0.1",
		"172.20.0.4/30":   "172.20.0.5",
		"172.20.0.8/30":   "172.20.0.9",
		"172.20.0.252/30": "172.20.0.253",
	}
	for cidr, want := range cases {
		if got := g.GatewayFor(cidr); got != want {
			t.Errorf("%s 网关应为 %s，实际 %s", cidr, want, got)
		}
	}
	if got := g.GatewayFor("bad"); got != "" {
		t.Errorf("非法 CIDR 应返回空串，实际 %q", got)
	}
}

// TestHostAddrIn 容器地址是子网内第 2 个地址（第 1 个是网关）。
func TestHostAddrIn(t *testing.T) {
	cases := []struct {
		cidr string
		n    int
		want string
	}{
		{"172.20.0.0/30", 2, "172.20.0.2"},
		{"172.20.0.4/30", 2, "172.20.0.6"},
		{"172.20.0.8/30", 2, "172.20.0.10"},
		{"172.20.0.0/30", 1, "172.20.0.1"},
	}
	for _, k := range cases {
		if got := hostAddrIn(k.cidr, k.n); got != k.want {
			t.Errorf("hostAddrIn(%s,%d) 应为 %s，实际 %s", k.cidr, k.n, k.want, got)
		}
	}
	if got := hostAddrIn("bad", 2); got != "" {
		t.Errorf("非法 CIDR 应返回空串，实际 %q", got)
	}
}

// TestConfigEgressSubnetOK 配置层的子网校验。
func TestConfigEgressSubnetOK(t *testing.T) {
	ok := []string{"172.20.0.0/16", "10.0.0.0/8", "192.168.5.0/24"}
	for _, s := range ok {
		if !config.EgressSubnetOK(s) {
			t.Errorf("%q 应通过校验", s)
		}
	}
	bad := []string{"", "abc", "172.20.0.0/30", "172.20.0.0/32", "2001:db8::/64"}
	for _, s := range bad {
		if config.EgressSubnetOK(s) {
			t.Errorf("%q 应校验失败", s)
		}
	}
}
