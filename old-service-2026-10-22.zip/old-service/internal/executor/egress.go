package executor

import (
	"fmt"
	"log"
	"net"
	"os/exec"
	"strings"
	"sync"

	"sandbox-exec/internal/config"
)

// 出站管控（v4）。
//
// 目标：容器「禁内网/元数据，公网自由」—— 能自行 apk/pip 装包、能访问公网 API，
// 但不得触碰私网、链路本地与云元数据地址。
//
// 为什么不用容器内 iptables：
//
//	宿主机实测容器默认无 CAP_NET_ADMIN，容器内 iptables/ip route 全部
//	"Permission denied"。要让它工作必须 --cap-add NET_ADMIN，
//	那等于把网络栈控制权交给被测代码本身，是明显的权限降级，且规则可被移除。
//
// 采用的方案（宿主机侧防线）：
//
//	1. 为每个用户分配一个独占 /30 子网（4 个地址），容器在该子网内
//	2. 服务在宿主机 FORWARD 链上按**源网段**匹配，拒绝到内网/元数据地址的转发
//	3. 容器自身不需要任何额外 capability，规则也不在容器内，无法被移除
//
// 规则链结构（幂等，可反复执行）：
//
//	SBX_EGRESS           —— 公共拒绝链，存放各 block CIDR 的 REJECT 规则
//	SBX_EGRESS_USER_<n>  —— 每用户链，仅一句 "-j SBX_EGRESS"
//	FORWARD              —— 两句 "-s <用户/30> -j SBX_EGRESS_USER_<n>"
//
// FORWARD 的插入位置很重要：必须在 Docker 自己的 FORWARD 规则**之前**，
// 否则 Docker 的 ACCEPT 会先命中（Docker 使用 -I 插到链首）。
// 因此这里同样用 -I（插入到第 1 位），并按插入顺序倒序处理以保持稳定。

const (
	egressCommonChain = "SBX_EGRESS"
	egressUserPrefix  = "SBX_EGRESS_USER_"
)

// egressGuard 管理宿主侧出站管控规则。
type egressGuard struct {
	cfg *config.Config

	mu      sync.Mutex
	subnets map[string]string // user → 已分配的子网（CIDR）
	byIndex map[int]string    // 段序号 → user
	nextIdx int
	ready   bool // 公共链是否已建好
}

func newEgressGuard(cfg *config.Config) *egressGuard {
	return &egressGuard{
		cfg:     cfg,
		subnets: map[string]string{},
		byIndex: map[int]string{},
	}
}

// iptables 是否可用且可用（需要 CAP_NET_ADMIN）。结果缓存，避免每次 fork。
func (g *egressGuard) iptablesUsable() bool {
	out, err := exec.Command("iptables", "-L", "FORWARD", "-n").CombinedOutput()
	if err != nil {
		log.Printf("[egress] iptables 不可用，出站规则不会下发（容器将可访问内网）：%v %s",
			err, strings.TrimSpace(string(out)))
		return false
	}
	return true
}

func runIptables(args ...string) error {
	out, err := exec.Command("iptables", args...).CombinedOutput()
	if err != nil {
		return fmt.Errorf("iptables %s：%v %s", strings.Join(args, " "), err, strings.TrimSpace(string(out)))
	}
	return nil
}

// ensureCommonChain 建立公共拒绝链（幂等）。
func (g *egressGuard) ensureCommonChain() error {
	g.mu.Lock()
	defer g.mu.Unlock()
	if g.ready {
		return nil
	}

	// 链已存在时 -N 会报错，先尝试清空重建以保证规则与服务配置一致
	if err := runIptables("-N", egressCommonChain); err != nil {
		if err := runIptables("-F", egressCommonChain); err != nil {
			return err
		}
	}
	for _, cidr := range g.cfg.EgressBlockCIDRs {
		cidr = strings.TrimSpace(cidr)
		if cidr == "" {
			continue
		}
		// 用 REJECT 而非 DROP：让容器内的连接尝试立刻失败并报错，
		// 而不是静默挂起（后者会让 LLM 以为"网络很慢"并反复重试）。
		if err := runIptables("-A", egressCommonChain, "-d", cidr, "-j", "REJECT"); err != nil {
			return err
		}
	}
	g.ready = true
	log.Printf("[egress] 公共拒绝链已建立，屏蔽 %d 个网段", len(g.cfg.EgressBlockCIDRs))
	return nil
}

// subnetFor 返回该用户已分配或新分配的子网 CIDR。
// 分配在子网基数上按 /30 顺序切分；已分配的用户保持稳定（容器重建也不换段）。
func (g *egressGuard) subnetFor(user string) (string, error) {
	g.mu.Lock()
	defer g.mu.Unlock()
	if s, ok := g.subnets[user]; ok {
		return s, nil
	}

	_, base, err := net.ParseCIDR(g.cfg.EgressSubnetBase)
	if err != nil {
		return "", fmt.Errorf("egress_subnet_base 非法：%w", err)
	}
	ip := base.IP.To4()
	if ip == nil {
		return "", fmt.Errorf("egress_subnet_base 必须是 IPv4")
	}
	ones, bits := base.Mask.Size()
	if bits != 32 {
		return "", fmt.Errorf("egress_subnet_base 掩码异常")
	}
	// 可用 /30 段数 = 2^(30-ones)
	count := 1 << (30 - ones)
	if g.nextIdx >= count {
		return "", fmt.Errorf("出站子网段已耗尽（上限 %d）", count)
	}

	// 第 idx 个 /30：基址 + idx*4
	idx := g.nextIdx
	g.nextIdx++
	start := uint32(ip[0])<<24 | uint32(ip[1])<<16 | uint32(ip[2])<<8 | uint32(ip[3])
	start += uint32(idx) * 4
	sub := fmt.Sprintf("%d.%d.%d.%d/30",
		byte(start>>24), byte(start>>16), byte(start>>8), byte(start))

	g.subnets[user] = sub
	g.byIndex[idx] = user
	return sub, nil
}

// GatewayFor 返回该用户子网的网关地址（子网第 1 个可用地址）。
func (g *egressGuard) GatewayFor(cidr string) string {
	_, n, err := net.ParseCIDR(cidr)
	if err != nil {
		return ""
	}
	ip := n.IP.To4()
	v := uint32(ip[0])<<24 | uint32(ip[1])<<16 | uint32(ip[2])<<8 | uint32(ip[3])
	v++
	return fmt.Sprintf("%d.%d.%d.%d", byte(v>>24), byte(v>>16), byte(v>>8), byte(v))
}

// ApplyUser 为该用户的子网下发 FORWARD 规则。
func (g *egressGuard) ApplyUser(user, cidr string) error {
	g.mu.Lock()
	idx := -1
	for i, u := range g.byIndex {
		if u == user {
			idx = i
			break
		}
	}
	g.mu.Unlock()

	if idx < 0 {
		return fmt.Errorf("用户 %s 尚无出站段", user)
	}

	chain := fmt.Sprintf("%s%d", egressUserPrefix, idx)
	// 用户链：仅跳转到公共拒绝链
	if err := runIptables("-N", chain); err != nil {
		if err := runIptables("-F", chain); err != nil {
			return err
		}
	}
	if err := runIptables("-A", chain, "-j", egressCommonChain); err != nil {
		return err
	}

	// FORWARD 上的两句规则：先删后插，保证幂等且位于 Docker 规则之前。
	_ = runIptables("-D", "FORWARD", "-s", cidr, "-j", chain)
	if err := runIptables("-I", "FORWARD", "1", "-s", cidr, "-j", chain); err != nil {
		return err
	}
	return nil
}

// ReleaseUser 撤销该用户的 FORWARD 规则与用户链（容器销毁时调用）。
func (g *egressGuard) ReleaseUser(user string) {
	g.mu.Lock()
	idx := -1
	cidr := ""
	for i, u := range g.byIndex {
		if u == user {
			idx = i
			break
		}
	}
	cidr = g.subnets[user]
	g.mu.Unlock()

	if idx < 0 || cidr == "" {
		return
	}
	chain := fmt.Sprintf("%s%d", egressUserPrefix, idx)
	_ = runIptables("-D", "FORWARD", "-s", cidr, "-j", chain)
	_ = runIptables("-F", chain)
	_ = runIptables("-X", chain)
}

// CleanupStale 清理进程上次退出时遗留的规则（启动对账）。
// 规则按段序号命名，进程重启后内存态丢失，必须全量清理。
func (g *egressGuard) CleanupStale() {
	if !g.iptablesUsable() {
		return
	}
	// 删除 FORWARD 上所有指向 SBX_EGRESS_USER_* 的规则
	out, err := exec.Command("iptables", "-S", "FORWARD").CombinedOutput()
	if err == nil {
		for _, line := range strings.Split(string(out), "\n") {
			if !strings.Contains(line, egressUserPrefix) {
				continue
			}
			// 形如：-A FORWARD -s 172.20.0.0/30 -j SBX_EGRESS_USER_0
			fields := strings.Fields(line)
			if len(fields) < 2 || fields[0] != "-A" {
				continue
			}
			args := append([]string{"-D"}, fields[1:]...)
			_ = runIptables(args...)
		}
	}
	// 清理所有 SBX_EGRESS_USER_* 链
	out, err = exec.Command("iptables", "-S").CombinedOutput()
	if err == nil {
		for _, line := range strings.Split(string(out), "\n") {
			if !strings.HasPrefix(line, "-N "+egressUserPrefix) {
				continue
			}
			name := strings.TrimSpace(strings.TrimPrefix(line, "-N "))
			_ = runIptables("-F", name)
			_ = runIptables("-X", name)
		}
	}
}
