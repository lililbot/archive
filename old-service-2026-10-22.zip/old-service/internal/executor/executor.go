package executor

import (
	"archive/tar"
	"bytes"
	"context"
	"fmt"
	"io"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"sandbox-exec/internal/config"
	"sandbox-exec/internal/store"
)

// Executor 管理每用户一个的 Docker 容器，并在其中执行命令。
//
// 落地实现说明（与文档条款的对应）：
//   - 每用户一个容器，由 user 参数路由（设计文档 1）
//   - 容器按需启动，空闲回收（设计文档 6.1）
//   - 输出经容器内 /tmp/.out_<jobid>（bind mount，非 tmpfs，见设计文档 4.2）
//   - 配额写满时**停止写入、丢弃超出、不终止进程**（设计文档 5.4）
//   - 服务通过 docker exec 驱动命令，输出用 docker cp 取回宿主机做判定与投递
type Executor struct {
	cfg *config.Config
	st  *store.Store

	mu         sync.Mutex
	containers map[string]*UserContainer
	running    int

	docker *dockerClient
	egress *egressGuard
}

// UserContainer 一个用户的容器实例（一代）。
type UserContainer struct {
	User        string
	Generation  int
	ContainerID string

	mu         sync.Mutex
	procs      map[int]*runningProc
	lastActive time.Time

	// 宿主机侧工作目录（用于 /home/user 持久卷与临时交换）
	homeDir string
	tmpDir  string
}

type runningProc struct {
	jobID  int
	cancel context.CancelFunc

	mu           sync.Mutex
	truncated    bool
	timedOutFlag bool
	done         chan struct{}
	binHit       bool
}

func (rp *runningProc) setTruncated() { rp.mu.Lock(); rp.truncated = true; rp.mu.Unlock() }
func (rp *runningProc) getTruncated() bool {
	rp.mu.Lock()
	defer rp.mu.Unlock()
	return rp.truncated
}
func (rp *runningProc) setTimedOut() { rp.mu.Lock(); rp.timedOutFlag = true; rp.mu.Unlock() }
func (rp *runningProc) isTimedOut() bool {
	rp.mu.Lock()
	defer rp.mu.Unlock()
	return rp.timedOutFlag
}

// New 构造执行器。
func New(cfg *config.Config, st *store.Store) *Executor {
	e := &Executor{
		cfg:        cfg,
		st:         st,
		containers: make(map[string]*UserContainer),
		docker:     newDockerClient(),
		egress:     newEgressGuard(cfg),
	}
	return e
}

// EnsureEgressNetwork 准备出站管控（容器网络 + 宿主侧规则链）。
// 在服务启动时调用一次。不可用时仅告警，服务仍可运行（但容器网络可能走默认 bridge）。
func (e *Executor) EnsureEgressNetwork(ctx context.Context) {
	if !e.cfg.EgressEnforceHost {
		log.Printf("[egress] egress_enforce_host=false，跳过宿主侧出站规则")
		return
	}
	if !e.egress.iptablesUsable() {
		return
	}
	e.egress.CleanupStale()
	if err := e.egress.ensureCommonChain(); err != nil {
		log.Printf("[warn] 建立出站拒绝链失败：%v", err)
		return
	}
	// 创建独占网络（幂等）
	if err := e.docker.ensureNetwork(ctx, e.cfg.DockerNetwork, e.cfg.EgressSubnetBase); err != nil {
		log.Printf("[warn] 创建容器网络 %s 失败：%v", e.cfg.DockerNetwork, err)
	}
}

// ReleaseEgress 撤销该用户的出站规则（容器销毁时调用）。
func (e *Executor) ReleaseEgress(user string) {
	if e.cfg.EgressEnforceHost {
		e.egress.ReleaseUser(user)
	}
}

// DockerAvailable 报告 Docker 是否可用。
func (e *Executor) DockerAvailable() bool {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	return e.docker.ping(ctx) == nil
}

var ErrNoCapacity = fmt.Errorf("no capacity")

// EnsureContainer 返回该 user 的运行中容器，必要时冷启动。
// created=true 表示本次新建（已递增 generation、失效历史墓碑）。
func (e *Executor) EnsureContainer(ctx context.Context, user string) (*UserContainer, bool, error) {
	e.mu.Lock()
	if c, ok := e.containers[user]; ok && c.alive(ctx, e.docker) {
		c.touch()
		e.mu.Unlock()
		return c, false, nil
	}

	// 冷启动前检查全局容量（设计文档 2.4：无运行中容器且达上限 → 503）
	if e.cfg.ContainerTotalLimit > 0 && e.running >= e.cfg.ContainerTotalLimit {
		e.mu.Unlock()
		return nil, false, ErrNoCapacity
	}
	e.running++
	e.mu.Unlock()

	c, err := e.startContainer(ctx, user)
	if err != nil {
		e.mu.Lock()
		e.running--
		e.mu.Unlock()
		return nil, false, err
	}

	// 新代次启动：递增 generation 并**立即失效删除历史墓碑**（设计文档 6.3）
	c.Generation = e.st.StartGeneration(user)

	e.mu.Lock()
	e.containers[user] = c
	e.mu.Unlock()
	return c, true, nil
}

func (e *Executor) startContainer(ctx context.Context, user string) (*UserContainer, error) {
	base := filepath.Join(e.cfg.HomeVolumeRoot, user)
	homeDir := filepath.Join(base, "home")
	tmpDir := filepath.Join(base, "tmp")
	for _, d := range []string{homeDir, tmpDir} {
		if err := os.MkdirAll(d, 0o777); err != nil {
			return nil, fmt.Errorf("创建用户目录失败：%w", err)
		}
		_ = os.Chmod(base, 0o777)
		_ = os.Chmod(homeDir, 0o777)
		_ = os.Chmod(tmpDir, 0o777)
	}
	// 清理上一代遗留的输出文件（容器代次隔离）
	cleanOutputFiles(tmpDir)

	// 出站管控：为本用户分配独占 /30 段并下发宿主侧规则。
	// 必须在容器创建**之前**完成，否则存在规则生效前的窗口期。
	var subnet, gateway string
	if e.cfg.EgressEnforceHost {
		if sn, err := e.egress.subnetFor(user); err != nil {
			log.Printf("[warn] 用户 %s 出站段分配失败：%v", user, err)
		} else {
			subnet = sn
			gateway = e.egress.GatewayFor(sn)
			if err := e.egress.ApplyUser(user, sn); err != nil {
				log.Printf("[warn] 用户 %s 出站规则下发失败：%v", user, err)
			}
		}
	}

	id, err := e.docker.createAndStart(ctx, dockerRunSpec{
		Image:     e.cfg.BaseImage,
		User:      user,
		CPU:       e.cfg.ContainerCPU,
		MemoryMB:  e.cfg.ContainerMemMB,
		HomeDir:   homeDir,
		TmpDir:    tmpDir,
		Network:   e.cfg.DockerNetwork,
		Subnet:    subnet,
		Gateway:   gateway,
		ApkMirror: e.cfg.ApkMirror,
		DNS:       e.cfg.EgressDNS,
	})
	if err != nil {
		e.ReleaseEgress(user)
		return nil, err
	}

	c := &UserContainer{
		User:        user,
		ContainerID: id,
		procs:       make(map[int]*runningProc),
		lastActive:  time.Now(),
		homeDir:     homeDir,
		tmpDir:      tmpDir,
	}
	return c, nil
}

func (c *UserContainer) alive(ctx context.Context, d *dockerClient) bool {
	if c == nil || c.ContainerID == "" {
		return false
	}
	return d.isRunning(ctx, c.ContainerID)
}

func (c *UserContainer) touch() {
	c.mu.Lock()
	c.lastActive = time.Now()
	c.mu.Unlock()
}

// LastActive 返回最后一次活动时间。
func (c *UserContainer) LastActive() time.Time {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.lastActive
}

// ReconcileOrphans 启动时对账：清理本服务遗留的孤儿容器。
//
// 场景：服务进程异常退出（崩溃、被 kill）后，daemon 里的容器仍在运行。
// 新进程的内存态是空的，GC 遍历不到这些容器，会永久泄漏并占满
// container_total_limit。因此启动时必须按标签清理一遍。
//
// 注意：这里**不能**保留容器——内存态（job 记录、代次）已丢失，
// 保留容器只会得到一个无主实例。清理是唯一自洽的选择。
func (e *Executor) ReconcileOrphans(ctx context.Context) (int, error) {
	ids, err := e.docker.listContainers(ctx)
	if err != nil {
		return 0, err
	}
	n := 0
	for _, id := range ids {
		if err := e.docker.remove(ctx, id); err != nil {
			log.Printf("[reconcile] 清理孤儿容器失败 cid=%s err=%v", id, err)
			continue
		}
		n++
	}
	return n, nil
}

// Snapshot 返回当前全部容器的快照（供 GC 遍历）。
func (e *Executor) Snapshot() []*UserContainer {
	e.mu.Lock()
	defer e.mu.Unlock()
	out := make([]*UserContainer, 0, len(e.containers))
	for _, c := range e.containers {
		out = append(out, c)
	}
	return out
}

// Destroy 销毁容器（回收动作）。调用方应已先写墓碑。
//
// 顺序：终止运行中 job → 移除容器 → 清除 /tmp 输出文件 → 清出容器表。
func (e *Executor) Destroy(ctx context.Context, c *UserContainer) error {
	// 终止该容器内所有运行中的 exec
	c.mu.Lock()
	for _, rp := range c.procs {
		rp.cancel()
	}
	procs := len(c.procs)
	c.procs = make(map[int]*runningProc)
	c.mu.Unlock()
	_ = procs

	if err := e.docker.remove(ctx, c.ContainerID); err != nil {
		log.Printf("[recycle] 移除容器失败 user=%s cid=%s err=%v", c.User, c.ContainerID, err)
	}
	// 撤销该用户的宿主侧出站规则
	e.ReleaseEgress(c.User)

	// /tmp 输出文件随容器销毁（这里是宿主机侧镜像目录，清空即可）
	cleanOutputFiles(c.tmpDir)

	e.mu.Lock()
	if cur, ok := e.containers[c.User]; ok && cur == c {
		delete(e.containers, c.User)
		if e.running > 0 {
			e.running--
		}
	}
	e.mu.Unlock()
	return nil
}

// ---------- 执行 ----------

// ExecRequest 一次命令执行请求。
type ExecRequest struct {
	User    string
	Cmd     string
	Timeout time.Duration
}

// StartResult 启动结果。
type StartResult struct {
	Job        *store.Job
	Generation int
	Done       chan struct{}
}

// Start 启动一条命令，不阻塞。结果由 supervise goroutine 写入 store。
func (e *Executor) Start(ctx context.Context, req ExecRequest) (*StartResult, error) {
	c, _, err := e.EnsureContainer(ctx, req.User)
	if err != nil {
		return nil, err
	}
	c.touch()

	// 磁盘预检（v4）：/exec 会通过 shell 直接改写 homeDir / tmpDir，
	// Write 路径的配额检查管不到它。因此在命令下发前做一次总占用预检，
	// 超限则直接拒绝，避免容器把宿主磁盘写满。
	//
	// 已知边界：这是**下发前**的检查，命令执行期间的增长（dd、pip install 等）
	// 无法实时拦截，只能在命令结束后由下一次预检生效。宿主机为 overlay2、
	// 无 XFS pquota，Docker StorageOpt 不可用，故采用此软配额方案（见 README）。
	//
	// 例外：判定为「清理类」的命令放行。否则一旦超限，连 rm 都会被拒，
	// 用户被永久锁死、无法自行恢复（这是实测发现的死锁）。
	if e.cfg.UserDiskMB > 0 && !isCleanupCmd(req.Cmd) {
		u := e.diskUsage(c)
		if u.Total > u.Limit {
			return nil, ErrDiskQuota
		}
	}

	job, err := e.st.NewJob(req.User)
	if err != nil {
		return nil, err
	}

	// 场景 B：容器总配额已满，无法创建输出文件 → unusable / output quota exceeded
	if !e.canAllocate(c, 0) {
		code := -1
		e.st.FinishJob(req.User, c.Generation, job.JobID, &store.Result{
			Outcome:    store.OutcomeUnusable,
			ExitCode:   &code,
			Signal:     nil,
			OutputHead: "",
			OutputFile: outputRelPath(job.JobID),
			Error:      store.ErrOutputQuotaExc,
			Truncated:  false,
		})
		done := make(chan struct{})
		close(done)
		return &StartResult{Job: job, Generation: c.Generation, Done: done}, nil
	}

	// 命令执行期间的上下文：timeout 到期则取消（服务侧终止容器内进程）
	rp := &runningProc{jobID: job.JobID, cancel: func() {}, done: make(chan struct{})}

	c.mu.Lock()
	c.procs[job.JobID] = rp
	c.mu.Unlock()

	// 说明：timeout 的计时与强制终止在 docker.execAndWait 内实现
	// （取消 exec 的 HTTP 流会断开连接，daemon 侧随之终止容器内进程）。

	go e.supervise(c, rp, job, req)

	return &StartResult{Job: job, Generation: c.Generation, Done: rp.done}, nil
}

// supervise 执行命令并处理结果。
//
// 落地要点：
//   - 输出先落在容器内 /tmp/.out_<jobid>（tmpfs），由容器内 shell 重定向产生（fd 重定向，非管道）
//   - 服务侧按 output_tmp_quota_mb 监控：写满则停止后续收集（truncated=true），但**不终止进程**
//   - 进程结束后（wait 返回）再取回输出，保证 output_head 是 output_file 的确定前缀
func (e *Executor) supervise(c *UserContainer, rp *runningProc, job *store.Job, req ExecRequest) {
	defer close(rp.done)

	quotaBytes := int64(e.cfg.OutputTmpQuotaMB) * 1024 * 1024
	outName := store.OutputFileName(job.JobID)

	// 命令本体。输出重定向由 docker 层包装时统一加上
	// （stdout/stderr → /tmp/.out_<jobid>，即文档要求的文件描述符重定向）。
	shCmd := fmt.Sprintf("cd /home/user && %s", req.Cmd)

	exitCode, sig, timedOut := e.docker.execAndWait(rp, c, shCmd, req.Timeout)

	// 关键时序保证（设计文档 5.1）：
	// exec 的 HTTP 流关闭不等于容器内进程已完全退出，此时立即读取可能读到空文件。
	// 因此在此处显式等待容器内该进程消失，确保 kernel 侧写入已完成，
	// 再读取输出文件 —— 这对应文档要求的"等待 waitpid 返回后再读取"。
	e.waitProcessGone(c, outName)

	// 进程已结束，可安全读取输出文件
	content, gotAll, err := e.readOutput(c, rp, outName, quotaBytes)

	truncated := !gotAll
	if truncated {
		rp.setTruncated()
	}

	head := e.buildHead(content, exitCode, truncated)
	binHit := content != nil && binaryHitBytes(content, e.cfg.BinaryCheckWindow, e.cfg.BinaryInvalidRatio)

	res := &store.Result{
		ExitCode:   exitCode,
		Signal:     sig,
		OutputHead: head,
		OutputFile: outputRelPath(job.JobID),
		Truncated:  truncated,
	}

	switch {
	case binHit:
		res.Outcome = store.OutcomeUnusable
		res.Error = store.ErrBinaryOutput
		res.OutputHead = ""
	case timedOut:
		res.Outcome = store.OutcomeUnusable
		res.Error = store.ErrTimeout
	default:
		res.Outcome = store.OutcomeOK
	}
	if err != nil && content == nil {
		res.Outcome = store.OutcomeUnusable
		res.Error = store.ErrOutputQuotaExc
	}

	e.st.FinishJob(c.User, c.Generation, job.JobID, res)

	c.mu.Lock()
	delete(c.procs, job.JobID)
	c.mu.Unlock()
}

// waitProcessGone 等待容器内该 job 的输出写入进程完全退出。
//
// 实现方式：轮询输出文件直到其可稳定读取（大小连续两次一致），
// 或超时兜底。配合 exec 的退出码查询，保证读到的是最终内容。
func (e *Executor) waitProcessGone(c *UserContainer, outName string) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	var lastSize int64 = -1
	stable := 0
	for {
		size, err := e.docker.fileSize(ctx, c.ContainerID, "/tmp/"+outName)
		if err == nil {
			if size == lastSize {
				stable++
				if stable >= 2 {
					return
				}
			} else {
				stable = 0
				lastSize = size
			}
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(20 * time.Millisecond):
		}
	}
}

// readOutput 从容器取回输出文件。
// 返回 (内容, 是否完整, error)。配额内的截断由 gotAll=false 表示。
func (e *Executor) readOutput(c *UserContainer, rp *runningProc, outName string, quotaBytes int64) ([]byte, bool, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	rc, err := e.docker.copyFromContainer(ctx, c.ContainerID, "/tmp/"+outName)
	if err != nil {
		// 文件不存在（命令未产生输出）→ 空文件，视为完整
		return []byte{}, true, nil
	}
	defer rc.Close()

	limited := io.LimitReader(rc, quotaBytes+1)
	data, err := io.ReadAll(limited)
	if err != nil {
		return data, false, err
	}
	if int64(len(data)) > quotaBytes {
		return data[:quotaBytes], false, nil
	}
	return data, true, nil
}

// outputRelPath 输出文件对外的相对路径：tmp/.out_<jobid>（设计文档 3.1）。
func outputRelPath(jobID int) string {
	return "tmp/" + store.OutputFileName(jobID)
}

// buildHead 按设计文档 5.2 计算摘要（前缀语义）。
func (e *Executor) buildHead(content []byte, exitCode *int, truncated bool) string {
	n := e.cfg.OutputHeadFallback
	if exitCode != nil && *exitCode == 0 && !truncated {
		n = e.cfg.OutputHeadBytes
	}
	if len(content) < n {
		n = len(content)
	}
	return sanitizeUTF8Prefix(content[:n])
}

// canAllocate 检查容器总输出配额是否还能分配 addBytes。
func (e *Executor) canAllocate(c *UserContainer, addBytes int64) bool {
	limit := int64(e.cfg.OutputTmpQuotaMB) * 1024 * 1024
	var used int64
	ents, err := os.ReadDir(c.tmpDir)
	if err != nil {
		return true
	}
	for _, ent := range ents {
		if info, err := ent.Info(); err == nil {
			used += info.Size()
		}
	}
	return used+addBytes <= limit
}

// ---------- 文件操作 ----------

// CatResult /cat 的结果。
type CatResult struct {
	Content      string
	HasMore      bool
	Size         int64
	Binary       bool
	IsOutputFile bool
	JobID        int
}

// Cat 读取用户文件或输出文件。
func (e *Executor) Cat(ctx context.Context, user, relPath string, offset, limit int64) (*CatResult, error) {
	c, _, err := e.EnsureContainer(ctx, user)
	if err != nil {
		return nil, err
	}
	c.touch()

	isOut, jobID, containerPath, err := resolvePath(relPath)
	if err != nil {
		return nil, err
	}

	// 从容器取回（走 docker cp）
	rc, err := e.docker.copyFromContainer(ctx, c.ContainerID, containerPath)
	if err != nil {
		return nil, os.ErrNotExist
	}
	defer rc.Close()
	data, err := io.ReadAll(io.LimitReader(rc, 64*1024*1024))
	if err != nil {
		return nil, err
	}
	size := int64(len(data))

	// 二进制判定：快速路径（窗口内完整判定）+ 全量 NUL 兜底
	if binaryHitBytes(data, e.cfg.BinaryCheckWindow, e.cfg.BinaryInvalidRatio) {
		return &CatResult{Binary: true, IsOutputFile: isOut, JobID: jobID, Size: size}, nil
	}

	if offset < 0 {
		offset = 0
	}
	if limit <= 0 {
		limit = e.cfg.CatMaxBytes
	}
	if offset >= size {
		return &CatResult{Content: "", HasMore: false, Size: size, IsOutputFile: isOut, JobID: jobID}, nil
	}
	remain := size - offset
	take := remain
	if limit > 0 && limit < remain {
		take = limit
	}
	chunk := data[offset : offset+take]
	return &CatResult{
		Content:      sanitizeUTF8Prefix(chunk),
		HasMore:      offset+take < size,
		Size:         size,
		IsOutputFile: isOut,
		JobID:        jobID,
	}, nil
}

// Write 写入用户文件（整体替换，临时文件 + rename）。
func (e *Executor) Write(ctx context.Context, user, relPath string, content []byte) error {
	c, _, err := e.EnsureContainer(ctx, user)
	if err != nil {
		return err
	}
	c.touch()

	isOut, _, _, err := resolvePath(relPath)
	if err != nil {
		return err
	}
	if isOut {
		return ErrInvalidArgument // 保留路径 tmp/.out_* 不可写
	}

	clean := filepath.Clean(relPath)
	containerPath := "/home/user/" + filepath.ToSlash(clean)

	// 目录检查
	if kind, err := e.docker.statPath(ctx, c.ContainerID, containerPath); err == nil {
		if kind == pathDir {
			return ErrIsDirectory
		}
	}
	// 父目录必须存在
	parent := filepath.ToSlash(filepath.Dir(containerPath))
	if kind, err := e.docker.statPath(ctx, c.ContainerID, parent); err != nil || kind != pathDir {
		return os.ErrNotExist
	}

	// 磁盘配额（user_disk_mb）：homeDir + tmpDir 合计，覆盖写时扣除原文件
	if !e.withinDiskQuota(ctx, c, containerPath, int64(len(content))) {
		return ErrDiskQuota
	}

	// 临时文件 + rename，失败不留中间状态
	tmpPath := containerPath + ".tmp"
	if err := e.docker.writeFile(ctx, c.ContainerID, tmpPath, content); err != nil {
		return err
	}
	if _, err := e.docker.execSimple(ctx, c.ContainerID, fmt.Sprintf("mv -f %s %s", shq(tmpPath), shq(containerPath))); err != nil {
		e.docker.execSimple(context.Background(), c.ContainerID, "rm -f "+shq(tmpPath))
		return err
	}
	return nil
}

// Ls 列出目录当前层。
func (e *Executor) Ls(ctx context.Context, user, relPath string) (dirs, files []string, err error) {
	c, _, err := e.EnsureContainer(ctx, user)
	if err != nil {
		return nil, nil, err
	}
	c.touch()

	isOut, _, containerPath, rerr := resolvePath(relPath)
	if rerr != nil {
		return nil, nil, rerr
	}
	if isOut {
		containerPath = "/tmp"
	}
	if containerPath == "" {
		containerPath = "/home/user"
	}

	out, err := e.docker.execSimple(ctx, c.ContainerID,
		fmt.Sprintf("ls -1p %s", shq(containerPath)))
	if err != nil {
		return nil, nil, os.ErrNotExist
	}
	dirs, files = []string{}, []string{}
	for _, line := range strings.Split(out, "\n") {
		line = strings.TrimRight(line, "\r")
		if line == "" {
			continue
		}
		if strings.HasSuffix(line, "/") {
			dirs = append(dirs, strings.TrimSuffix(line, "/"))
		} else {
			files = append(files, line)
		}
	}
	sortStrings(dirs)
	sortStrings(files)
	return dirs, files, nil
}

// DiskUsage 用户磁盘用量明细（宿主机侧统计，单位字节）。
type DiskUsage struct {
	Home  int64 // /home/user 持久卷
	Tmp   int64 // /tmp 易失工作区（含输出文件）
	Total int64 // 合计
	Limit int64 // 预算上限（user_disk_mb）
}

// diskUsage 统计该用户 homeDir + tmpDir 的合计占用。
//
// 说明：这是**宿主机侧**统计，与容器内看到的 /home/user 和 /tmp 是同一份数据
// （两处均为 bind mount 挂载宿主机目录），因此无需进入容器即可精确测量。
// 目录遍历失败不视为超限（返回已统计部分），避免因瞬时错误误杀正常请求。
func (e *Executor) diskUsage(c *UserContainer) DiskUsage {
	limit := int64(e.cfg.UserDiskMB) * 1024 * 1024
	home := dirSize(c.homeDir)
	tmp := dirSize(c.tmpDir)
	return DiskUsage{Home: home, Tmp: tmp, Total: home + tmp, Limit: limit}
}

// dirSize 递归统计目录内所有普通文件大小；符号链接与目录本身不计。
func dirSize(root string) int64 {
	var total int64
	_ = filepath.Walk(root, func(_ string, info os.FileInfo, err error) error {
		if err != nil || info == nil {
			return nil
		}
		if info.Mode().IsRegular() {
			total += info.Size()
		}
		return nil
	})
	return total
}

// withinDiskQuota 检查 user_disk_mb 配额是否可以再写入 addBytes。
//
// v4 修订：配额口径从「仅 /home/user」扩展为「/home/user + /tmp 合计」，
// 与 16G 的磁盘预算对齐。
//
//   - 旧实现只统计 homeDir，而 /tmp 下可能堆积大量输出文件，实际磁盘占用被低估
//   - 旧实现仅被 Write 调用，/exec 完全绕过配额（dd / pip install 不受约束）
//
// replacePath 为容器内路径：若是覆盖写已有文件，则扣除该文件原有大小，避免重复计算。
// 传空串表示纯新增用途（如 /exec 的预检）。
func (e *Executor) withinDiskQuota(ctx context.Context, c *UserContainer, replacePath string, addBytes int64) bool {
	if e.cfg.UserDiskMB <= 0 {
		return true
	}
	u := e.diskUsage(c)
	if replacePath != "" {
		u.Total -= hostPathSize(c, replacePath)
	}
	return u.Total+addBytes <= u.Limit
}

// hostPathSize 把容器内路径映射回宿主机路径并取文件大小；不存在返回 0。
func hostPathSize(c *UserContainer, containerPath string) int64 {
	var host string
	switch {
	case strings.HasPrefix(containerPath, "/home/user/"):
		host = filepath.Join(c.homeDir, strings.TrimPrefix(containerPath, "/home/user/"))
	case containerPath == "/home/user":
		return 0
	case strings.HasPrefix(containerPath, "/tmp/"):
		host = filepath.Join(c.tmpDir, strings.TrimPrefix(containerPath, "/tmp/"))
	default:
		return 0
	}
	if st, err := os.Stat(host); err == nil && st.Mode().IsRegular() {
		return st.Size()
	}
	return 0
}

// ---------- 路径解析与越权防护 ----------

var (
	ErrInvalidArgument = fmt.Errorf("invalid argument")
	ErrIsDirectory     = fmt.Errorf("target is a directory")
)

// ErrDiskQuota 表示用户磁盘预算已用尽。
var ErrDiskQuota = fmt.Errorf("disk quota exceeded")

// cleanupCmds 是「清理磁盘」的常用命令前缀白名单。
//
// 为什么需要它：配额预检会拦下**所有** /exec。若不做例外，一旦用户把磁盘写满，
// 连 `rm` 都会被 507 拒绝，形成死锁 —— 用户无法自行恢复，只能等服务端回收容器。
// 因此对明确的删除类命令放行（它们不增加占用，只会释放）。
//
// 注意这是**前缀匹配**，看的是命令开头；不追求完备，只覆盖最常见的清理动作。
// 风险可控：即便有人用 `rm` 之外的手段写文件，预检仍会在下一次生效。
var cleanupCmds = []string{
	"rm ", "rm\t", "rmdir ", "unlink ", "shred ",
	"find ", // find ... -delete / -exec rm 常见于此
	"truncate ", "dd if=/dev/null",
}

// isCleanupCmd 判断命令是否属于清理类（放行配额预检）。
func isCleanupCmd(cmd string) bool {
	s := strings.TrimLeft(cmd, " \t")
	// 跳过前缀的 env 赋值与常见包装，尽量识别真实的命令头
	for {
		switch {
		case strings.HasPrefix(s, "sudo "):
			s = strings.TrimLeft(s[5:], " \t")
			continue
		case strings.HasPrefix(s, "command "):
			s = strings.TrimLeft(s[8:], " \t")
			continue
		case strings.HasPrefix(s, "exec "):
			s = strings.TrimLeft(s[5:], " \t")
			continue
		}
		break
	}
	for _, p := range cleanupCmds {
		if strings.HasPrefix(s, p) || s == strings.TrimSpace(p) {
			return true
		}
	}
	return false
}

// resolvePath 把相对路径解析为容器内绝对路径，并做越权防护（设计文档 8）。
// 返回 (是否输出文件, jobID, 容器内绝对路径, error)。
func resolvePath(rel string) (bool, int, string, error) {
	if rel == "" {
		rel = "."
	}
	if strings.HasPrefix(rel, "/") {
		return false, 0, "", ErrInvalidArgument
	}
	clean := filepath.Clean(rel)
	if clean == ".." || strings.HasPrefix(clean, ".."+string(filepath.Separator)) {
		return false, 0, "", ErrInvalidArgument
	}
	clean = filepath.ToSlash(clean)

	// 输出文件：tmp/.out_<jobid> → 容器内 /tmp
	if clean == "tmp" {
		return false, 0, "/tmp", nil
	}
	if strings.HasPrefix(clean, "tmp/") {
		rest := strings.TrimPrefix(clean, "tmp/")
		base := pathBase(rest)
		jobID := 0
		isOut := strings.HasPrefix(base, ".out_")
		if isOut {
			jobID = atoiSafe(strings.TrimPrefix(base, ".out_"))
		}
		return isOut, jobID, "/tmp/" + rest, nil
	}
	return false, 0, "/home/user/" + clean, nil
}

func pathBase(p string) string {
	p = strings.TrimSuffix(p, "/")
	if i := strings.LastIndex(p, "/"); i >= 0 {
		return p[i+1:]
	}
	return p
}

// shq shell 单引号转义。
func shq(s string) string {
	return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'"
}

func sortStrings(s []string) {
	for i := 1; i < len(s); i++ {
		for j := i; j > 0 && s[j] < s[j-1]; j-- {
			s[j], s[j-1] = s[j-1], s[j]
		}
	}
}

func atoiSafe(s string) int {
	n := 0
	for _, r := range s {
		if r < '0' || r > '9' {
			return 0
		}
		n = n*10 + int(r-'0')
		if n > 1<<31-1 {
			return 0
		}
	}
	return n
}

// cleanOutputFiles 清空 tmpDir 下的 .out_* 文件。
func cleanOutputFiles(tmpDir string) {
	ents, err := os.ReadDir(tmpDir)
	if err != nil {
		return
	}
	for _, ent := range ents {
		if strings.HasPrefix(ent.Name(), ".out_") {
			_ = os.Remove(filepath.Join(tmpDir, ent.Name()))
		}
	}
}

// ---------- tar 辅助（docker cp 需要 tar 流） ----------

func tarSingleFile(name string, content []byte) (io.Reader, error) {
	var buf bytes.Buffer
	tw := tar.NewWriter(&buf)
	hdr := &tar.Header{
		Name: filepath.Base(name),
		Mode: 0o644,
		Size: int64(len(content)),
	}
	if err := tw.WriteHeader(hdr); err != nil {
		return nil, err
	}
	if _, err := tw.Write(content); err != nil {
		return nil, err
	}
	if err := tw.Close(); err != nil {
		return nil, err
	}
	return &buf, nil
}

var _ = exec.Command
