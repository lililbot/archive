#!/bin/bash
# 启动脚本（v4）。
#
# 关键点：
#   - 监听 $PORT（平台注入），绑定 0.0.0.0
#   - 基础镜像已预拉取，容器冷启动很快
#   - 持久卷放在沙箱本地目录，容器回收后保留
#   - 容器出站受控：禁内网/元数据，公网自由（宿主侧 iptables，需 NET_ADMIN）
set -e

: "${PORT:=3000}"

export SBX_LISTEN_ADDR="0.0.0.0:${PORT}"
export SBX_USER_ALLOWLIST="${SBX_USER_ALLOWLIST:-alice,bob,demo}"
export SBX_HOME_VOLUME_ROOT="${SBX_HOME_VOLUME_ROOT:-/tmp/sandbox-exec-home}"
export SBX_BASE_IMAGE="${SBX_BASE_IMAGE:-alpine:3.19}"

# ---- v4 资源限制：4G内存 / 16G磁盘 / 双核 ----
export SBX_CONTAINER_MEMORY_MB="${SBX_CONTAINER_MEMORY_MB:-4096}"
export SBX_CONTAINER_CPU="${SBX_CONTAINER_CPU:-2}"
export SBX_USER_DISK_MB="${SBX_USER_DISK_MB:-16384}"
# 单次输出上限（非磁盘配额）；必须 < user_disk_mb
export SBX_OUTPUT_TMP_QUOTA_MB="${SBX_OUTPUT_TMP_QUOTA_MB:-1024}"

# ---- v4 容器出站管控 ----
# 普通用户仅 GET；容器需自行联网装包，故放开出站，但屏蔽内网与云元数据。
export SBX_DOCKER_NETWORK="${SBX_DOCKER_NETWORK:-sandbox-egress}"
export SBX_EGRESS_SUBNET_BASE="${SBX_EGRESS_SUBNET_BASE:-172.20.0.0/16}"
export SBX_APK_MIRROR="${SBX_APK_MIRROR:-mirrors.aliyun.com}"
# 出站规则需要宿主侧 iptables（CAP_NET_ADMIN）。无权限的环境可置 false 降级，
# 此时容器将可访问内网 —— 安全性由调用侧 user 白名单兜底。
export SBX_EGRESS_ENFORCE_HOST="${SBX_EGRESS_ENFORCE_HOST:-true}"

# ---- 演示环境参数 ----
export SBX_PER_USER_MAX_JOBS="${SBX_PER_USER_MAX_JOBS:-16}"
export SBX_CONTAINER_TOTAL_LIMIT="${SBX_CONTAINER_TOTAL_LIMIT:-8}"
export SBX_GC_IDLE_CONTAINER_S="${SBX_GC_IDLE_CONTAINER_S:-600}"
export SBX_GC_SCAN_INTERVAL_S="${SBX_GC_SCAN_INTERVAL_S:-60}"
export SBX_TIMEOUT_MAX_S="${SBX_TIMEOUT_MAX_S:-60}"
export SBX_EXEC_SYNC_WAIT_S="${SBX_EXEC_SYNC_WAIT_S:-10}"

mkdir -p "$SBX_HOME_VOLUME_ROOT"

exec /workspace/sandbox-exec/bin/sandbox-exec
