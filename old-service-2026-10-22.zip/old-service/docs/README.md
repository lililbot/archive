# 沙箱代码执行服务 · 使用文档

在隔离 Linux 容器中执行 bash 命令、读写文件、自助联网装包的服务。
全部接口为 `GET`，响应 JSON。

## 目录

| 文件 | 内容 |
|---|---|
| `api.md` | 接口契约：参数、响应、错误码 |
| `encoding.md` | 百分号编码规则与构造 URL 的方法 |
| `examples.md` | 可直接复制的调用示例 |
| `FAQ.md` | 常见问题与错误排查 |
| `limits.md` | 能力边界与限制 |

## 快速开始

```bash
U=http://127.0.0.1:8099

# 健康检查
curl "$U/healthz"

# 执行命令
curl -G "$U/exec" --data-urlencode 'user=alice' \
  --data-urlencode 'cmd=echo hello' --data-urlencode 'timeout_s=30'

# 写文件
curl -G "$U/write" --data-urlencode 'user=alice' \
  --data-urlencode 'path=note.txt' --data-urlencode 'content=hi'

# 读文件
curl "$U/cat?user=alice&path=note.txt"

# 列目录
curl "$U/ls?user=alice"
```

> 构造 URL 请始终使用 `--data-urlencode` 或等价的编码函数，
> **不要手工拼接**。详见 `encoding.md`。
