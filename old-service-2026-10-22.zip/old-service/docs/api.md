# api.md — 接口契约

基址示例：`http://127.0.0.1:8099`

全部接口为 `GET`，响应 `application/json; charset=utf-8`，统一带 `Cache-Control: no-store`。

## 通用约定

### 参数 `user`

必填。格式 `^[A-Za-z0-9_-]{1,64}$`，且必须在服务端白名单内。

### 参数白名单

每个接口的参数表是**严格**的：出现任何未列出的查询参数即返回 `400`。

### 参数别名

同一语义可用多个参数名，语义完全等价：

| 语义 | 可用参数名 |
|---|---|
| 命令 | `cmd` / `q` / `command` |
| 超时 | `timeout_s` / `timeout` |
| 路径 | `path` / `p` |
| 单次读取上限 | `max_bytes` / `limit` |
| 写入内容 | `content` / `text` / `d` |

### 编码

所有参数须经百分号编码，规则见 `encoding.md`。

---

## `GET /exec` — 提交命令

执行命令，同步等待至多 `exec_sync_wait_s`；未完成则返回 `pending`，后续用 `/status` 轮询。

### 参数

| 参数 | 必填 | 类型 | 约束 |
|---|---|---|---|
| `user` | ✅ | string | 见上 |
| `cmd` | ✅ | string | 非空，命令原文 |
| `timeout_s` | ✅ | float | `0 < t ≤ 60`（默认部署） |

### 响应 `200`

已完成：

```json
{
  "state": "finished",
  "job_id": 1,
  "result": {
    "outcome": "ok",
    "exit_code": 0,
    "signal": null,
    "output_head": "hello\n",
    "output_file": "tmp/.out_1",
    "truncated": false
  }
}
```

用户同步等待内未完成：

```json
{ "job_id": 2, "state": "pending" }
```

### 说明

- 客户端断开连接时，**job 继续在后台运行**，不返回响应
- 部分成功场景（如超时）会带 `piggyback` 字段，见下文

---

## `GET /status` — 查询 job 状态

### 参数

| 参数 | 必填 | 约束 |
|---|---|---|
| `user` | ✅ | 见上 |
| `job_id` | ✅ | 十进制整数，`1 ≤ id ≤ 2^31-1` |

### 响应 `200`

已完成：

```json
{
  "state": "finished",
  "job_id": 1,
  "result": { "...": "同上" }
}
```

容器已回收：

```json
{ "state": "recycled", "job_id": 1, "error": "container recycled" }
```

> 容器回收后返回 **`200` + `recycled`**，而非 `404`。
> `404` 仅表示该 `job_id` 从未存在。

> `/status` **不附带** `piggyback`。

---

## `GET /cat` — 读文件

### 参数

| 参数 | 必填 | 类型 | 约束 |
|---|---|---|---|
| `user` | ✅ | string | 见上 |
| `path` | ✅ | string | 相对路径 |
| `offset` | ❌ | int | `≥ 0` |
| `limit` | ❌ | int | `≥ 1`；缺省用 `cat_max_bytes` |

### 响应 `200`

```json
{ "ok": true, "content": "文件内容", "has_more": false, "size": 12 }
```

| 字段 | 含义 |
|---|---|
| `content` | 本次返回的内容 |
| `has_more` | 是否还有未返回的内容（分页用） |
| `size` | 文件总字节数 |

内容为二进制时：

```json
{ "ok": false, "error": "binary output" }
```

若 `path` 指向输出文件（`tmp/.out_<job_id>`）且内容为二进制，
返回该 job 的结果结构并附 `note` 说明（**不改动** `/status` 中已发布的 `outcome`）。

### 路径规则

见 `examples.md` 的路径小节。仅接受相对路径，`..` 逃逸与绝对路径一律 `400`。

---

## `GET /write` — 写文件

整体替换目标文件。

### 参数

| 参数 | 必填 | 约束 |
|---|---|---|
| `user` | ✅ | 见上 |
| `path` | ✅ | 相对路径；父目录须已存在 |
| `content` | ✅ | 可省略（写空文件）；上限 `content_max_bytes` |

### 响应 `200`

```json
{ "ok": true, "path": "note.txt" }
```

### 限制

- 保留路径 `tmp/.out_*` 不可写（`400`）
- 目标为目录 → `409`
- 父目录不存在 → `404`
- 内容超限 → `413`
- 磁盘配额不足 → `507`

> 单次可写内容受 URL 长度限制，实际约 2 KB。大文件请用 `/exec`，
> 见 `limits.md`。

---

## `GET /ls` — 列目录

### 参数

| 参数 | 必填 | 约束 |
|---|---|---|
| `user` | ✅ | 见上 |
| `path` | ❌ | 相对路径；缺省为 `/home/user` |

### 响应 `200`

```json
{ "ok": true, "dir": ["sub"], "file": ["a.txt", "b.sh"] }
```

`dir` 与 `file` 均为当前层条目名，按升序排列。

---

## `GET /healthz` — 健康检查

```json
{ "ok": true, "docker": true }
```

`docker` 表示 Docker daemon 是否可用。

---

## 错误码

| 码 | `error` | 触发条件 |
|---|---|---|
| 400 | `invalid argument` | 参数缺失/格式错/越界/未预期；**编码不合规** |
| 403 | `user not allowed` | `user` 格式合法但不在白名单 |
| 404 | `not found` | 文件或 job 不存在 |
| 409 | `target is a directory` | 写入目标为目录 |
| 413 | `content too large` | 写入内容超过 `content_max_bytes` |
| 429 | `too many jobs` | 该 user 的 pending 数达上限 |
| 503 | `no capacity` | 全局容器数达上限 |
| 507 | `disk quota exceeded` | 磁盘用量达上限 |
| 500 | `internal error` | 内部异常 |

响应体统一为：

```json
{ "error": "invalid argument" }
```

### 关于 507

磁盘配额在**命令下发前**检查。超限后普通命令会被拒，
但**清理类命令仍然放行**（`rm`、`rmdir`、`unlink`、`shred`、`find`、`truncate` 等）。

自救方式：

```
/exec?user=alice&cmd=rm -rf <大文件>
```

清理后配额自动恢复。

---

## `result` 字段

| 字段 | 说明 |
|---|---|
| `outcome` | `ok` 或 `unusable` |
| `exit_code` | 进程退出码；无法取得时为 `null` |
| `signal` | 终止信号名；非信号终止时为 `null` |
| `output_head` | 输出前缀（可能被截断） |
| `output_file` | 完整输出的相对路径，可用 `/cat` 读取 |
| `truncated` | 是否因输出配额被截断 |
| `error` | `outcome` 为 `unusable` 时的原因 |

### `outcome` 为 `ok` 不等于命令成功

`exit_code` 非零仍属 `ok`——它表示"进程正常结束"。
**务必同时检查 `exit_code`**：

- `127`：命令不存在
- `126`：无执行权限

### `unusable` 的三种原因

| `error` | 含义 |
|---|---|
| `timeout` | 超过 `timeout` 未结束 |
| `binary output` | 输出判定为二进制 |
| `output quota exceeded` | 输出超过单 job 上限 |

---

## `piggyback` 字段

`/exec`、`/write`、`/cat`、`/ls` 的响应中可能附带该 user **尚未投递**的 job 摘要：

```json
{
  "...": "接口自己的字段",
  "piggyback": [
    { "job_id": 7, "state": "finished", "result": { "...": "..." } }
  ]
}
```

| 项 | 规则 |
|---|---|
| 不附加于 | `/status` |
| 条目上限 | 20 |
| 排序 | `job_id` 升序 |
| `output_head` | 比正常值更短（512 字节） |
| 投递即标记已读 | 不再出现在后续 `piggyback` |

若要看某个 job 的**完整** `output_head`，用 `/status`。
