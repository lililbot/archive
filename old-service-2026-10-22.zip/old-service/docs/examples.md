# examples.md — 调用示例

所有示例假设 `U=http://127.0.0.1:8099`，`user=alice` 在白名单内。

均使用 `--data-urlencode` 让 curl 负责编码，避免手工编码出错。

## 执行命令

### 基本

```bash
curl -G "$U/exec" --data-urlencode 'user=alice' \
  --data-urlencode 'cmd=echo hello' --data-urlencode 'timeout_s=30'
```

### 组合命令

```bash
curl -G "$U/exec" --data-urlencode 'user=alice' \
  --data-urlencode 'cmd=mkdir -p src && cd src && echo ok > a.txt && ls -l' \
  --data-urlencode 'timeout_s=30'
```

### 长任务（转 pending）

```bash
curl -G "$U/exec" --data-urlencode 'user=alice' \
  --data-urlencode 'cmd=sleep 60' --data-urlencode 'timeout_s=30'
# → {"job_id":2,"state":"pending"}

curl "$U/status?user=alice&job_id=2"
```

### 安装软件包

容器内已预配可达的镜像源，可直接安装：

```bash
curl -G "$U/exec" --data-urlencode 'user=alice' \
  --data-urlencode 'cmd=apk add --no-cache curl jq' \
  --data-urlencode 'timeout_s=120'
```

```bash
curl -G "$U/exec" --data-urlencode 'user=alice' \
  --data-urlencode 'cmd=apk add --no-cache python3 py3-pip && pip3 install requests' \
  --data-urlencode 'timeout_s=180'
```

### 访问网络

```bash
curl -G "$U/exec" --data-urlencode 'user=alice' \
  --data-urlencode 'cmd=curl -s https://mirrors.aliyun.com/ | head -c 200' \
  --data-urlencode 'timeout_s=60'
```

内网与云元数据地址被禁止访问（连接会被拒绝）。

### 读取完整输出

`output_head` 可能被截断。完整内容用 `/cat` 读输出文件：

```bash
curl "$U/cat?user=alice&path=tmp/.out_1"
```

分页读取：

```bash
curl "$U/cat?user=alice&path=tmp/.out_1&offset=0&limit=4096"
```

## 文件操作

### 写文件

```bash
curl -G "$U/write" --data-urlencode 'user=alice' \
  --data-urlencode 'path=note.txt' --data-urlencode 'content=hello world'
```

### 写大文件（用 /exec）

单次 `/write` 受 URL 长度限制，**约 2 KB**。更大内容用 `/exec`：

```bash
curl -G "$U/exec" --data-urlencode 'user=alice' \
  --data-urlencode 'cmd=cat > big.txt <<'"'"'EOF'"'"'
第一行
第二行
...
EOF' --data-urlencode 'timeout_s=30'
```

或用 base64 传二进制：

```bash
B64=$(base64 -w0 local.bin)
curl -G "$U/exec" --data-urlencode 'user=alice' \
  --data-urlencode "cmd=echo '$B64' | base64 -d > remote.bin && ls -l remote.bin" \
  --data-urlencode 'timeout_s=30'
```

### 读文件

```bash
curl "$U/cat?user=alice&path=note.txt"
```

### 列目录

```bash
curl "$U/ls?user=alice"
curl "$U/ls?user=alice&path=src"
curl "$U/ls?user=alice&path=tmp"
```

## 路径规则

| 写法 | 解析为 |
|---|---|
| `note.txt` | `/home/user/note.txt` |
| `sub/a.txt` | `/home/user/sub/a.txt` |
| `sub/` | `/home/user/sub` |
| `tmp` | `/tmp` |
| `tmp/.out_3` | `/tmp/.out_3`（某 job 的完整输出） |
| `.` 或省略 | `/home/user` |

**一律拒绝**：绝对路径（`/etc/passwd`）、`..` 逃逸（`../evil`）、`a/../../b`。

**保留路径**：`tmp/.out_*` 不可经 `/write` 写入。

## 完整工作流示例

```bash
U=http://127.0.0.1:8099

# 1. 写一个脚本
curl -G "$U/write" --data-urlencode 'user=alice' \
  --data-urlencode 'path=hello.py' \
  --data-urlencode 'content=print("hello from container")'

# 2. 装 Python
curl -G "$U/exec" --data-urlencode 'user=alice' \
  --data-urlencode 'cmd=apk add --no-cache python3' \
  --data-urlencode 'timeout_s=120'

# 3. 运行
curl -G "$U/exec" --data-urlencode 'user=alice' \
  --data-urlencode 'cmd=python3 hello.py' --data-urlencode 'timeout_s=30'

# 4. 确认文件在
curl "$U/ls?user=alice"
```

## curl 技巧

显式 GET 加参数时用 `-G` 让 `--data-urlencode` 拼进查询串：

```bash
# 正确
curl -G "$U/exec" --data-urlencode 'user=alice' --data-urlencode 'cmd=echo hi' --data-urlencode 'timeout_s=30'

# 错误：--data-urlencode 默认发 POST body，不带 -G 会变成 POST
curl "$U/exec" --data-urlencode 'user=alice'
```

只想知道 HTTP 状态码：

```bash
curl -s -o /dev/null -w '%{http_code}\n' "$U/healthz"
```

查看响应头：

```bash
curl -sI "$U/healthz"
```
