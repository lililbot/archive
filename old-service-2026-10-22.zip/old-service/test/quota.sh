#!/bin/bash
# 磁盘配额专项测试（v4）。
#
# 为什么单独一个脚本：user_disk_mb 是**启动时**读取的配置，无法在运行中改小。
# 要验证「超限 → 507」必须用一个小配额实例另起一份服务。
#
# 用法：bash test/quota.sh [端口] [磁盘MB]
# 前置：已构建 bin/sandbox-exec
set -u
PORT=${1:-8097}
DISK_MB=${2:-3}
B="http://127.0.0.1:${PORT}"
ROOT=/tmp/sbx-quota-test
PASS=0; FAIL=0

chk() { # chk <描述> <实际> <期望子串>
  if echo "$2" | grep -qF "$3"; then
    echo "  [PASS] $1"; PASS=$((PASS+1))
  else
    echo "  [FAIL] $1"; echo "         期望包含: $3"; echo "         实际: $2"; FAIL=$((FAIL+1))
  fi
}
chkcode() { # chkcode <描述> <url> <期望码>
  code=$(curl -s -o /dev/null -w '%{http_code}' "$2")
  if [ "$code" = "$3" ]; then
    echo "  [PASS] $1 (HTTP $code)"; PASS=$((PASS+1))
  else
    echo "  [FAIL] $1 期望 HTTP $3，实际 $code"; FAIL=$((FAIL+1))
  fi
}

BIN=$(dirname "$0")/../bin/sandbox-exec
[ -x "$BIN" ] || { echo "请先构建：go build -o bin/sandbox-exec ./cmd/server"; exit 1; }

# 预检：停止可能占用端口的旧实例（按端口精确定位，避免误杀）
if command -v fuser >/dev/null 2>&1; then
  fuser -k "${PORT}/tcp" 2>/dev/null
  sleep 1
fi

rm -rf "$ROOT"; mkdir -p "$ROOT"
# output_tmp_quota_mb 必须 < user_disk_mb（配置校验要求）
TMPQ=$(( DISK_MB > 1 ? DISK_MB - 1 : 1 ))
env SBX_LISTEN_ADDR="0.0.0.0:${PORT}" \
    SBX_USER_ALLOWLIST=demo \
    SBX_HOME_VOLUME_ROOT="$ROOT" \
    SBX_USER_DISK_MB="$DISK_MB" \
    SBX_OUTPUT_TMP_QUOTA_MB="$TMPQ" \
    SBX_TIMEOUT_MAX_S=60 \
    SBX_EGRESS_ENFORCE_HOST=false \
    "$BIN" > /tmp/sbx-quota.log 2>&1 &
SRV=$!
trap 'kill $SRV 2>/dev/null' EXIT

# 等待就绪
for _ in $(seq 1 30); do
  curl -s -m 1 "$B/healthz" >/dev/null 2>&1 && break
  sleep 0.5
done
if ! curl -s -m 2 "$B/healthz" >/dev/null 2>&1; then
  echo "服务未能启动，日志："; cat /tmp/sbx-quota.log; exit 1
fi

echo "=== 磁盘配额测试（user_disk_mb=${DISK_MB}MB，端口 ${PORT}）==="

# 写约 80% 预算（用 dd 走 /exec —— 这正是旧版本绕开配额的路径）
KB=$(( DISK_MB * 1024 * 80 / 100 ))
chkcode "写入 ${KB}KB（预算内）→ 200" \
  "$B/exec?user=demo&cmd=dd%20if%3D%2Fdev%2Fzero%20of%3Df.bin%20bs%3D1K%20count%3D${KB}%202%3E%2Fdev%2Fnull&timeout=60" 200

chkcode "预算内普通命令 → 200" "$B/exec?user=demo&cmd=echo%20hi&timeout=30" 200

# 撑过预算
chkcode "再写 ${KB}KB（超出预算）→ 由 /exec 执行" \
  "$B/exec?user=demo&cmd=dd%20if%3D%2Fdev%2Fzero%20of%3Dg.bin%20bs%3D1K%20count%3D${KB}%202%3E%2Fdev%2Fnull&timeout=60" 200

echo "  -- 关键断言：/exec 也被配额约束（旧版本此处完全绕过）--"
chkcode "超限后普通命令 → 507" "$B/exec?user=demo&cmd=echo%20hi&timeout=30" 507

echo "  -- 死锁防护：超限时清理类命令仍须放行，否则用户被永久锁死 --"
r=$(curl -s "$B/exec?user=demo&cmd=rm%20-f%20g.bin%3B%20echo%20cleaned&timeout=30")
chk "超限时 rm 被放行" "$r" 'cleaned'
chkcode "清理后普通命令恢复 → 200" "$B/exec?user=demo&cmd=echo%20ok&timeout=30" 200

# /write 也纳入同一预算。
# 注意：不能用 shell 传大 body（会触发 "Argument list too long"），
# 改用 python 发请求。
WCODE=$(python3 - "$B" "$DISK_MB" <<'PY'
import sys, urllib.request, urllib.parse, urllib.error
base, mb = sys.argv[1], int(sys.argv[2])
# 故意超过 content_max_bytes 与磁盘预算
body = "B" * (mb * 1024 * 1024)
url = base + "/write?user=demo&path=z.txt&content=" + urllib.parse.quote(body, safe="")
try:
    r = urllib.request.urlopen(url, timeout=60)
    print(r.status)
except urllib.error.HTTPError as e:
    print(e.code)
except Exception as e:
    print("ERR:" + str(e))
PY
)
# 可接受的拒绝码：
#   507 = 磁盘配额超限（本服务返回）
#   413 = 单次内容超过 content_max_bytes（本服务返回）
#   431 = 请求头/URL 过长，在到达业务逻辑前就被 HTTP 层拒绝 —— 同样是"被拒"，
#         对大 body 而言这是正常的传输层边界，不是缺陷。
case "$WCODE" in
  507|413|431)
    echo "  [PASS] /write 超预算被拒 (HTTP $WCODE)"; PASS=$((PASS+1));;
  *)
    echo "  [FAIL] /write 超预算应被拒，实际 HTTP $WCODE"; FAIL=$((FAIL+1));;
esac

# 追加：处于超限态时，一个「小额」/write 也必须走 507 分支
# （证明拦截来自磁盘配额，而不是 content_max_bytes / URL 长度）
r=$(curl -s "$B/exec?user=demo&cmd=echo%20probe&timeout=30")
if echo "$r" | grep -q '"error":"disk quota exceeded"'; then
  r=$(curl -s "$B/write?user=demo&path=small.txt&content=hello")
  chk "超限态下小额 /write 走 507 分支" "$r" 'disk quota exceeded'
else
  echo "  [SKIP] 当前未处于超限态，跳过 507 分支断言"
fi

echo
echo "======================================"
echo "PASS=$PASS  FAIL=$FAIL"
[ "$FAIL" -eq 0 ] && echo "全部通过" || echo "存在失败项"
[ "$FAIL" -eq 0 ] || exit 1
