#!/bin/bash
# 端到端验收测试。覆盖《设计文档》《工程文档》v3 的主要条款。
B=${B:-http://127.0.0.1:8099}
PASS=0; FAIL=0

chk() { # chk <描述> <实际> <期望子串>
  if echo "$2" | grep -qF "$3"; then
    echo "  [PASS] $1"; PASS=$((PASS+1))
  else
    echo "  [FAIL] $1"; echo "         期望包含: $3"; echo "         实际: $2"; FAIL=$((FAIL+1))
  fi
}
chkcode() { # chkcode <描述> <url> <期望HTTP码>
  code=$(curl -s -o /tmp/_body -w '%{http_code}' "$2")
  if [ "$code" = "$3" ]; then
    echo "  [PASS] $1 (HTTP $code)"; PASS=$((PASS+1))
  else
    echo "  [FAIL] $1 期望 HTTP $3，实际 $code  体=$(cat /tmp/_body)"; FAIL=$((FAIL+1))
  fi
}

echo "=== A. 两层状态模型 ==="
r=$(curl -s "$B/exec?user=alice&cmd=true&timeout=30")
chk "同步完成含 state/job_id/result" "$r" '"state":"finished"'
chk "outcome=ok" "$r" '"outcome":"ok"'
chk "exit_code=0" "$r" '"exit_code":0'
chk "signal 为 null" "$r" '"signal":null'
chk "output_file 为 tmp/.out_N" "$r" '"output_file":"tmp/.out_'
chk "truncated=false" "$r" '"truncated":false'

r=$(curl -s "$B/exec?user=alice&cmd=exit%207&timeout=30")
chk "非零退出码 outcome 仍为 ok" "$r" '"outcome":"ok"'
chk "exit_code=7" "$r" '"exit_code":7'

echo
echo "=== B. /status 与 404 语义 ==="
JID=$(echo "$r" | grep -o '"job_id":[0-9]*' | head -1 | cut -d: -f2)
r=$(curl -s "$B/status?user=alice&job_id=$JID")
chk "/status 已完成返回 finished" "$r" '"state":"finished"'
chkcode "/status 不存在的 job → 404" "$B/status?user=alice&job_id=99999" 404
chkcode "/status 缺 job_id → 400" "$B/status?user=alice" 400
chkcode "/status job_id=0 → 400" "$B/status?user=alice&job_id=0" 400

echo
echo "=== C. 二进制判定 ==="
# 输出含 NUL 字节
curl -s "$B/exec?user=bob&cmd=printf%20%27a%5C000b%27&timeout=30" > /dev/null
r=$(curl -s "$B/exec?user=bob&cmd=printf%20%27x%5C000y%27&timeout=30")
chk "含 NUL → unusable" "$r" '"outcome":"unusable"'
chk "error=binary output" "$r" '"error":"binary output"'

echo
echo "=== D. /cat 分页与 has_more ==="
curl -s "$B/write?user=alice&path=big.txt&content=0123456789abcdefghij" > /dev/null
r=$(curl -s "$B/cat?user=alice&path=big.txt&limit=5")
chk "limit 生效" "$r" '"content":"01234"'
chk "has_more=true" "$r" '"has_more":true'
chk "size 为总长" "$r" '"size":20'
r=$(curl -s "$B/cat?user=alice&path=big.txt&offset=10&limit=5")
chk "offset 生效" "$r" '"content":"abcde"'
r=$(curl -s "$B/cat?user=alice&path=big.txt&offset=100")
chk "offset 越界返回空" "$r" '"content":""'
chk "offset 越界 has_more=false" "$r" '"has_more":false'

echo
echo "=== E. /write 错误码 ==="
chkcode "写保留路径 tmp/.out_ → 400" "$B/write?user=alice&path=tmp/.out_9&content=x" 400
chkcode "父目录不存在 → 404" "$B/write?user=alice&path=nodir/x.txt&content=x" 404
chkcode "路径逃逸 → 400" "$B/write?user=alice&path=../evil.txt&content=x" 400
chkcode "绝对路径 → 400" "$B/write?user=alice&path=/etc/passwd&content=x" 400
curl -s "$B/write?user=alice&path=adir" > /dev/null
chkcode "user 不在白名单 → 403" "$B/ls?user=mallory" 403
chkcode "user 格式非法 → 400" "$B/ls?user=bad%20name" 400
chkcode "预期外参数 → 400" "$B/ls?user=alice&bogus=1" 400
chkcode "timeout 超上限 → 400" "$B/exec?user=alice&cmd=true&timeout=99999" 400
chkcode "timeout 非正 → 400" "$B/exec?user=alice&cmd=true&timeout=0" 400

echo
echo "=== F. timeout ==="
r=$(curl -s "$B/exec?user=alice&cmd=sleep%2030&timeout=1")
chk "超时 → unusable" "$r" '"outcome":"unusable"'
chk "error=timeout" "$r" '"error":"timeout"'

echo
echo "=== G. 用户隔离 ==="
curl -s "$B/write?user=alice&path=secret.txt&content=aliceonly" > /dev/null
chkcode "bob 看不到 alice 的文件（404）" "$B/cat?user=bob&path=secret.txt" 404
r=$(curl -s "$B/exec?user=bob&cmd=cat%20secret.txt&timeout=30")
chk "bob 容器内也读不到" "$r" '"exit_code":1'
r=$(curl -s "$B/cat?user=alice&path=secret.txt")
chk "alice 自己能读到" "$r" '"content":"aliceonly"'

echo
echo "=== H. 持久卷（/home/user 跨代次保留）==="
r=$(curl -s "$B/exec?user=alice&cmd=ls%20-1&timeout=30")
chk "代次内可见文件" "$r" '"outcome":"ok"'

echo
echo "=== I. /ls 结构 ==="
r=$(curl -s "$B/ls?user=alice")
chk "含 ok/dir/file" "$r" '"ok":true'
chk "含 dir 数组" "$r" '"dir":'
chk "含 file 数组" "$r" '"file":'

echo
echo "=== J. piggyback 约束 ==="
chk "exec 响应不因 piggyback 破坏结构" "$(curl -s "$B/exec?user=bob&cmd=true&timeout=30")" '"state":"finished"'

echo
echo "=== K. v4 严格百分号编码（所有编码用%）==="
chkcode "+ 号当空格 → 400" "$B/exec?user=alice&cmd=echo+hello&timeout=30" 400
chkcode "裸中文 → 400" "$B/write?user=alice&path=中文.txt&content=x" 400
chkcode "非法转义 %ZZ → 400" "$B/exec?user=alice&cmd=%ZZ&timeout=30" 400
chkcode "截断转义 %A → 400" "$B/exec?user=alice&cmd=%A&timeout=30" 400
chkcode "裸反斜杠（未编码）→ 400" "$B/write?user=alice&path=a\\b.txt&content=x" 400
r=$(curl -s "$B/exec?user=alice&cmd=echo%20%25PATH%25&timeout=30")
chk "%25 正确解码为 %" "$r" '%PATH%\n'
# %5C 是编码后的反斜杠：解码后属于普通字符，应被正常接受
chkcode "编码后的反斜杠 %5C 被接受" "$B/write?user=alice&path=ok.txt&content=%5C" 200
r=$(curl -s "$B/exec?user=alice&cmd=printf%20%27a%5Ctb%27&timeout=30")
chk "编码后的制表符序列可用" "$r" 'a\tb'

echo
echo "=== L. v4 容器出站管控（禁内网/元数据，公网自由）==="
# 确保容器内具备 curl（基础镜像已预配 apk 镜像源）
curl -s "$B/exec?user=demo&cmd=apk%20add%20--no-cache%20curl%20%3E%2Fdev%2Fnull%202%3E%261&timeout=120" > /dev/null
netchk() { # netchk <描述> <目标URL> <期望判定>
  r=$(curl -s "$B/exec?user=demo&cmd=curl%20-s%20-m%206%20-o%20%2Fdev%2Fnull%20-w%20%22%25%7Bhttp_code%7D%22%20$2%3B%20echo%20%22rc%3D%24%3F%22&timeout=60")
  if echo "$r" | grep -q "$3"; then
    echo "  [PASS] $1"; PASS=$((PASS+1))
  else
    echo "  [FAIL] $1"; echo "         期望包含: $3"; echo "         实际: $r"; FAIL=$((FAIL+1))
  fi
}
# 公网可达（rc=0，有 HTTP 码）
netchk "公网 mirrors.aliyun.com 可达" "https%3A%2F%2Fmirrors.aliyun.com%2F" 'rc=0'
# 内网与元数据被拒（curl rc=7 = 连接被拒绝）
netchk "元数据 169.254.169.254 被阻断" "http%3A%2F%2F169.254.169.254%2F" 'rc=7'
netchk "内网 10.0.0.1 被阻断" "http%3A%2F%2F10.0.0.1%2F" 'rc=7'
netchk "内网 172.17.0.1 被阻断" "http%3A%2F%2F172.17.0.1%2F" 'rc=7'
netchk "内网 192.168.1.1 被阻断" "http%3A%2F%2F192.168.1.1%2F" 'rc=7'
netchk "阿里云元数据 100.100.100.200 被阻断" "http%3A%2F%2F100.100.100.200%2F" 'rc=7'
# 容器内不得具备修改网络规则的能力
r=$(curl -s "$B/exec?user=demo&cmd=iptables%20-L%202%3E%261%3B%20echo%20rc%3D%24%3F&timeout=30")
chk "容器内 iptables 不可用（无 NET_ADMIN）" "$r" 'rc='

echo
echo "=== M. v4 资源限制（4G内存/16G磁盘/双核）==="
r=$(curl -s "$B/exec?user=demo&cmd=nproc&timeout=30")
chk "容器可见 CPU 核数" "$r" '"outcome":"ok"'
# 磁盘预算：单次写入超 content_max_bytes 应被拒
BIG=$(python3 -c "print('A'*70000)")
chkcode "超 content_max_bytes → 413" "$B/write?user=demo&path=big.txt&content=$BIG" 413

echo
echo "=== N. v4 磁盘配额：/exec 也受约束 + 死锁防护 ==="
# 说明：这里的 user_disk_mb 由服务启动参数决定（默认 16384）。
# 本组只验证「清理类命令在超限时仍可用」这一关键性质，
# 完整的超限→507 行为由 test/quota.sh 用独立小配额实例验证。
r=$(curl -s "$B/exec?user=demo&cmd=rm%20-f%20nonexistent.tmp%3B%20echo%20rc%3D%24%3F&timeout=30")
chk "清理类命令（rm）正常放行" "$r" 'rc=0'

echo
echo "======================================"
echo "PASS=$PASS  FAIL=$FAIL"
[ "$FAIL" -eq 0 ] && echo "全部通过" || echo "存在失败项"
