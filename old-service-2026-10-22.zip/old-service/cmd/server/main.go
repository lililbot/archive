package main

import (
	"context"
	"errors"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"sandbox-exec/internal/api"
	"sandbox-exec/internal/config"
	"sandbox-exec/internal/executor"
	"sandbox-exec/internal/store"
)

func main() {
	log.SetFlags(log.LstdFlags | log.Lmicroseconds)

	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("启动失败：%v", err)
	}

	st := store.New()
	ex := executor.New(cfg, st)

	if !ex.DockerAvailable() {
		log.Printf("[warn] Docker 不可用：容器将无法启动，/exec 会失败。请检查 /var/run/docker.sock")
	} else {
		log.Printf("[init] Docker 可用，基础镜像=%s", cfg.BaseImage)
	}

	srv := api.NewServer(cfg, st, ex)

	// 后台 GC
	gc := executor.NewGC(cfg, st, ex)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go gc.Run(ctx)

	httpSrv := &http.Server{
		Addr:              cfg.ListenAddr,
		Handler:           srv.Routes(),
		ReadHeaderTimeout: 10 * time.Second,
		// 不设 WriteTimeout：/exec 同步等待 + 大响应需要长连接
	}

	// 先开始监听，再做对账。
	// 对账要遍历 Docker 容器，可能耗时数秒；若放在监听之前，
	// 就绪探针会在窗口期内探测失败。
	var listener net.Listener
	ln, err := net.Listen("tcp", cfg.ListenAddr)
	if err != nil {
		log.Fatalf("监听失败 %s：%v", cfg.ListenAddr, err)
	}
	listener = ln

	go func() {
		// 这行日志同时是发布平台的就绪特征（"serving http"），必须保留该措辞。
		log.Printf("[init] serving http on %s", cfg.ListenAddr)
		if err := httpSrv.Serve(listener); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Fatalf("HTTP 服务退出：%v", err)
		}
	}()

	// 对账：清理上次进程遗留的孤儿容器（否则会泄漏并占满 container_total_limit）。
	// 放在监听之后，不阻塞就绪；期间容器数短暂偏高，由后续 GC 收敛。
	if ex.DockerAvailable() {
		go func() {
			initCtx, initCancel := context.WithTimeout(context.Background(), 60*time.Second)
			defer initCancel()

			// 出站管控准备：清理遗留规则 → 建公共拒绝链 → 确保独占网络存在。
			// 必须在容器启动前完成，否则先起的容器会短暂处于无规则状态。
			ex.EnsureEgressNetwork(initCtx)

			if n, err := ex.ReconcileOrphans(initCtx); err != nil {
				log.Printf("[warn] 孤儿容器对账失败：%v", err)
			} else if n > 0 {
				log.Printf("[init] 已清理 %d 个遗留容器", n)
			}
		}()
	}

	// 优雅退出
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	<-sig
	log.Printf("[shutdown] 收到退出信号，停止服务")
	shutCtx, shutCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer shutCancel()
	_ = httpSrv.Shutdown(shutCtx)
}
