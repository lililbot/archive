#!/bin/bash
# 本地联调启动脚本。
# 生产部署请用环境变量或配置中心覆盖这些值。
export SBX_USER_ALLOWLIST="${SBX_USER_ALLOWLIST:-alice,bob,demo}"
export SBX_LISTEN_ADDR="${SBX_LISTEN_ADDR:-:8099}"
export SBX_HOME_VOLUME_ROOT="${SBX_HOME_VOLUME_ROOT:-/tmp/sandbox-exec-home}"
export SBX_GC_SCAN_INTERVAL_S="${SBX_GC_SCAN_INTERVAL_S:-30}"
export SBX_CONTAINER_TOTAL_LIMIT="${SBX_CONTAINER_TOTAL_LIMIT:-5}"
export SBX_BASE_IMAGE="${SBX_BASE_IMAGE:-alpine:3.19}"

# v4 资源限制：4G内存 / 16G磁盘 / 双核
export SBX_CONTAINER_MEMORY_MB="${SBX_CONTAINER_MEMORY_MB:-4096}"
export SBX_CONTAINER_CPU="${SBX_CONTAINER_CPU:-2}"
export SBX_USER_DISK_MB="${SBX_USER_DISK_MB:-16384}"
export SBX_OUTPUT_TMP_QUOTA_MB="${SBX_OUTPUT_TMP_QUOTA_MB:-1024}"

# v4 容器出站管控（禁内网/元数据，公网自由）
export SBX_DOCKER_NETWORK="${SBX_DOCKER_NETWORK:-sandbox-egress}"
export SBX_EGRESS_SUBNET_BASE="${SBX_EGRESS_SUBNET_BASE:-172.20.0.0/16}"
export SBX_APK_MIRROR="${SBX_APK_MIRROR:-mirrors.aliyun.com}"
# 无宿主 iptables 权限时置 false 可降级（届时容器可访问内网）
export SBX_EGRESS_ENFORCE_HOST="${SBX_EGRESS_ENFORCE_HOST:-true}"

mkdir -p "$SBX_HOME_VOLUME_ROOT"

exec /workspace/sandbox-exec/bin/sandbox-exec
