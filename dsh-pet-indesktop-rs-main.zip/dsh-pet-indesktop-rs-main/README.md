# dsh-pet-indesktop-rs

<p align="center">
  <img alt="语言" src="https://img.shields.io/badge/语言-Rust-DEA584">
  <img alt="平台" src="https://img.shields.io/badge/平台-Windows%20%7C%20macOS%20%7C%20Linux-8A2BE2">
  <img alt="CI" src="https://github.com/entropy356/dsh-pet-indesktop-rs/actions/workflows/ci.yml/badge.svg">
</p>

将 [MerZlin/dsh-pet-indesktop](https://github.com/MerZlin/dsh-pet-indesktop)（Python + PySide6 桌面宠物「蓝色大肥鱼」）用 **Rust** 重构的工程。

> 原项目亮点：透明无边框、置顶、可拖动的桌宠窗口；角色切换与动画播放；系统托盘；单进程多开（共享解码链）；物理/碰撞彩蛋；可选 AI 对话能力。本仓库目标是在保持功能与交互体验的前提下，用 Rust 获得更小的体积、更低的内存与更快的启动。

## 当前进度：第一阶段（骨架）

- ✅ 模块划分与占位接口（`window` / `animation` / `physics` / `tray` / `config`）
- ✅ 零依赖、开箱即编译，内置单元测试
- ⬜ 第二阶段：winit 透明置顶窗口 + 拖动 + 动画帧渲染
- ⬜ 第三阶段：系统托盘、右键菜单、配置持久化
- ⬜ 第四阶段：单进程多开与共享解码链
- ⬜ 第五阶段：AI 对话、语音、音乐歌词等扩展能力

## 技术选型（规划）

| 领域 | 原项目（Python） | Rust 方案 |
|---|---|---|
| 窗口/事件 | PySide6 | `winit` |
| 渲染 | Qt 绘制 | `softbuffer`（起步）→ `wgpu`（加速） |
| 托盘 | Qt SystemTray | `tray-icon` |
| 配置 | JSON | `serde` + `serde_json`/`toml` |
| 视频解码 | OpenCV/Qt Multimedia | PNG 序列帧优先（纯 Rust `png`/`image` 解码，issue #12 定稿）；webm/VP9 见 backlog #16 |
| 纯逻辑层 | collision.py / physics.py | 本仓 `src/physics.rs`（零 GUI 依赖，单测守护） |

## 架构红线（继承自原项目，CI 守护）

1. **纯逻辑层不依赖 GUI**：`src/physics.rs` 等纯逻辑模块禁止引入 winit/wgpu 等渲染依赖。
2. **共享解码链单向依赖**：`animation` 不得反向依赖 `window`；窗口钩子只能通过注入接入。
3. **窗口私有面冻结**：`PetWindow` 的内部字段仅 `window` 模块自身可访问。

完整开发规范（红线细则、契约流程、素材策略、公告机制、双端协作）见
[SPEC.md](SPEC.md)——单一事实源，动工前必读。

## 开发

```bash
cargo build        # 编译
cargo test         # 运行单元测试
cargo run          # 运行（骨架阶段仅打印模块划分）
cargo clippy --all-targets -- -D warnings   # CI 同款 lint
cargo fmt --check  # 格式检查
bash scripts/check-arch.sh                   # 架构红线检查（CI 同款）
```

## 素材（issue #14 约定，#12 加载器的约定来源）

角色素材**不入库**：用户自行从原项目获取 webm，用转换脚本生成本仓库运行时
所需的 PNG 序列帧。

### 目录约定

```
assets/<角色>/<行为分类>/<片段>/NNNN.png + manifest.json
```

- `<角色>` 与 config 的 `character` 字段对齐（默认 `shenshen`）；
- `<片段>` = 原项目 videos 下每个 webm 文件（去扩展名）；行为分类目录层级
  原样保留（如 `click`、`events/balance`）；
- 帧名 `0000.png` 起零填充 4 位递增，**断号视为损坏**；
- `manifest.json`（由转换脚本经 ffprobe 生成，全字段必选）：

  ```json
  { "version": 1, "fps": 24, "frame_count": 241, "width": 640, "height": 360 }
  ```

- **回退行为**：manifest 缺失/损坏/断号时，#12 加载器回退 `MockFrameSource`
  并日志提示，不 panic；
- 加载器按「含 `manifest.json` 的目录 = 一个可播放片段」递归扫描；
  行为分类取该目录相对路径的父级。

### 转换脚本

```bash
# 完整转换（默认输出 ./assets/，帧率上限 24fps，保持原分辨率）
python3 scripts/convert_assets.py --src <原项目>/assets/characters/shenshen/videos

# 只转 idle 分类，帧率压到 12fps，缩放到 300x300
python3 scripts/convert_assets.py --src .../videos --include idle --fps-cap 12 --size 300x300
```

Python 3 标准库 + 系统 ffmpeg/ffprobe，零 pip 依赖；`--help` 自说明。
`assets/**/*.png` 与 `assets/**/manifest.json` 已在 `.gitignore` 中，素材
本体与生成物不进仓库。

### 授权

角色素材为同人作品（CC BY-NC-SA 类，**仅限个人非商业使用**，须保留署名与
来源），详见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。

## 许可证

代码：[MIT](LICENSE)（原项目 MerZlin/dsh-pet-indesktop 亦为 MIT，版权行已保留）。

角色动画与声音素材（第二阶段引入）授权见
[THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)：角色素材为同人作品
（CC BY-NC-SA 类，**仅限个人非商业使用**，须保留署名与来源）。

## 致谢

- 原项目与「蓝色大肥鱼」素材：[MerZlin/dsh-pet-indesktop](https://github.com/MerZlin/dsh-pet-indesktop)（基于 PC2005-cloud/dsh-pet）
