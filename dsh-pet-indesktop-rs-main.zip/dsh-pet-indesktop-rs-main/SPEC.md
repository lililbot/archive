# SPEC —— 开发规范正文（单一事实源）

本文件是 dsh-pet-indesktop-rs 及其协作体系（planner / 执行端）的**规范唯一权威
版本**。各端动工前重读本文件确认最新版；**变更历史以本文件的 git 提交记录
为准**。

> 本文件由 planner 维护——planner 可直接提交规范文档，不受「不直接写
> 主仓库代码」限制。

## 1. SOFT SPEC（架构与协作红线）

1. **CI 红线**：GUI 代码与纯逻辑隔离——`physics` / `config` / 解码链不得
   依赖窗口层；`animation` 不得反向依赖 `window`；`PetWindow` 私有面冻结。
   由 `scripts/check-arch.sh` 三项检查 + CI 强制。
2. **接口先行**：跨轨依赖（如解码器 ← Frame 契约）以 issue 内契约为准；
   契约变更须在契约所在 issue 内更新并评论提示，相关轨开工前复查契约。
3. **issue 分工**：规划端建任务 issue（含背景与验收标准）；执行端领取时
   评论认领并简述计划，同时开执行 issue（标题 `exec: 简述 (#N)`），完成后
   在 commit / PR 里 `closes #N` 指回父任务；规划端不动执行端已领取的
   issue（以看板认领评论为准）。
4. **素材策略**：素材不入库、PNG 序列帧优先、MIT 音效
   入库；**内存占用 > 磁盘占用 / 包体**是资源类设计的基准约束。
5. **执行端反馈**：需要用户即时裁决的问题
   （契约歧义、验收争议、外部阻塞）**先在对话中直报用户**，再落 issue
   评论沉淀；常规工作沟通（进展、疑问、验收澄清）直接在相关 issue
   评论，无需前缀（并行会话场景才 @ 相关方）。**带前缀的仅两类**：
   `[阻塞]`（卡住无法继续，planner 扫板优先处理）/ `[反馈]`
   （**经验总结或建议**——踩坑教训、流程 / 规范 / 工具的改进提议，
   planner 判定归档去向：操作手册 / SPEC / PROGRESS）。执行端 token
   无 Discussions 写权限——公共广播面收敛：主仓库 Discussions 各分类
   对执行端关闭，一切持久沟通走 issue 评论。
6. **合并复核**：合并关口 = **CI 门禁
   （机械事实源）+ planner 语义复核**——冷读 diff、验收标准逐项对照、
   决策一致性（锁定项偏离即打回）、跨轨契约一致性；本地全量门禁仅
   在 CI 无法判定或复核存疑时补跑（与 CI 同款门禁的本地重跑属重复
   劳动）。复核结论落 PR 评论：门禁依据 + 验收对照 + 语义抽验点 +
   结论。GUI 轨维持两步验收（CI + 单测 → 用户桌面行为验收）。

## 2. 身份与禁区（双端协作）

- planner 与执行端在 GitHub 上共用 entropy356 账号（单一 admin），分离靠
  token 分级 + 约定：
  - **planner**：全量 PAT（四仓库读写 + Discussions 写）；
  - **执行端**：受限 fine-grained PAT，仅本仓库 Contents / Issues / PR
    三项 RW + Metadata 只读（规格与 age 交接流程见 agent-bootstrap
    `agent/README.md`）。
- **planner 禁区**：不动执行端已领取的 issue；不直接写主仓库代码——两个
  例外，均为 planner 职责：本文件 SPEC.md 的维护；`main.rs` **跨轨集成
  接线**（window / sim / animation 等多轨组件在入口的组装）。例外范围
  仍走 PR + CI 门禁合并，不直推 main；组件内部实现归执行端。
- **执行端禁区**：不写 planning-center（含 PROGRESS.md）——token 层面
  强制（该私有仓库不在执行端令牌范围内）。
- **审计线**：planning-center 的 `PROGRESS.md`（只记决策、事故、规范
  变更、下一步；issue / PR 状态以本仓库看板为事实源）。
- **应急通道**：需要立即触达的事项走两条既有通道——
  用户直接在相关会话中喊话（各执行端均为用户面前的会话）；planner 在
  受影响的 issue 下评论冻结。**不设全局广播位**：Discussions 仅保留
  用户与 planner 的交流分类（Q&A / Ideas 等），Announcements 分类
  不承载任何流程。

## 3. 文档纪律

- **除 planning-center 外，所有文档保持无状态**：只写现行规则与操作
  指引，不写日期、背景、决策过程与历史沿革（历史在 git 提交记录与
  planning-center 的 PROGRESS）。planning-center 为唯一有状态的载体
  （进度与审计线）。
