// ============================================================
// 01 基础类型：Python 注解 ↔ TypeScript 注解
// Python:
//   name: str = "Bob"
//   age: int = 23
//   ok: bool = True
//   pi: float = 3.14
// ============================================================
export {};

const name: string = "Bob";
const age: number = 23;
const ok: boolean = true;
const pi: number = 3.14; // Python 的 int/float 在 TS 里都是 number

// 大整数：Python 天然任意精度，TS 要用 bigint（后缀 n）
const big: bigint = 2n ** 100n;

// 字符串模板（≈ f-string）
const msg = `Hello, ${name}! Age ${age}.`;

// 字面量类型（≈ Literal["r", "w"]）
let mode: "r" | "w" = "r";
mode = "w";

// unknown 是安全的 Any：用之前必须收窄
function describe(value: unknown): string {
  if (typeof value === "number") return `number: ${value.toFixed(1)}`;
  if (typeof value === "string") return `string: ${value.trim()}`;
  return "other";
}

console.log("[01] ", msg, "| pi =", pi, "| ok =", ok);
console.log("[01] ", big.toString().slice(0, 12) + "... (bigint)");
console.log("[01] ", describe(3.14159), "|", describe("  hi  "), "|", describe(null));

// 陷阱演示：空数组在 JS 里是 truthy（和 Python 相反）
const empty: number[] = [];
console.log("[01] ", `[] is truthy in JS? ${Boolean(empty)}`);
