// ============================================================
// 13 异步：async def/await/asyncio.gather → async/Promise/await/Promise.all
// ============================================================
export {};

// async def f() -> str  →  async function f(): Promise<string>
async function fetchUser(uid: number): Promise<string> {
  return `user-${uid}`;
}

// 模拟失败的异步
async function maybeFail(shouldFail: boolean): Promise<number> {
  if (shouldFail) throw new Error("boom");
  return 42;
}

// 并发：asyncio.gather → Promise.all
async function gatherDemo(): Promise<void> {
  const [a, b] = await Promise.all([fetchUser(1), fetchUser(2)]);
  console.log("[13] Promise.all =", a, b);
}

// 错误处理：try/except → try/catch（catch 的 e 是 unknown，必须收窄）
async function errorDemo(): Promise<void> {
  try {
    await maybeFail(true);
  } catch (e: unknown) {
    if (e instanceof Error) {
      console.log("[13] caught Error:", e.message);
    } else {
      console.log("[13] caught non-Error:", e);
    }
  } finally {
    console.log("[13] finally ran");
  }
}

// 异步迭代：async for → for await...of
async function* countUpAsync(n: number): AsyncGenerator<number> {
  for (let i = 0; i < n; i++) {
    yield i;
  }
}

async function iterateDemo(): Promise<void> {
  const collected: number[] = [];
  for await (const x of countUpAsync(3)) {
    collected.push(x);
  }
  console.log("[13] for await =", collected);
}

// 顶层没有 await（CJS），用一个 async main 启动，等价 asyncio.run(main())
async function main(): Promise<void> {
  console.log("[13] fetchUser =", await fetchUser(7));
  console.log("[13] maybeFail(false) =", await maybeFail(false));
  await gatherDemo();
  await errorDemo();
  await iterateDemo();
}

void main();
