// ============================================================
// 03 可选与空值：Optional / None → ? / ?? / ! / ?.
// ============================================================
export {};

// Optional[str] → string | undefined
let a: string | undefined = undefined;
let b: string | null = null;

function getLen(s: string | null): number {
  if (s === null) return 0;
  return s.length;
}

// 可选链 ?.
interface Address {
  city?: string;
}
interface User {
  name: string;
  address?: Address;
}

function cityOf(u: User | null): string {
  return u?.address?.city ?? "unknown";
}

// ?? 与 || 的区别：0 和 "" 是 falsy，但 ?? 只对 null/undefined 生效
function withDefault(value: number | null | undefined): { or: number; nullish: number } {
  const or = value || 100; // value=0 时也变成 100（有坑）
  const nullish = value ?? 100; // 只有 null/undefined 才用 100
  return { or, nullish };
}

// 非空断言 !（等价于 cast，慎用）
// 注意：如果真传 null，这里会在运行时抛 TypeError——这正是 ! 的危险之处。
function firstChar(s: string | null): string {
  return s![0] ?? "";
}

// 安全用法：先收窄，再取值
function firstCharSafe(s: string | null): string {
  if (s === null) return "";
  return s[0] ?? "";
}

// 解构默认值
function greeting({ name = "guest" }: { name?: string } = {}): string {
  return `Hi ${name}`;
}

a = "x";
console.log("[03] getLen =", getLen("hello"), "|", getLen(null));
console.log("[03] cityOf =", cityOf({ name: "Bob", address: { city: "Beijing" } }),
  "|", cityOf({ name: "Bob" }), "|", cityOf(null));
console.log("[03] withDefault(0) =", withDefault(0), "| withDefault(null) =", withDefault(null));
console.log("[03] firstChar('abc') =", firstChar("abc"),
  "| firstCharSafe(null) =", firstCharSafe(null));
console.log("[03] greeting =", greeting(), "|", greeting({ name: "Bob" }));
console.log("[03] b =", b, "| a =", a);
