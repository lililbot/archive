// ============================================================
// 11 工具类型：typing 的 helper → Partial/Required/Readonly/Pick/Omit/Record/...
// ============================================================
export {};

interface User {
  id: number;
  name: string;
  email: string;
  password: string;
}

// Partial<T>：所有字段变可选（≈ NotRequired / total=False）
type PartialUser = Partial<User>;
const patch: PartialUser = { name: "New" };

// Required<T>：全部必填
type RequiredUser = Required<PartialUser>;
const full: RequiredUser = { id: 1, name: "Bob", email: "b@x.com", password: "p" };

// Readonly<T>：只读（≈ frozen dataclass）
type Frozen = Readonly<{ host: string; port: number }>;
const cfg: Frozen = { host: "localhost", port: 80 };

// Pick / Omit：从大类型裁剪
type UserPreview = Pick<User, "id" | "name">;
type PublicUser = Omit<User, "password">;
const preview: UserPreview = { id: 1, name: "Bob" };
const pub: PublicUser = { id: 1, name: "Bob", email: "b@x.com" };

// Record：字典，且强制键齐全
type Role = "admin" | "user";
type Permissions = Record<Role, string[]>;
const perms: Permissions = { admin: ["read", "write"], user: ["read"] };

// Exclude / Extract / NonNullable：联合运算
type Status = "idle" | "running" | "done";
type Active = Exclude<Status, "done">;
type Finished = Extract<Status, "done">;
type Name = NonNullable<string | null | undefined>;

// ReturnType / Parameters：从函数反推
function createUser(name: string, age: number) {
  return { id: 1, name, age };
}
type CreatedUser = ReturnType<typeof createUser>;
type CreateArgs = Parameters<typeof createUser>;

// 组合：Partial<Omit<User, "id">>
type Editable = Partial<Omit<User, "id">>;

const patch2: Editable = { email: "new@x.com" };
const created: CreatedUser = createUser("Bob", 20);
const args: CreateArgs = ["Cara", 22];

const active: Active = "running";
const finished: Finished = "done";
const nm: Name = "abc";

console.log("[11] patch =", patch, "| full.id =", full.id);
console.log("[11] cfg =", cfg, "| preview =", preview, "| pub =", pub);
console.log("[11] perms.admin =", perms.admin);
console.log("[11] active =", active, "| finished =", finished, "| name =", nm);
console.log("[11] created =", created, "| args =", args);
console.log("[11] patch2 =", patch2);
