// ============================================================
// 10 收窄与类型守卫：isinstance/TypeGuard → typeof/instanceof/in / x is T
// ============================================================
export {};

// typeof 收窄标量
function pad(x: number | string): string {
  if (typeof x === "number") return x.toFixed(2);
  return x.trim();
}

// Array.isArray 收窄数组
function sum(x: number | number[]): number {
  if (Array.isArray(x)) return x.reduce((a, b) => a + b, 0);
  return x;
}

// instanceof 收窄类实例
class Animal {
  constructor(public name: string) {}
}
class Dog extends Animal {
  bark(): string {
    return "Woof";
  }
}
function speak(a: Animal): string {
  if (a instanceof Dog) return a.bark();
  return "...";
}

// in 收窄"有没有字段"
type Fish = { swim: () => string };
type Bird = { fly: () => string };
function move(a: Fish | Bird): string {
  if ("swim" in a) return a.swim();
  return a.fly();
}

// 自定义类型守卫：TypeGuard[list[str]] → xs is string[]
function isStringArray(xs: unknown[]): xs is string[] {
  return xs.every((x) => typeof x === "string");
}

// 断言函数：assert isinstance(...) → asserts x is string
function assertString(x: unknown): asserts x is string {
  if (typeof x !== "string") throw new Error("not a string");
}

console.log("[10] pad =", pad(1.5), "|", pad("  hi  "));
console.log("[10] sum =", sum(3), "|", sum([1, 2, 3]));
console.log("[10] speak =", speak(new Dog("Rex")), "|", speak(new Animal("x")));
console.log("[10] move =", move({ swim: () => "swimming" }), "|",
  move({ fly: () => "flying" }));

const unknownArr: unknown[] = ["a", "b"];
if (isStringArray(unknownArr)) {
  console.log("[10] isStringArray -> joined:", unknownArr.join(","));
}

const maybe: unknown = "hello";
assertString(maybe);
console.log("[10] assertString ->", maybe.toUpperCase());
