// ============================================================
// 04 联合 / 交叉：Union[int,str] → number|string；A & B（Python 无直接对应）
// ============================================================
export {};

// 联合类型：写法与 Python 3.10+ 完全一致
function stringifyId(id: number | string): string {
  if (typeof id === "number") return id.toString();
  return id.trim();
}

// 字面量联合（≈ Literal["idle","running","done"]）
type Status = "idle" | "running" | "done";

// 交叉类型：把两个对象的字段合并
type Named = { name: string };
type Aged = { age: number };
type Person = Named & Aged;

const person: Person = { name: "Bob", age: 20 };

// 判别联合（discriminated union）：判别键 + switch 自动收窄
type Shape =
  | { kind: "circle"; radius: number }
  | { kind: "square"; side: number };

function area(s: Shape): number {
  switch (s.kind) {
    case "circle":
      return Math.PI * s.radius ** 2;
    case "square":
      return s.side ** 2;
    default: {
      const _exhaustive: never = s; // 穷尽性检查（≈ assert_never）
      return _exhaustive;
    }
  }
}

const statusLabel = (s: Status): string => `status: ${s}`;

console.log("[04] stringifyId =", stringifyId(42), "|", stringifyId("  a  "));
console.log("[04] person =", person);
console.log("[04] area(circle) =", area({ kind: "circle", radius: 1 }).toFixed(3));
console.log("[04] area(square) =", area({ kind: "square", side: 3 }));
console.log("[04] statusLabel =", statusLabel("running"));
