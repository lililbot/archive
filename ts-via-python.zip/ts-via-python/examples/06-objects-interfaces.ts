// ============================================================
// 06 对象与接口：TypedDict/dataclass/Protocol → type/interface/implements
// ============================================================
export {};

// TypedDict → interface
interface User {
  name: string;
  age: number;
  readonly id: string;
  nickname?: string; // NotRequired[str]
}

const u: User = { name: "Bob", age: 20, id: "u1" };

// 结构化类型：形状对就行，不需要显式继承
interface Named {
  name: string;
}
function hello(x: Named): string {
  return `Hi ${x.name}`;
}
const robot = { name: "R2D2", serial: 7 }; // 多字段也行
class Android {
  name = "Data";
}

// Protocol → interface + implements
interface Speaker {
  speak(): string;
}
class EnglishTeacher implements Speaker {
  speak(): string {
    return "Hello, class!";
  }
}

// 索引签名 / Record：dict[str, int]
interface Scores {
  [key: string]: number;
}
const scores: Scores = { alice: 90, bob: 85 };

// 接口继承 / 扩展
interface Animal {
  name: string;
}
interface Dog extends Animal {
  breed: string;
}
const rex: Dog = { name: "Rex", breed: "Husky" };

console.log("[06] user =", u.name, u.id, "| nickname =", u.nickname);
console.log("[06] hello(robot) =", hello(robot), "| hello(android) =", hello(new Android()));
console.log("[06] teacher =", new EnglishTeacher().speak());
console.log("[06] scores =", scores, "| alice =", scores["alice"]);
console.log("[06] dog =", rex);
