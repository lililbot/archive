# 用 Python 类型注解类比学 TypeScript（全套语法）

一套面向 **Python 开发者** 的 TypeScript 教程。每一章都用你熟悉的 `typing` 注解做对照：左边 Python、右边 TypeScript，逐个语法点讲清楚"对应什么、差别在哪、有什么坑"。

- **21 章正文**：从基础类型一路讲到泛型、工具类型、类型编程、异步、装饰器、`tsconfig`。
- **13 个可运行示例**：`examples/*.ts`，开启**最严格**的 `tsc` 配置，能编译、能运行、输出可核对。
- 需要 **Node 18+**（本项目用 Node 24）。

## 如何运行

```bash
# 进入本目录
cd ts-via-python

# 安装依赖（typescript + @types/node）
npm install

# 只做类型检查（≈ 对 TS 跑 mypy）
npm run typecheck

# 编译出 JS
npm run build

# 编译并运行全部示例
npm run examples

# 编译并运行"习题集可运行参考答案"（全部断言应通过）
npm run exercises
```

> 若不想用 npm 脚本，也可以直接：
> `npx tsc --noEmit`、`npx tsc`、`node dist/examples/run-all.js`、`node dist/exercises/run-all.js`

## 习题集

读完每章后，到 [`习题集/`](习题集/README.md) 做配套练习：

- **21 章各一份习题**，按 A 级（入门）/ B 级（进阶）/ C 级（挑战）递进，共约 170 题。
- 每题都附**参考答案**；关键题在 [`exercises/`](exercises/) 里有**可运行**的版本。
- 另有 [`习题集/综合大作业.md`](习题集/综合大作业.md)：5 个跨章节项目（`Result` 容器、状态机、事件总线、`unknown` 解析层、泛型 `LRU`）。

```bash
# 你的答案要能通过这项目最严格的 tsc 配置
npm run typecheck

# 跑一遍习题的可运行参考答案（全绿才算对）
npm run exercises
```

入口 → [习题集/README.md](习题集/README.md)

## 章节索引

| # | 章节 | 一句话 |
| --- | --- | --- |
| 01 | [心智模型](01-心智模型.md) | 注解放在哪一层生效；TS 类型编译后被抹除 |
| 02 | [基础类型](02-基础类型.md) | `int/float/str/bool/None` → `number/string/boolean/null` |
| 03 | [变量声明](03-变量声明.md) | `const`/`let`/`var`；`const` 不等于内容不可变 |
| 04 | [函数](04-函数.md) | `def`→`function`、`*args`→`...args`、`**kwargs`→对象参数 |
| 05 | [可选与空值](05-可选与空值.md) | `Optional`→`?`、`?.`、`??`、`!` |
| 06 | [联合与交叉类型](06-联合与交叉类型.md) | `Union`/`\|`→`\|`，以及 TS 独有的 `&` |
| 07 | [集合类型](07-集合类型.md) | `list/dict/set/tuple` → `[]/Record\|Map/Set/[..]` |
| 08 | [对象与接口](08-对象与接口.md) | `TypedDict/dataclass`→`type/interface`；结构化类型 |
| 09 | [类型别名与字面量](09-类型别名与字面量.md) | `TypeAlias`→`type`、`Literal`→字面量类型 |
| 10 | [枚举](10-枚举.md) | `Enum`→`enum`、字面量联合、`as const` 对象 |
| 11 | [泛型](11-泛型.md) | `TypeVar`→`<T>`、`Generic[T]`→`<T>`、`bound`→`extends` |
| 12 | [类](12-类.md) | `__init__`→`constructor`、`@property`→`get/set`、`ABC`→`abstract` |
| 13 | [协议与结构化类型](13-协议与结构化类型.md) | `Protocol`≈`interface`；名义类型 vs 结构类型 |
| 14 | [收窄与类型守卫](14-收窄与类型守卫.md) | `isinstance`→`typeof/instanceof`、`TypeGuard`→`x is T` |
| 15 | [工具类型](15-工具类型.md) | `Partial/Pick/Omit/Record/ReturnType…` |
| 16 | [高级类型](16-高级类型.md) | `keyof`/条件类型/映射类型/`infer`（Python 类型层基本没有） |
| 17 | [模块与导入](17-模块与导入.md) | `import`/`from…import`↔`import`/`export` |
| 18 | [异步](18-异步.md) | `async def`→`async`、`gather`→`Promise.all` |
| 19 | [装饰器](19-装饰器.md) | `@decorator` 两边都有，但用途和透明度差别大 |
| 20 | [断言与类型转换](20-断言与类型转换.md) | `cast`→`as`、`assert`→`!`/断言函数、`satisfies` |
| 21 | [配置与严格模式](21-配置与严格模式.md) | `mypy.ini`→`tsconfig.json`、`strict`≈`mypy --strict` |

## 30 秒速查表

| Python | TypeScript |
| --- | --- |
| `x: int = 1` | `const x: number = 1` |
| `x: str \| None` | `x: string \| null` / `x?: string` |
| `list[int]` | `number[]` |
| `dict[str, int]` | `Record<string, number>` / `Map<string, number>` |
| `tuple[int, str]` | `[number, string]` |
| `set[int]` | `Set<number>` |
| `def f(a: int) -> str` | `function f(a: number): string` |
| `Callable[[int], str]` | `(x: number) => string` |
| `Literal["a","b"]` | `"a" \| "b"` |
| `TypeVar("T")` | `<T>`（就地声明） |
| `Generic[T]` | `class Box<T>` |
| `Optional[int]` | `number \| undefined` |
| `Union[int, str]` | `number \| string` |
| `TypedDict` | `interface` / `type` |
| `Protocol` | `interface`（结构化） |
| `cast(str, x)` | `x as string` |
| `isinstance(x, int)` | `typeof x === "number"` |
| `TypeGuard[T]` | `x is T` |
| `async def f() -> T` | `async function f(): Promise<T>` |
| `asyncio.gather(...)` | `Promise.all([...])` |
| `enum.Enum` | `enum` / 字面量联合 / `as const` |
| `@property` | `get` / `set` |
| `ABC` + `@abstractmethod` | `abstract class` + `abstract` 方法 |
| `@dataclass(frozen=True)` | `readonly` / `Readonly<T>` |
| `Any` | `any`（优先 `unknown`） |

## 推荐阅读路径

- **只想快速上手（约 1 小时）**：01 → 02 → 04 → 05 → 07 → 08 → 12。
- **要写业务代码（约 3 小时）**：上面 + 03 → 06 → 09 → 10 → 11 → 14 → 15 → 17 → 18。
- **想搞懂类型系统 / 库开发**：继续加 13 → 16 → 20 → 21。
- **只想看"哪里有坑"**：重点看每章的"小结"和标 ★ 的差异点，尤其是 03（`const` 语义）、07（方法名、没有列表推导式）、08/13（结构化类型）、18（协程惰性 vs Promise）。

## 这套类比"到此为止"的地方

用 Python 类比能覆盖 TS 大约 70% 的语法，但以下几块是 **TS 独有、Python 类型层没有对应** 的，看到它们别再硬套：

1. **类型是可编程的**：条件类型、映射类型、`infer`、`keyof`、索引访问、模板字面量类型（[15](15-工具类型.md)/[16](16-高级类型.md) 章）。
2. **结构化类型是默认**：Python 要 `Protocol`，TS 天生如此（[13 章](13-协议与结构化类型.md)）。
3. **编译期概念**：`as`/`!`/`satisfies` 只在编译期生效，运行时无痕迹（[20 章](20-断言与类型转换.md)）——因为类型运行时被抹除（[01 章](01-心智模型.md)）。
4. **TS 独有的运行时构造**：`undefined` 与 `null` 并存、数字枚举反向映射、`Set` 无集合运算、没有列表推导式。
5. **工程细节**：`tsconfig`、`@types/*`、`.d.ts`、模块解析（[17](17-模块与导入.md)/[21](21-配置与严格模式.md) 章）。

把这些当作"TS 比 Python 多出来的部分"单独记，而不是找对等物，学起来更顺。
