// ============================================================
// 参考答案 · 06 联合与交叉类型 + 07 集合类型
//   运行：node dist/exercises/03-union-collections.js
// ============================================================
import { assertEquals, assertTrue, summary } from "./_assert.js";

// ---- 06 联合与交叉类型 ----

// A1/A2：联合与字面量联合
let u: number | string = 1;
u = "a";
type Status = "idle" | "running" | "done";
const st: Status = "running";
assertEquals(st, "running", "字面量联合");

// A3/B4：联合用前必须收窄
function format(x: string | number | boolean): string {
  switch (typeof x) {
    case "boolean": return x ? "yes" : "no";
    case "number": return x.toFixed(2);
    default: return x;
  }
}
assertEquals(format(true), "yes", "format(boolean)");
assertEquals(format(3), "3.00", "format(number)");
assertEquals(format("hi"), "hi", "format(string)");

// B1：交叉类型合并对象
type Named = { name: string };
type Aged = { age: number };
type Person = Named & Aged;
const p: Person = { name: "Bob", age: 20 };
assertEquals(p, { name: "Bob", age: 20 }, "交叉类型 Person");

// B3/C1：判别联合 + switch + 穷尽性检查
type Shape =
  | { kind: "circle"; radius: number }
  | { kind: "square"; side: number };

function area(s: Shape): number {
  switch (s.kind) {
    case "circle": return Math.PI * s.radius ** 2;
    case "square": return s.side ** 2;
    default: {
      const _exhaustive: never = s;
      throw new Error(`unreachable: ${String(_exhaustive)}`);
    }
  }
}
assertTrue(Math.abs(area({ kind: "circle", radius: 1 }) - Math.PI) < 1e-9, "圆面积");
assertEquals(area({ kind: "square", side: 3 }), 9, "方面积");

// C1：Result 判别联合
type Result = { ok: true; data: string } | { ok: false; error: string };
function unwrap(r: Result): string {
  switch (r.ok) {
    case true: return r.data;
    case false: throw new Error(r.error);
    default: {
      const _x: never = r;
      throw new Error(`unreachable: ${String(_x)}`);
    }
  }
}
assertEquals(unwrap({ ok: true, data: "ok" }), "ok", "unwrap 成功");
let threw = false;
try { unwrap({ ok: false, error: "bad" }); } catch { threw = true; }
assertTrue(threw, "unwrap 失败会抛");

// ---- 07 集合类型 ----

// A2：列表方法映射
const xs: number[] = [1, 2, 3];
xs.push(1);                       // append
xs.push(...[2, 3]);               // extend
const first = xs.shift();         // pop(0)
assertEquals(first, 1, "shift = pop(0)");
assertEquals(xs.length, 5, "len = .length");
assertTrue(xs.includes(5) === false && xs.includes(3), "in = includes");

// A3/B1：推导式 → map/filter/reduce/some/every/find
const nums = [3, 1, 10, 2];
assertEquals(nums.map((x) => x * x), [9, 1, 100, 4], "map = 列表推导");
assertEquals(nums.filter((x) => x % 2 === 0), [10, 2], "filter = 带条件推导");
assertEquals(nums.reduce((a, b) => a + b, 0), 16, "reduce = sum");
assertEquals(nums.some((x) => x > 5), true, "some = any");
assertEquals(nums.every((x) => x > 0), true, "every = all");
assertEquals(nums.find((x) => x < 0), undefined, "find = next(..., None)");

// B2：数字排序
const toSort = [10, 9, 100, 1];
assertEquals([...toSort].sort(), [1, 10, 100, 9], "默认 sort 是字符串序（坑）");
assertEquals([...toSort].sort((a, b) => a - b), [1, 9, 10, 100], "数字升序");

// B3：没有负索引（.at(-1) 需要 lib >= ES2022，本项目 lib 是 ES2020，故用下标）
assertEquals(toSort[toSort.length - 1], 1, "xs[xs.length - 1]");
assertEquals((toSort as number[])[-1], undefined, "xs[-1] 是 undefined");

// B4/B5：Record vs Map；键不存在返回 undefined
const scores: Record<string, number> = { alice: 90 };
assertEquals(scores["bob"], undefined, "Record 缺键得 undefined");
function getOr(dict: Record<string, number>, key: string, fallback: number): number {
  return dict[key] ?? fallback;
}
assertEquals(getOr(scores, "carol", 0), 0, "getOr 默认值");
const m = new Map<string, number>([["a", 1]]);
assertEquals(m.get("a"), 1, "Map.get");
assertEquals(m.size, 1, "Map.size");

// C1：Set 并交差（无内置运算）
function union<T>(a: Set<T>, b: Set<T>): Set<T> { return new Set([...a, ...b]); }
function intersection<T>(a: Set<T>, b: Set<T>): Set<T> {
  return new Set([...a].filter((x) => b.has(x)));
}
function difference<T>(a: Set<T>, b: Set<T>): Set<T> {
  return new Set([...a].filter((x) => !b.has(x)));
}
const s1 = new Set([1, 2, 3]);
const s2 = new Set([2, 3, 4]);
assertEquals([...union(s1, s2)].sort((a, b) => a - b), [1, 2, 3, 4], "并集");
assertEquals([...intersection(s1, s2)].sort((a, b) => a - b), [2, 3], "交集");
assertEquals([...difference(s1, s2)], [1], "差集");

// C2：groupBy
function groupBy<T, K extends string>(items: T[], key: (x: T) => K): Record<K, T[]> {
  const out = {} as Record<K, T[]>;
  for (const x of items) {
    const k = key(x);
    (out[k] ??= []).push(x);
  }
  return out;
}
const grouped = groupBy(["aa", "b", "cc", "d"], (s) => (s.length === 1 ? "short" : "long"));
assertEquals(grouped.long, ["aa", "cc"], "groupBy long");
assertEquals(grouped.short, ["b", "d"], "groupBy short");

summary("03-union-collections");
