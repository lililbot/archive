// ============================================================
// 参考答案 · 04 函数 + 05 可选与空值
//   运行：node dist/exercises/02-func-optional.js
// ============================================================
import { assertEquals, assertTrue, summary } from "./_assert.js";

// ---- 04 函数 ----

// A1/A2：基础 + 默认值
function add(a: number, b: number): number { return a + b; }
function greet(name: string, greeting = "Hello"): string {
  return `${greeting}, ${name}!`;
}
assertEquals(add(2, 3), 5, "add");
assertEquals(greet("Bob"), "Hello, Bob!", "greet 默认");
assertEquals(greet("Bob", "Hi"), "Hi, Bob!", "greet 传参");

// A3：*args → 剩余参数
function total(...nums: number[]): number {
  return nums.reduce((a, b) => a + b, 0);
}
assertEquals(total(1, 2, 3, 4), 10, "total(*args)");

// B1：**kwargs → 对象参数 + 解构
interface MakeUserOptions { name: string; age?: number; admin?: boolean }
function makeUser(opts: MakeUserOptions): { name: string; age: number; admin: boolean } {
  const { name, age = 0, admin = false } = opts;
  return { name, age, admin };
}
assertEquals(makeUser({ name: "Bob", admin: true }), { name: "Bob", age: 0, admin: true }, "makeUser 关键字参数");

// B3：函数重载
function parse(x: string): number;
function parse(x: number): string;
function parse(x: string | number): number | string {
  return typeof x === "string" ? Number(x) : String(x);
}
assertEquals(parse("42"), 42, "parse(string) → number");
assertEquals(parse(42), "42", "parse(number) → string");

// B5：数字排序必须传比较函数
const toSort = [10, 9, 100, 1];
const wrongSort = [...toSort].sort();               // 字符串排序
const rightSort = [...toSort].sort((a, b) => a - b);
assertEquals(wrongSort, [1, 10, 100, 9], "默认 sort 是字符串序（坑）");
assertEquals(rightSort, [1, 9, 10, 100], "数字排序要传比较函数");

// C1：once（ParamSpec 思路）
function once<Args extends unknown[], R>(fn: (...args: Args) => R): (...args: Args) => R {
  let called = false;
  let cached: R;
  return (...args: Args): R => {
    if (!called) { called = true; cached = fn(...args); }
    return cached;
  };
}
let calls = 0;
const initOnce = once((name: string) => { calls++; return `init:${name}`; });
assertEquals(initOnce("a"), "init:a", "once 首次");
assertEquals(initOnce("b"), "init:a", "once 第二次返回缓存");
assertEquals(calls, 1, "once 只执行一次");

// ---- 05 可选与空值 ----

// A2：判空后收窄
function getLen(s: string | null): number {
  if (s === null) return 0;
  return s.length;
}
assertEquals(getLen("hello"), 5, "getLen 有值");
assertEquals(getLen(null), 0, "getLen null");

// A3：可选链 + 空值合并
interface Address { city?: string }
interface Person { name: string; address?: Address }
function cityOf(p: Person | null): string {
  return p?.address?.city ?? "unknown";
}
assertEquals(cityOf({ name: "Bob", address: { city: "Beijing" } }), "Beijing", "cityOf 有城市");
assertEquals(cityOf({ name: "Bob" }), "unknown", "cityOf 缺 address");
assertEquals(cityOf(null), "unknown", "cityOf null");

// B1：|| vs ??
function defaults(v: number | null | undefined): { or: number; nullish: number } {
  return { or: v || 10, nullish: v ?? 10 };
}
assertEquals(defaults(0), { or: 10, nullish: 0 }, "0：|| 取默认，?? 保留 0");
assertEquals(defaults(null), { or: 10, nullish: 10 }, "null：两者都取默认");

// B4：displayName 处理 null / undefined / 空串
function displayName(user: { name?: string | null }): string {
  const name = user.name;
  if (name === undefined || name === null || name === "") return "匿名";
  return name;
}
assertEquals(displayName({ name: "Bob" }), "Bob", "displayName 有名字");
assertEquals(displayName({ name: "" }), "匿名", "displayName 空串");
assertEquals(displayName({}), "匿名", "displayName 缺字段");

// C2：安全取嵌套值（类型守卫 + 收窄）
function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null;
}
function getNested(obj: unknown, ...path: string[]): unknown {
  let cur: unknown = obj;
  for (const key of path) {
    if (!isRecord(cur)) return undefined;
    cur = cur[key];
  }
  return cur;
}
assertEquals(getNested({ a: { b: { c: 1 } } }, "a", "b", "c"), 1, "getNested 命中");
assertEquals(getNested({ a: {} }, "a", "b", "c"), undefined, "getNested 断开");
assertEquals(getNested(null, "a"), undefined, "getNested null");

// C1 断言：exactOptionalPropertyTypes 的语义
//   开了 exactOptionalPropertyTypes 后，{ x?: number } **不接受**显式 { x: undefined }；
//   想显式写 undefined，要声明成 { x?: number | undefined }。
interface P { x?: number }
interface P2 { x?: number | undefined }
const pEmpty: P = {};
const pUndef: P2 = { x: undefined };
assertTrue(!("x" in pEmpty), "空对象没有 x 键");
assertTrue("x" in pUndef, "显式 undefined 有 x 键");

summary("02-func-optional");
