// ============================================================
// 习题集 · 可运行参考答案的公共断言工具
//   exercises/*.ts 里用 assertEquals / assertDeepEqual 校验答案
//   用 node 跑一遍，任何断言失败都会抛错，说明答案错了。
// ============================================================
export {};

let passed = 0;
let failed = 0;

export function assertEquals<T>(actual: T, expected: T, label: string): void {
  // 简单值用 JSON 比较即可（这里只比较可 JSON 化的值）
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) {
    passed++;
    console.log(`  ✓ ${label}`);
  } else {
    failed++;
    console.log(`  ✗ ${label}: 期望 ${JSON.stringify(expected)}，得到 ${JSON.stringify(actual)}`);
  }
}

export function assertTrue(value: boolean, label: string): void {
  assertEquals(value, true, label);
}

export function summary(section: string): void {
  console.log(`[${section}] 通过 ${passed} 项，失败 ${failed} 项`);
  if (failed > 0) {
    process.exitCode = 1;
  }
  passed = 0;
  failed = 0;
}
