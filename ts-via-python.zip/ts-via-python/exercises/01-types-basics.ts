// ============================================================
// 参考答案 · 02 基础类型 + 03 变量声明
//   运行：node dist/exercises/01-types-basics.js
// ============================================================
import { assertEquals, assertTrue, summary } from "./_assert.js";

// ---- 02 基础类型 ----

// int / float / str / bool 的统一翻译
const age: number = 23;
const pi: number = 3.14;
const ok: boolean = true;
const greeting: string = "hi";

// bigint：Python 的任意精度整数
const big: bigint = 2n ** 100n;

// A4 / C1：f-string ↔ 模板字符串；number 精度 vs bigint
const template = `${greeting} is ${age}`;
assertEquals(template, "hi is 23", "模板字符串 = f-string");
assertEquals(big.toString(), "1267650600228229401496703205376", "bigint 保持精度");

// B1：truthy/falsy（与 Python 相反的空容器）
assertTrue(Boolean([]) === true, "空数组在 JS 是 truthy");
assertTrue(Boolean({}) === true, "空对象在 JS 是 truthy");
assertEquals(Boolean(""), false, "空字符串 falsy");
assertEquals(Boolean(0), false, "0 falsy");
assertEquals(Boolean(Number.NaN), false, "NaN falsy");

// B2：浮点精度（与 Python 一致）
assertEquals(0.1 + 0.2 === 0.3, false, "0.1+0.2 !== 0.3");
assertTrue(Math.abs(0.1 + 0.2 - 0.3) < 1e-9, "浮点比较应用差值");

// B3：typeof 收窄
function formatUid(uid: string | number): string {
  if (typeof uid === "number") return String(uid).padStart(6, "0");
  return uid;
}
assertEquals(formatUid(42), "000042", "数字补零");
assertEquals(formatUid("x7"), "x7", "字符串原样返回");

// C2：覆盖 typeof 的所有分支（含 null 与数组两个坑）
function describe(value: unknown): string {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  switch (typeof value) {
    case "number": return "number";
    case "string": return "string";
    case "boolean": return "boolean";
    case "bigint": return "bigint";
    case "symbol": return "symbol";
    case "function": return "function";
    case "undefined": return "undefined";
    case "object": return "object";
  }
  return "unknown";
}
assertEquals(describe(null), "null", "describe(null)");
assertEquals(describe([1]), "array", "describe([])");
assertEquals(describe(1), "number", "describe(1)");
assertEquals(describe(undefined), "undefined", "describe(undefined)");

// ---- 03 变量声明 ----

// A2：const 只管绑定，不管内容
const xs = [1, 2, 3];
xs.push(4); // ✓ 改内容可以
assertEquals(xs, [1, 2, 3, 4], "const 数组可以 push");

// A3：const 推断字面量，let 放宽
const constString = "idle"; // 类型 "idle"
let letString = "idle";     // 类型 string
assertEquals(constString, "idle", "const 字面量");
assertEquals(letString, "idle", "let 放宽");

// B2：withRetry 补全默认值
interface RetryOptions {
  retries?: number;
  delayMs?: number;
}
function withRetry(opts: RetryOptions): { retries: number; delayMs: number } {
  const { retries = 3, delayMs = 1000 } = opts;
  return { retries, delayMs };
}
assertEquals(withRetry({ retries: 5 }), { retries: 5, delayMs: 1000 }, "withRetry 只传部分");
assertEquals(withRetry({}), { retries: 3, delayMs: 1000 }, "withRetry 全默认");

// B4：从常量数组推导联合类型
const ROUTES = ["/home", "/about", "/settings"] as const;
type Route = (typeof ROUTES)[number];
const r: Route = "/about";
assertEquals(r, "/about", "Route 来自 ROUTES");

summary("01-types-basics");
