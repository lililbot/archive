// ============================================================
// 参考答案 · 08 对象与接口 + 09 类型别名与字面量 + 10 枚举
//   运行：node dist/exercises/04-objects-enums.js
// ============================================================
import { assertEquals, assertTrue, summary } from "./_assert.js";

// ---- 08 对象与接口 ----

// A1/A2：interface 描述形状（可选 + 只读）
interface User {
  readonly id: string;
  name: string;
  age: number;
  nickname?: string;
}
const u: User = { id: "u1", name: "Bob", age: 20 };
assertEquals(u.name, "Bob", "对象点号访问");

// B4：结构化类型（不 implements 也满足）
interface Speaker { speak(): string }
class Robot {
  speak(): string { return "beep"; }
}
const sp: Speaker = new Robot();
assertEquals(sp.speak(), "beep", "结构化匹配");

// B3：索引签名与 Record
interface Scores { [key: string]: number }
const scores: Scores = { alice: 90, bob: 85 };
assertEquals(scores["alice"], 90, "索引签名访问");

// B5：extends vs 交叉
interface Animal { name: string }
interface Dog extends Animal { breed: string }
type Dog2 = Animal & { breed: string };
const d: Dog = { name: "Rex", breed: "Husky" };
const d2: Dog2 = { name: "Rex", breed: "Husky" };
assertEquals(d, d2, "extends 与交叉等价");

// ---- 09 类型别名与字面量 ----

// A1：类型别名
type UserId = number;
type Point = [number, number];
const uid: UserId = 1;
const pt: Point = [0, 0];
assertEquals(uid, 1, "类型别名 UserId");
assertEquals(pt, [0, 0], "类型别名 Point");

// A2：字面量类型
let mode: "r" | "w" = "r";
mode = "w";
assertEquals(mode, "w", "字面量类型 mode");

// B1：const 推断字面量
const constStr = "idle";   // "idle"
let letStr = "idle";       // string
assertEquals(constStr, letStr, "const vs let 值相同（类型不同）");

// B2：as const 保留字面量
const cfg = { role: "admin", level: 3 } as const;
assertEquals(cfg.role, "admin", "as const role");
assertEquals(cfg.level, 3, "as const level");

// B3：从数组推导联合
const COLORS = ["red", "green", "blue"] as const;
type Color = (typeof COLORS)[number];
const c: Color = "green";
assertEquals(c, "green", "Color 来自 COLORS");

// B4：模板字面量类型
type Event = "click" | "focus";
type Handler = `on${Capitalize<Event>}`;
const h: Handler = "onClick";
assertEquals(h, "onClick", "模板字面量类型");

// C1：递归 JsonValue
type JsonValue =
  | string | number | boolean | null
  | JsonValue[]
  | { [key: string]: JsonValue };
const json: JsonValue = { name: "Bob", tags: ["a"], nested: { ok: true, v: null } };
assertTrue(typeof json === "object" && json !== null, "JsonValue 构造");

// ---- 10 枚举 ----

// A1：字符串 enum
enum ColorEnum {
  Red = "red",
  Green = "green",
  Blue = "blue",
}
assertEquals(ColorEnum.Red, "red", "字符串 enum");

// B2：as const 轻量枚举（可遍历）
const Colors = { Red: "red", Green: "green", Blue: "blue" } as const;
type ColorV = (typeof Colors)[keyof typeof Colors];
const cv: ColorV = Colors.Blue;
assertEquals(cv, "blue", "as const 枚举取值");
assertEquals(Object.values(Colors), ["red", "green", "blue"], "as const 枚举可遍历");

// B4：IntEnum → 数字联合
type Level = 1 | 2;
const lv: Level = 2;
assertEquals(lv, 2, "IntEnum → 数字联合");

// C1：轻量枚举 + 判定
const Status = { Idle: "idle", Running: "running", Done: "done" } as const;
type StatusT = (typeof Status)[keyof typeof Status];
function isTerminal(s: StatusT): boolean { return s === Status.Done; }
assertEquals(isTerminal(Status.Done), true, "isTerminal(done)");
assertEquals(isTerminal("running"), false, "isTerminal(running)");

summary("04-objects-enums");
