// ============================================================
// 参考答案 · 14 收窄与类型守卫 + 15 工具类型
//   运行：node dist/exercises/06-narrowing-utils.js
// ============================================================
import { assertEquals, assertTrue, summary } from "./_assert.js";

// ---- 14 收窄与类型守卫 ----

// A1：typeof 收窄
function handle(x: number | string): string {
  if (typeof x === "number") return x.toFixed(2);
  return x.trim();
}
assertEquals(handle(3), "3.00", "typeof 收窄 number");
assertEquals(handle("  hi  "), "hi", "typeof 收窄 string");

// A2：instanceof 收窄
class Animal {}
class Dog extends Animal {}
function speak(a: Animal): string {
  if (a instanceof Dog) return "Woof";
  return "...";
}
assertEquals(speak(new Dog()), "Woof", "instanceof 收窄");
assertEquals(speak(new Animal()), "...", "instanceof 默认分支");

// A3：in 收窄
type Swimmer = { swim: () => string };
type Flyer = { fly: () => string };
function move(a: Swimmer | Flyer): string {
  if ("swim" in a) return a.swim();
  return a.fly();
}
assertEquals(move({ swim: () => "swimming" }), "swimming", "in 收窄 swim");
assertEquals(move({ fly: () => "flying" }), "flying", "in 收窄 fly");

// B1：Array.isArray 收窄
function sum(x: number | number[]): number {
  if (Array.isArray(x)) return x.reduce((a, b) => a + b, 0);
  return x;
}
assertEquals(sum([1, 2, 3]), 6, "Array.isArray 求和");
assertEquals(sum(5), 5, "Array.isArray 原值");

// B3：自定义类型谓词
function isStringArray(xs: unknown[]): xs is string[] {
  return xs.every((x) => typeof x === "string");
}
const maybeStrings: unknown[] = ["a", "b"];
if (isStringArray(maybeStrings)) {
  assertEquals(maybeStrings.join(","), "a,b", "收窄后可 join");
}

// B4：断言函数
function assertString(x: unknown): asserts x is string {
  if (typeof x !== "string") throw new Error("not a string");
}
function useAssert(x: unknown): string {
  assertString(x);
  return x.toUpperCase();
}
assertEquals(useAssert("hello"), "HELLO", "asserts x is string");

// C1：穷尽性检查
type Shape =
  | { kind: "circle"; radius: number }
  | { kind: "square"; side: number }
  | { kind: "rect"; w: number; h: number };
function area(s: Shape): number {
  switch (s.kind) {
    case "circle": return Math.PI * s.radius ** 2;
    case "square": return s.side ** 2;
    case "rect": return s.w * s.h;
    default: {
      const _exhaustive: never = s;
      throw new Error(`unreachable: ${String(_exhaustive)}`);
    }
  }
}
assertEquals(area({ kind: "rect", w: 2, h: 3 }), 6, "穷尽性检查 面积");

// C2：classify
function classify(value: unknown): string {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  if (value instanceof Date) return "date";
  if (value instanceof RegExp) return "regexp";
  switch (typeof value) {
    case "number": return "number";
    case "string": return "string";
    case "boolean": return "boolean";
    case "bigint": return "bigint";
    case "symbol": return "symbol";
    case "function": return "function";
    case "undefined": return "undefined";
    case "object": return "object";
  }
  return "unknown";
}
assertEquals(classify(null), "null", "classify null");
assertEquals(classify([]), "array", "classify array");
assertEquals(classify(new Date()), "date", "classify date");
assertEquals(classify(/x/), "regexp", "classify regexp");

// ---- 15 工具类型 ----

interface User { id: number; name: string; email: string }

// A1/A2
type PartialUser = Partial<User>;
type UserPreview = Pick<User, "id" | "name">;
type NoEmail = Omit<User, "email">;
const patch: PartialUser = { name: "New" };
const preview: UserPreview = { id: 1, name: "Bob" };
const noEmail: NoEmail = { id: 1, name: "Bob" };
assertEquals(patch.name, "New", "Partial");
assertEquals(preview.name, "Bob", "Pick");
assertEquals(noEmail.name, "Bob", "Omit");

// B2：Record 强制键齐全
type Role = "admin" | "user";
type Permissions = Record<Role, string[]>;
const perms: Permissions = { admin: ["read", "write"], user: ["read"] };
assertEquals(perms.admin, ["read", "write"], "Record 权限表");

// B3：联合运算
type Status = "idle" | "running" | "done";
const active: Exclude<Status, "done"> = "running";
const finished: Extract<Status, "done"> = "done";
const nm: NonNullable<string | null | undefined> = "abc";
assertEquals(active, "running", "Exclude");
assertEquals(finished, "done", "Extract");
assertEquals(nm, "abc", "NonNullable");

// B4：ReturnType / Parameters
function createUser(name: string, age: number) {
  return { id: 1, name, age };
}
type CreatedUser = ReturnType<typeof createUser>;
type CreateArgs = Parameters<typeof createUser>;
const created: CreatedUser = createUser("Bob", 20);
const args: CreateArgs = ["Cara", 22];
assertEquals(created.id, 1, "ReturnType");
assertEquals(args[0], "Cara", "Parameters");

// C2：组合工具类型
type UpdatePayload<T> = Partial<Omit<T, "id">>;
const update: UpdatePayload<User> = { email: "new@x.com" };
assertEquals(update.email, "new@x.com", "UpdatePayload");

// 运行时验证 Readonly 只是编译期
type Frozen = Readonly<{ host: string; port: number }>;
const frozen: Frozen = { host: "localhost", port: 80 };
// frozen.port = 1;   // ✗ 编译期报错
const frozenObj = Object.freeze({ host: "localhost", port: 80 });
assertTrue(Object.isFrozen(frozenObj), "Object.freeze 运行时真冻结");
assertEquals(frozen.port, 80, "Readonly 值可读");

summary("06-narrowing-utils");
