// ============================================================
// 参考答案 · 综合大作业（1-5）
//   运行：node dist/exercises/capstone.js
// ============================================================
import { assertEquals, assertTrue, summary } from "./_assert.js";

// ================= 作业一：Result<T, E> =================

type Result<T, E> =
  | { ok: true; value: T }
  | { ok: false; error: E };

function ok<T>(v: T): Result<T, never> {
  return { ok: true, value: v };
}
function err<E>(e: E): Result<never, E> {
  return { ok: false, error: e };
}
function mapResult<T, E, U>(r: Result<T, E>, f: (t: T) => U): Result<U, E> {
  if (r.ok) return ok(f(r.value));
  return err(r.error);
}
function unwrapOr<T, E>(r: Result<T, E>, fallback: T): T {
  return r.ok ? r.value : fallback;
}

assertEquals(mapResult(ok(2), (x) => x * 10), { ok: true, value: 20 }, "Result.map 成功");
assertEquals(mapResult(err("bad") as Result<number, string>, (x) => x * 10),
  { ok: false, error: "bad" }, "Result.map 失败");
assertEquals(unwrapOr(ok(5), 0), 5, "unwrapOr 成功");
assertEquals(unwrapOr(err("x") as Result<number, string>, 0), 0, "unwrapOr 失败");

// ================= 作业二：轻量枚举 + 状态机 =================

const Status = {
  Idle: "idle",
  Running: "running",
  Done: "done",
  Failed: "failed",
} as const;
type Status = (typeof Status)[keyof typeof Status];

type MachineEvent =
  | { type: "start" }
  | { type: "finish" }
  | { type: "fail"; reason: string };

function reduce(state: Status, event: MachineEvent): Status {
  switch (event.type) {
    case "start":
      return state === Status.Idle ? Status.Running : state;
    case "finish":
      return state === Status.Running ? Status.Done : state;
    case "fail":
      return state === Status.Running ? Status.Failed : state;
  }
}
function isTerminal(s: Status): boolean {
  return s === Status.Done || s === Status.Failed;
}

assertEquals(reduce(Status.Idle, { type: "start" }), "running", "start → running");
assertEquals(reduce(Status.Running, { type: "finish" }), "done", "finish → done");
assertEquals(reduce(Status.Running, { type: "fail", reason: "x" }), "failed", "fail → failed");
assertEquals(reduce(Status.Idle, { type: "finish" }), "idle", "非法转移保持原状态");
assertTrue(isTerminal(Status.Done) && !isTerminal(Status.Running), "isTerminal");

// ================= 作业三：类型安全的事件总线 =================

interface BusEvents {
  userCreated: { id: number };
  userDeleted: { id: number };
}
// 内部把各事件的处理器统一存成 (p: never) => void（类型审查角度最宽），
// 这是"用泛型保证事件名与 payload 类型一一对应"的标准做法。
type AnyHandler = (payload: never) => void;
const handlers = new Map<keyof BusEvents, AnyHandler[]>();

function on<K extends keyof BusEvents>(name: K, handler: (payload: BusEvents[K]) => void): void {
  const list = handlers.get(name) ?? [];
  list.push(handler);          // (p: BusEvents[K]) => void 可赋给 (p: never) => void
  handlers.set(name, list);
}
function emit<K extends keyof BusEvents>(name: K, payload: BusEvents[K]): void {
  handlers.get(name)?.forEach((h) => h(payload as never));   // 取出时还原为对应 payload
}

const received: number[] = [];
on("userCreated", (p) => received.push(p.id));
emit("userCreated", { id: 1 });
emit("userCreated", { id: 2 });
assertEquals(received, [1, 2], "事件总线 on/emit");

// ================= 作业四：从 unknown 解析可信数据 =================

function isString(v: unknown): v is string { return typeof v === "string"; }
function isNumber(v: unknown): v is number { return typeof v === "number"; }
function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

type ParsedUser = { name: string; age: number };

function parseUser(input: unknown): ParsedUser | null {
  if (!isRecord(input)) return null;
  const { name, age } = input;
  if (!isString(name) || !isNumber(age)) return null;
  return { name, age };
}
function assertUser(input: unknown): asserts input is ParsedUser {
  if (parseUser(input) === null) throw new Error("invalid User");
}

assertEquals(parseUser({ name: "Bob", age: 20 }), { name: "Bob", age: 20 }, "parseUser 合法");
assertEquals(parseUser({ name: "Bob" }), null, "parseUser 缺字段");
assertEquals(parseUser({ name: 1, age: 20 }), null, "parseUser 类型错");
let asserted = false;
try { assertUser({ name: "Bob" }); } catch { asserted = true; }
assertTrue(asserted, "assertUser 非法抛错");

// ================= 作业五：泛型缓存 LRU =================

class LRU<K, V> {
  private map = new Map<K, V>();
  constructor(private capacity: number) {}

  get(key: K): V | undefined {
    const value = this.map.get(key);
    if (value === undefined) return undefined;
    this.map.delete(key);          // 删了再插 = 移到最近使用
    this.map.set(key, value);
    return value;
  }

  set(key: K, value: V): void {
    if (this.map.has(key)) this.map.delete(key);
    this.map.set(key, value);
    if (this.map.size > this.capacity) {
      const oldest = this.map.keys().next().value;
      if (oldest !== undefined) this.map.delete(oldest);
    }
  }

  get size(): number { return this.map.size; }
}

const lru = new LRU<string, number>(2);
lru.set("a", 1);
lru.set("b", 2);
assertEquals(lru.size, 2, "LRU.size");
assertEquals(lru.get("a"), 1, "LRU.get 命中");
lru.set("c", 3);                    // 超容量，淘汰最久未使用的 "b"
assertEquals(lru.size, 2, "LRU 淘汰后 size");
assertEquals(lru.get("b"), undefined, "LRU 淘汰 b");
assertEquals(lru.get("a"), 1, "LRU 保留 a");
assertEquals(lru.get("c"), 3, "LRU 保留 c");

summary("capstone");
