// ============================================================
// 入口：依次运行全部"可运行参考答案"
//   npm run exercises
//   → tsc 编译到 dist，再用 node 运行 dist/exercises/run-all.js
// 任何 assertEquals 失败都会让进程以非 0 退出码结束。
// ============================================================
import "./01-types-basics";
import "./02-func-optional";
import "./03-union-collections";
import "./04-objects-enums";
import "./05-generics-classes";
import "./06-narrowing-utils";
import "./07-advanced-async";
import "./capstone";

console.log("\n[run-all] 全部习题参考答案已运行完毕（含异步部分请见上面 [ex07] 输出）。");

if (process.exitCode && process.exitCode !== 0) {
  console.log("[run-all] 有断言失败，请检查上面的 ✗ 项。");
}
