// ============================================================
// 参考答案 · 11 泛型 + 12 类 + 13 协议与结构化类型
//   运行：node dist/exercises/05-generics-classes.js
// ============================================================
import { assertEquals, assertTrue, summary } from "./_assert.js";

// ---- 11 泛型 ----

// A1：泛型函数
function first<T>(items: T[]): T {
  return items[0]!;   // noUncheckedIndexedAccess：T | undefined
}
assertEquals(first([10, 20]), 10, "first 泛型");

// A2：泛型类
class Box<T> {
  constructor(private value: T) {}
  get(): T { return this.value; }
}
assertEquals(new Box(6).get(), 6, "Box 泛型类");

// B1：约束 T extends Animal
interface Named2 { name: string }
function feed<T extends Named2>(a: T): string {
  return `feeding ${a.name}`;
}
assertEquals(feed({ name: "Rex" }), "feeding Rex", "T extends 约束");

// C1：keyof T + T[K]
function get<T, K extends keyof T>(obj: T, key: K): T[K] {
  return obj[key];
}
const user = { name: "Bob", age: 20 };
assertEquals(get(user, "age"), 20, "keyof T + T[K] 取 age");
assertEquals(get(user, "name"), "Bob", "keyof T + T[K] 取 name");

// B4：参数元组（ParamSpec 思路）
function callWith<Args extends unknown[], R>(f: (...args: Args) => R, args: Args): R {
  return f(...args);
}
assertEquals(callWith((a: number, b: string) => `${a}${b}`, [1, "x"]), "1x", "callWith 元组参数");

// C3：merge 交叉
function merge<T extends object, U extends object>(a: T, b: U): T & U {
  return { ...a, ...b };
}
assertEquals(merge({ name: "Bob" }, { age: 20 }), { name: "Bob", age: 20 }, "merge 交叉");

// ---- 12 类 ----

// A2：参数属性
class Person {
  constructor(public name: string, public age: number) {}
  greet(): string { return `Hello, ${this.name}!`; }
}
assertEquals(new Person("Bob", 20).greet(), "Hello, Bob!", "参数属性");

// B1：继承 + override
class Animal {
  constructor(public name: string) {}
  speak(): string { return "..."; }
}
class Dog extends Animal {
  constructor(name: string, public breed: string) { super(name); }
  override speak(): string { return "Woof"; }
}
const dog = new Dog("Rex", "Husky");
assertEquals(dog.speak(), "Woof", "override speak");
assertTrue(dog instanceof Animal, "instanceof Animal");

// B3：抽象类
abstract class Shape {
  abstract area(): number;
}
class Circle extends Shape {
  constructor(private r: number) { super(); }
  area(): number { return Math.PI * this.r ** 2; }
}
assertTrue(Math.abs(new Circle(1).area() - Math.PI) < 1e-9, "抽象类子类实现");

// A3：get/set
class Temp {
  constructor(private celsius: number) {}
  get fahrenheit(): number { return (this.celsius * 9) / 5 + 32; }
  set fahrenheit(f: number) { this.celsius = ((f - 32) * 5) / 9; }
}
const t = new Temp(0);
assertEquals(t.fahrenheit, 32, "get fahrenheit");
t.fahrenheit = 212;
assertEquals(t.fahrenheit, 212, "set fahrenheit");

// B4：static
class Math2 {
  static square(x: number): number { return x * x; }
}
assertEquals(Math2.square(3), 9, "static 方法");

// C1：泛型类 Stack
class Stack<T> {
  private items: T[] = [];
  push(item: T): void { this.items.push(item); }
  pop(): T | undefined { return this.items.pop(); }
  peek(): T | undefined { return this.items[this.items.length - 1]; }
  get size(): number { return this.items.length; }
}
const stack = new Stack<number>();
stack.push(1);
stack.push(2);
assertEquals(stack.size, 2, "Stack.size");
assertEquals(stack.peek(), 2, "Stack.peek");
assertEquals(stack.pop(), 2, "Stack.pop");
assertEquals(stack.pop(), 1, "Stack.pop 2");
assertEquals(stack.pop(), undefined, "Stack 空栈 pop");

// ---- 13 协议与结构化类型 ----

// A1：结构化类型：Robot 不 implements 也是 Animal
interface Animal2 { name: string }
class Robot2 { name = "R2D2"; }
function greetAnimal(a: Animal2): string { return `Hi ${a.name}`; }
assertEquals(greetAnimal(new Robot2()), "Hi R2D2", "结构化类型匹配");

// B4：多余属性检查只对字面量
interface Point { x: number; y: number }
const q = { x: 1, y: 2, z: 3 };
const r: Point = q;   // 经变量中转，不查多余字段
assertEquals(r.x, 1, "经变量中转的多余属性");

// C1：类型谓词
function isNamed(x: unknown): x is { name: string } {
  return typeof x === "object" && x !== null && "name" in x
    && typeof (x as { name: unknown }).name === "string";
}
const data: unknown = { name: "Bob" };
assertTrue(isNamed(data), "isNamed 类型谓词");

summary("05-generics-classes");
