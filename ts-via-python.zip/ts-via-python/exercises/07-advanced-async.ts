// ============================================================
// 参考答案 · 16 高级类型 + 17 模块与导入 + 18 异步
//   运行：node dist/exercises/07-advanced-async.js
// ============================================================
import { assertEquals, assertTrue, summary } from "./_assert.js";
import { add, PI } from "./_mathutil.js";            // 具名导入
import Logger from "./_mathutil.js";                 // 默认导入
import type { Point } from "./_mathutil.js";         // 只导入类型

// ---- 16 高级类型 ----

// A1：typeof（类型位置）
const config = { host: "localhost", port: 8080 };
type Config = typeof config;
const cfg: Config = config;
assertEquals(cfg.port, 8080, "typeof 取类型");

// A2/A3：keyof 与索引访问
interface User { name: string; age: number }
type UserKey = keyof User;          // "name" | "age"
type NameType = User["name"];       // string
type UserValue = User[keyof User];  // string | number
const k: UserKey = "name";
const nv: NameType = "x";
const uv: UserValue = 1;
assertEquals(k, "name", "keyof");
assertEquals(nv, "x", "索引访问");
assertEquals(uv, 1, "User[keyof User]");

// B1：条件类型
type IsString<T> = T extends string ? "yes" : "no";
const t1: IsString<string> = "yes";
const t2: IsString<number> = "no";
assertEquals(t1, "yes", "IsString<string>");
assertEquals(t2, "no", "IsString<number>");

// B2：条件类型分发（复刻 Exclude）
type MyExclude<T, U> = T extends U ? never : T;
const r1: MyExclude<"a" | "b" | "c", "a"> = "b";
assertEquals(r1, "b", "MyExclude 分发");

// B3/B4 & C1：infer / 映射类型
type MyReturnType<F> = F extends (...args: never[]) => infer R ? R : never;
type ElementOf<T> = T extends (infer E)[] ? E : never;
type Unwrap<T> = T extends Promise<infer U> ? U : T;
type MyPartial<T> = { [K in keyof T]?: T[K] };
const rt: MyReturnType<() => string> = "s";
const el: ElementOf<string[]> = "e";
const uw: Unwrap<Promise<number>> = 42;
const mp: MyPartial<User> = { age: 21 };
assertEquals(rt, "s", "MyReturnType");
assertEquals(el, "e", "ElementOf");
assertEquals(uw, 42, "Unwrap");
assertEquals(mp.age, 21, "MyPartial");

// C2：键重映射
type Getters<T> = { [K in keyof T as `get${Capitalize<string & K>}`]: () => T[K] };
const getters: Getters<User> = { getName: () => "Bob", getAge: () => 20 };
assertEquals(getters.getName(), "Bob", "Getters 键重映射");

// C3：递归只读
type ReadonlyDeep<T> = {
  readonly [K in keyof T]: T[K] extends object ? ReadonlyDeep<T[K]> : T[K];
};
const deepCfg: ReadonlyDeep<{ host: string; db: { port: number } }> = {
  host: "localhost",
  db: { port: 5432 },
};
assertEquals(deepCfg.db.port, 5432, "ReadonlyDeep 类型可用");

// ---- 17 模块与导入 ----

// 具名导入
assertEquals(add(1, 2), 3, "具名导入 add");
assertEquals(PI, 3.14, "具名导入 PI");

// 默认导入（名字自定）
const logger = new Logger();
logger.log("a");
logger.log("b");
assertEquals(logger.count, 2, "默认导入 Logger");

// 只导入类型
const pt: Point = { x: 1, y: 2 };
assertEquals(pt.x, 1, "import type Point");

// ---- 18 异步 ----

async function fetchUser(uid: number): Promise<string> {
  return `user-${uid}`;
}
function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function main(): Promise<void> {
  console.log("[ex07] 17/18 异步部分开始");

  // async 函数返回 Promise<T>；await 取值
  assertEquals(await fetchUser(7), "user-7", "async/await");

  // Promise.all（≈ asyncio.gather）
  const [a, b] = await Promise.all([fetchUser(1), fetchUser(2)]);
  assertEquals([a, b], ["user-1", "user-2"], "Promise.all");

  // Promise.allSettled（≈ gather(return_exceptions=True)）
  const settled = await Promise.allSettled([
    fetchUser(1),
    Promise.reject(new Error("boom")),
  ]);
  const okCount = settled.filter((s) => s.status === "fulfilled").length;
  const failCount = settled.filter((s) => s.status === "rejected").length;
  assertEquals([okCount, failCount], [1, 1], "Promise.allSettled 统计");

  // try/catch：catch 的 e 是 unknown
  let caught = "";
  try {
    await Promise.reject(new Error("nope"));
  } catch (e: unknown) {
    if (e instanceof Error) caught = e.message;
  }
  assertEquals(caught, "nope", "catch unknown 收窄");

  // for await...of（≈ async for）
  async function* countUpAsync(n: number): AsyncGenerator<number> {
    for (let i = 0; i < n; i++) yield i;
  }
  const collected: number[] = [];
  for await (const x of countUpAsync(3)) collected.push(x);
  assertEquals(collected, [0, 1, 2], "for await...of");

  // C1：withTimeout
  function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
    const timeout = new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error("timeout")), ms));
    return Promise.race([p, timeout]);
  }
  const fast = await withTimeout(sleep(1).then(() => "done"), 50);
  assertEquals(fast, "done", "withTimeout 未超时");
  let timedOut = false;
  try {
    await withTimeout(sleep(50).then(() => "late"), 1);
  } catch {
    timedOut = true;
  }
  assertTrue(timedOut, "withTimeout 超时抛错");

  summary("07-advanced-async");
}

void main();
