// ============================================================
// 参考答案 · 17 模块与导入 的示例模块
//   演示：具名导出、默认导出、export type
// ============================================================
export function add(a: number, b: number): number {
  return a + b;
}

export const PI = 3.14;

export interface Point {
  x: number;
  y: number;
}

export default class Logger {
  private lines: string[] = [];
  log(msg: string): void {
    this.lines.push(msg);
  }
  get count(): number {
    return this.lines.length;
  }
}
